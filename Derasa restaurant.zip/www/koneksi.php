<?php
// koneksi.php (shared for user & admin)
require_once __DIR__ . '/ADMIN/koneksi.php';
// file ADMIN/koneksi.php mendefinisikan $conn dan $mysqli
?>