<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Pembayaran - Restoran DeRasa</title>

  <style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap');

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: "Poppins", sans-serif;
    }

    /* LATAR BELAKANG */
    body {
      background: linear-gradient(135deg, #fdfcfb 0%, #e2d1c3 100%);
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      padding: 30px;
    }

    /* KONTENER UTAMA */
    .container {
      width: 100%;
      max-width: 1100px;
    }

    /* KARTU PEMBAYARAN */
    .card {
      display: flex;
      flex-direction: row;
      gap: 30px;
      background: rgba(255, 255, 255, 0.85);
      backdrop-filter: blur(12px);
      border-radius: 25px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
      padding: 55px 35px 35px 35px;
      animation: fadeIn 0.8s ease;
      transition: 0.3s;
      align-items: flex-start;
      position: relative;
    }

    .card:hover {
      transform: translateY(-4px);
    }

    /* BACK BUTTON */
    .back-btn {
      position: absolute;
      top: 18px;
      left: 20px;
      z-index: 10;
      background: #ffffffee;
      border: 2px solid #d6bfa4;
      padding: 8px 12px;
      border-radius: 12px;
      font-size: 20px;
      cursor: pointer;
      backdrop-filter: blur(6px);
      transition: 0.25s ease;
      box-shadow: 0 4px 10px rgba(0,0,0,0.15);
    }

    .back-btn:hover {
      background: #fff5e5;
      transform: translateX(-4px);
    }

    /* FORM PEMBAYARAN */
    .left-section {
      flex: 1;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
    }

    .header {
      text-align: center;
      margin-bottom: 25px;
    }

    .header h1 {
      color: #1a1a1a;
      font-size: 28px;
    }

    .header h1 span {
      color: #d78b27;
    }

    .header p {
      color: #5a4a3f;
      font-weight: 500;
      margin-top: 5px;
    }

    .payment-form .form-group {
      margin-bottom: 20px;
    }

    .payment-form label {
      font-weight: 600;
      color: #3b2f26;
      margin-bottom: 8px;
      display: block;
    }

    .payment-form input,
    .payment-form select,
    .payment-form textarea {
      width: 100%;
      padding: 12px 15px;
      border-radius: 12px;
      border: 1.8px solid #e0c8af;
      background: #fffdf9;
      font-size: 15px;
      transition: 0.3s;
    }

    .payment-form input:focus,
    .payment-form select:focus,
    .payment-form textarea:focus {
      border-color: #d78b27;
      box-shadow: 0 0 10px rgba(215, 139, 39, 0.2);
      outline: none;
    }

    /* RINGKASAN PESANAN */
    .right-section {
      flex: 1.2;
      background: #1a1a1a;
      border-radius: 20px;
      padding: 25px;
      border: 2px solid #d6bfa4;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
    }

    .order-summary h2 {
      color: #fff;
      text-align: center;
      margin-bottom: 20px;
      font-size: 22px;
    }

    /* ITEM MENU */
    .menu-item {
      display: flex;
      align-items: center;
      background: #fff;
      border-radius: 14px;
      margin-bottom: 15px;
      padding: 12px;
      box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
      transition: 0.3s;
    }

    .menu-item:hover {
      transform: scale(1.02);
    }

    .menu-item img {
      width: 65px;
      height: 65px;
      border-radius: 10px;
      object-fit: cover;
      margin-right: 12px;
      border: 2px solid #f0d9c2;
    }

    .menu-info h3 {
      color: #3b2f26;
      margin: 0;
      font-size: 15px;
    }

    .menu-info p {
      color: #786a5e;
      font-size: 13px;
    }

    .menu-info .price {
      color: #d78b27;
      font-weight: 600;
      font-size: 14px;
    }

    /* JUMLAH PESANAN */
    .menu-actions {
      margin-left: auto;
      display: flex;
      align-items: center;
      gap: 8px;
      background: #fffaf5;
      border-radius: 10px;
      padding: 5px 10px;
    }

    .menu-actions button {
      border: none;
      padding: 6px 10px;
      border-radius: 8px;
      cursor: pointer;
      font-weight: 700;
      font-size: 16px;
      transition: 0.2s ease;
    }

    .add-btn {
      background: #d78b27;
      color: white;
      box-shadow: 0 2px 4px rgba(215, 139, 39, 0.3);
    }

    .add-btn:hover {
      background: #c77a15;
      transform: scale(1.08);
    }

    .delete-btn {
      background: #e74c3c;
      color: white;
      box-shadow: 0 2px 4px rgba(231, 76, 60, 0.3);
    }

    .delete-btn:hover {
      background: #c0392b;
      transform: scale(1.08);
    }

    .menu-qty {
      min-width: 22px;
      text-align: center;
      font-weight: 600;
      color: #3b2f26;
      font-size: 15px;
    }

    /* RINGKASAN HARGA */
    .price-summary {
      background: #fffaf5;
      border-radius: 12px;
      padding: 15px;
      margin-top: 15px;
    }

    .price-summary p {
      display: flex;
      justify-content: space-between;
      color: #3b2f26;
    }

    .price-summary .total {
      font-weight: 700;
      color: #d78b27;
    }

    /* TOMBOL BAYAR */
    .pay-btn {
      width: 100%;
      background: linear-gradient(90deg, #d78b27, #e0a64b);
      border: none;
      border-radius: 12px;
      color: white;
      padding: 14px;
      font-size: 16px;
      font-weight: 600;
      margin-top: 25px;
      cursor: pointer;
      transition: 0.3s;
    }

    .pay-btn:hover {
      background: linear-gradient(90deg, #e0a64b, #d78b27);
      transform: translateY(-2px);
    }

    /* POPUP */
    .popup {
      display: none;
      position: fixed;
      inset: 0;
      background: rgba(0, 0, 0, 0.55);
      backdrop-filter: blur(6px);
      justify-content: center;
      align-items: center;
      z-index: 9999;
    }

    .popup-content {
      position: relative;
      background: linear-gradient(180deg, #ffffff 0%, #f7f5f2 100%);
      border-radius: 18px;
      padding: 25px 20px;
      width: 90%;
      max-width: 380px;
      text-align: center;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.25);
      animation: fadeIn 0.4s ease-in-out;
      border: 1.5px solid #e7d9c6;
      max-height: 120vh;
      overflow-y: auto;
    }

    #popup-body h2 {
      font-size: 20px;
      font-weight: 700;
      color: #1e1e1e;
      margin-bottom: 6px;
    }

    #popup-body p {
      color: #5a4a3f;
      font-size: 13px;
      margin-bottom: 10px;
    }

    .qris-img {
      display: block;
      margin: 15px auto;
      max-width: 230px;
      height: auto;
      border-radius: 12px;
      border: 2px solid #f0e2d0;
      background: #fff;
      padding: 10px;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.08);
    }

    #status {
      font-weight: 600;
      color: #444;
      background: #fff7e6;
      border: 1px solid #f2d9a9;
      border-radius: 8px;
      display: inline-block;
      padding: 6px 12px;
      margin-top: 6px;
      font-size: 13px;
    }

    #timer {
      font-size: 13px;
      color: #7a6a58;
      margin-top: 4px;
    }

    #confirm-paid {
      background: linear-gradient(90deg, #16a34a, #2ecc71);
      color: white;
      border: none;
      border-radius: 10px;
      padding: 10px 14px;
      font-size: 14px;
      cursor: pointer;
      font-weight: 600;
      margin-top: 16px;
      box-shadow: 0 4px 10px rgba(22, 163, 74, 0.25);
      transition: 0.3s;
    }

    #confirm-paid:hover {
      background: linear-gradient(90deg, #2ecc71, #16a34a);
      transform: translateY(-2px);
    }

    .close-popup {
      position: absolute;
      right: 14px;
      top: 12px;
      font-size: 24px;
      cursor: pointer;
      color: #999;
      transition: 0.3s;
    }

    .close-popup:hover {
      color: #333;
      transform: rotate(90deg);
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: scale(0.9) translateY(20px); }
      to { opacity: 1; transform: scale(1) translateY(0); }
    }

    @media (max-height: 600px) {
      .popup-content {
        max-height: 85vh;
        padding: 18px 16px;
      }
      .qris-img {
        max-width: 190px;
      }
    }

    /* ============================
       RESPONSIVE HP (incl. iPhone 14 Pro)
       ============================ */
    @media (max-width: 768px) {
      body {
        padding: 16px 10px;
        align-items: flex-start;   /* supaya mulai dari atas, tidak ketengah */
      }

      .container {
        max-width: 100%;
      }

      .card {
        flex-direction: column;    /* stack form & summary */
        gap: 20px;
        padding: 60px 16px 20px;
        width: 100%;
      }

      .left-section,
      .right-section {
        flex: 1 1 100%;
        width: 100%;
      }

      .right-section {
        margin-top: 5px;
      }
    }

    /* lebih spesifik iPhone 14 Pro (lebar 390px) */
    @media (max-width: 430px) {
      .card {
        border-radius: 20px;
      }

      .header h1 {
        font-size: 22px;
      }

      .order-summary h2 {
        font-size: 18px;
      }

      .payment-form label {
        font-size: 13px;
      }

      .payment-form input,
      .payment-form select {
        font-size: 13px;
        padding: 10px 12px;
      }
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="card">
      <button onclick="goBackSmooth()" class="back-btn">←</button>

      <div class="left-section">
        <header class="header">
          <h1>🍽️ Restoran <span>DeRasa</span></h1>
          <p>💳 Form Pembayaran</p>
        </header>

        <form class="payment-form">
          <div class="form-group">
            <label for="nama">👤 Nama Lengkap</label>
            <input id="nama" type="text" placeholder="Masukkan nama lengkap Anda" required />
          </div>

          <div class="form-group">
            <label for="nomor">📞 Nomor Telepon</label>
            <input id="nomor" type="tel" placeholder="Masukkan nomor telepon aktif" required />
          </div>

          <div class="form-group">
            <label for="Pilihan">🍴 Pilih Pengambilan Pesanan</label>
            <select id="Pilihan" required>
              <option value="">-- Pilih Pengambilan Pesanan --</option>
              <option value="pickup">Pick Up</option>
              <option value="dinein">Dine In</option>
            </select>
          </div>

          <div class="form-group" id="meja-field" style="display:none;">
            <label for="meja">📍 Nomor Meja</label>
            <input id="meja" type="text" placeholder="Masukkan Nomor Meja Anda" />
          </div>

          <div class="form-group">
            <label for="metode">💰 Metode Pembayaran</label>
            <select id="metode" name="metode" required>
              <option value="">-- Pilih Metode Pembayaran --</option>
              <option value="transfer">Transfer Bank</option>
              <option value="ewallet">E-Wallet</option>
              <option value="kasir">Bayar di Kasir</option>
            </select>
            <div id="opsi-pembayaran" style="margin-top: 10px; display: none;"></div>
          </div>
        </form>
      </div>

      <div class="right-section">
        <section class="order-summary">
          <h2>🧾 Ringkasan Pesanan</h2>
          <div id="menu-list">
            <div class="menu-item">
              <img src="putu.jpg" alt="Putu Pandan" />
              <div class="menu-info">
                <h3>Putu Pandan</h3>
                <p>Snack</p>
                <div class="price" data-price="9000">Rp 9.000</div>
              </div>
              <div class="menu-actions">
                <button type="button" class="delete-btn">−</button>
                <span class="qty">1</span>
                <button type="button" class="add-btn">+</button>
              </div>
            </div>
          </div>

          <div class="price-summary">
            <p>Subtotal: <span id="subtotal">Rp 9.000</span></p>
            <p>Pajak (10%): <span id="tax">Rp 900</span></p>
            <hr />
            <p class="total">Total: <strong id="grand-total">Rp 9.900</strong></p>
          </div>

          <button type="button" class="pay-btn">💸 Pay Now</button>
        </section>
      </div>
    </div>
  </div>

  <div id="popup" class="popup">
    <div class="popup-content">
      <span id="close-popup" class="close-popup">&times;</span>
      <div id="popup-body"></div>
    </div>
  </div>

  <script>
    function goBackSmooth() {
      const prev = document.referrer;
      if (prev) {
        window.location.replace(prev);
      } else {
        window.location.replace("../ordermakan.php");
      }
    }

    
    function resolvePaymentImage(raw) {
      if (!raw) return "../img/noimage.png";

      let img = String(raw).trim();

      if (/^https?:\/\//i.test(img) || img.startsWith("data:image")) return img;

      while (img.startsWith("../")) img = img.substring(3);
      while (img.startsWith("./")) img = img.substring(2);

      img = img.replace(/^\/+/, "");
      const lower = img.toLowerCase();

      const marker = "admin/uploads/";
      const idx = lower.indexOf(marker);
      if (idx !== -1) {
        const rest = img.substring(idx + marker.length);
        return "../ADMIN/uploads/" + rest;
      }

      if (lower.startsWith("uploads/")) {
        return "../ADMIN/" + img; // -> ../ADMIN/uploads/...
      }

      // hanya nama file
      return "../ADMIN/uploads/" + img;
    }

document.addEventListener("DOMContentLoaded", () => {
      const metodeSelect = document.getElementById("metode");
      const opsiPembayaran = document.getElementById("opsi-pembayaran");
      const pilihan = document.getElementById("Pilihan");
      const mejaField = document.getElementById("meja-field");
      const menuList = document.getElementById("menu-list");
      const payButton = document.querySelector(".pay-btn");
      const popup = document.getElementById("popup");
      const popupBody = document.getElementById("popup-body");
      const closePopup = document.getElementById("close-popup");

      if (metodeSelect) {
        metodeSelect.addEventListener("change", function () {
          const value = this.value;
          let html = "";

          if (value === "transfer") {
            html = `
              <label for="bank">🏦 Pilih Bank</label>
              <select id="bank" name="bank" required>
                <option value="">-- Pilih Bank --</option>
                <option value="bri">BRI</option>
                <option value="bca">BCA</option>
                <option value="mandiri">Mandiri</option>
              </select>`;
          } else if (value === "ewallet") {
            html = `
              <label for="ewallet">📱 Pilih E-Wallet</label>
              <select id="ewallet" name="ewallet" required>
                <option value="">-- Pilih E-Wallet --</option>
                <option value="qris">QRIS</option>
              </select>`;
          }

          if (html) {
            opsiPembayaran.style.display = "block";
            opsiPembayaran.innerHTML = html;
          } else {
            opsiPembayaran.style.display = "none";
            opsiPembayaran.innerHTML = "";
          }
        });
      }

      if (pilihan && mejaField) {
        pilihan.addEventListener("change", function () {
          mejaField.style.display = this.value === "dinein" ? "block" : "none";
        });
      }

      let orderData =
        JSON.parse(localStorage.getItem("cart")) ||
        JSON.parse(localStorage.getItem("selectedMenu")) ||
        [];

      function rebindQtyButtons() {
        document
          .querySelectorAll(".add-btn")
          .forEach((btn) =>
            btn.addEventListener("click", (e) => tambahMenu(e))
          );
        document
          .querySelectorAll(".delete-btn")
          .forEach((btn) =>
            btn.addEventListener("click", (e) => kurangMenu(e))
          );
      }

      function renderOrder() {
        if (!menuList) return;

        if (!Array.isArray(orderData) || orderData.length === 0) {
          menuList.innerHTML = `<p class="empty-cart">Belum ada pesanan 😢</p>`;
          updateTotal();
          return;
        }

        menuList.innerHTML = orderData
          .map((item) => {
            let imgPath = resolvePaymentImage(item.img);

            return `
            <div class="menu-item">
              <img src="${imgPath || "putu.jpg"}" alt="${item.name}" onerror="this.src='../img/noimage.png'">
              <div class="menu-info">
                <h3>${item.name}</h3>
                <p><small>${item.category?.toUpperCase() || ""}</small></p>
                <span class="price" data-price="${item.price}">
                  Rp ${Number(item.price).toLocaleString("id-ID")}
                </span>
              </div>
              <div class="menu-actions">
                <button type="button" class="delete-btn">➖</button>
                <span class="qty">${item.qty}</span>
                <button type="button" class="add-btn">➕</button>
              </div>
            </div>`;
          })
          .join("");

        rebindQtyButtons();
        updateTotal();
      }

      function updateTotal() {
        let subtotal = 0;
        document.querySelectorAll(".menu-item").forEach((item) => {
          const priceElt = item.querySelector(".price");
          const qtyElt = item.querySelector(".qty");
          if (!priceElt || !qtyElt) return;

          const price = parseInt(priceElt.dataset.price || "0", 10);
          const qty = parseInt(qtyElt.textContent || "0", 10);
          subtotal += price * qty;
        });

        const tax = Math.round(subtotal * 0.1);
        const total = subtotal + tax;

        const subElt = document.getElementById("subtotal");
        const taxElt = document.getElementById("tax");
        const totalElt = document.getElementById("grand-total");

        if (subElt) subElt.textContent = "Rp " + subtotal.toLocaleString("id-ID");
        if (taxElt) taxElt.textContent = "Rp " + tax.toLocaleString("id-ID");
        if (totalElt) totalElt.textContent = "Rp " + total.toLocaleString("id-ID");

        return total;
      }

      function syncOrderDataFromDOM() {
        const itemsDOM = document.querySelectorAll(".menu-item");
        const newData = [];

        itemsDOM.forEach((itemDom) => {
          const name = itemDom.querySelector(".menu-info h3")?.textContent || "";
          const price = parseInt(
            itemDom.querySelector(".price")?.dataset.price || "0",
            10
          );
          const qty = parseInt(
            itemDom.querySelector(".qty")?.textContent || "0",
            10
          );

          if (!name) return;

          const found = orderData.find((x) => x.name === name);
          newData.push({
            id: found?.id || null,
            name,
            price,
            qty,
            img: found?.img || null,
            category: found?.category || "",
          });
        });

        orderData = newData;
        localStorage.setItem("cart", JSON.stringify(orderData));
      }

      window.tambahMenu = function (e) {
        const itemDom = e.target.closest(".menu-item");
        if (!itemDom) return;
        const qtySpan = itemDom.querySelector(".qty");
        let qty = parseInt(qtySpan.textContent || "0", 10);
        qty++;
        qtySpan.textContent = qty;

        syncOrderDataFromDOM();
        updateTotal();
      };

      window.kurangMenu = function (e) {
        const itemDom = e.target.closest(".menu-item");
        if (!itemDom) return;
        const qtySpan = itemDom.querySelector(".qty");
        let qty = parseInt(qtySpan.textContent || "0", 10);
        qty = Math.max(0, qty - 1);
        qtySpan.textContent = qty;

        if (qty === 0) {
          itemDom.remove();
        }

        syncOrderDataFromDOM();
        updateTotal();
      };

      if (payButton) {
        payButton.addEventListener("click", (e) => {
          e.preventDefault();

          const nama = document.getElementById("nama")?.value.trim();
          const nomor = document.getElementById("nomor")?.value.trim();
          const pilihanMakan = document.getElementById("Pilihan")?.value;
          const metode = document.getElementById("metode")?.value;
          const bankElt = document.getElementById("bank");
          const ewalletElt = document.getElementById("ewallet");
          const bank = bankElt ? bankElt.value : "";
          const ewallet = ewalletElt ? ewalletElt.value : "";
          const noMeja = document.getElementById("meja")?.value;

          if (!nama || !nomor) return alert("⚠️ Mohon isi nama dan nomor Anda!");
          if (!pilihanMakan)
            return alert("⚠️ Silakan pilih jenis pemesanan (Dine In / Pick Up).");
          if (pilihanMakan === "dinein" && !noMeja)
            return alert("⚠️ Silakan isi nomor meja Anda.");
          if (!metode)
            return alert("⚠️ Silakan pilih metode pembayaran terlebih dahulu!");
          if (metode === "transfer" && !bank)
            return alert("⚠️ Pilih bank terlebih dahulu!");
          if (metode === "ewallet" && !ewallet)
            return alert("⚠️ Pilih jenis e-wallet terlebih dahulu!");

          const totalNominal =
            document.getElementById("grand-total")?.textContent || "Rp 0";

          // ==============================
          // SIMPAN PESANAN KE DATABASE (INTEGRASI ADMIN)
          // ==============================
          async function saveOrderToDB(paymentLabel) {
            const payload = {
              time: new Date().toISOString(),
              customer: nama,
              phone: nomor,
              paymentMethod: paymentLabel,
              status: "pending",
              notes:
                pilihanMakan === "dinein" ? `Nomor Meja: ${noMeja}` : "Pick Up",
              items: orderData.map((item) => ({
                menuId: item.id || 0,
                name: item.name,
                quantity: item.qty,
                price: item.price,
              })),
            };

            const res = await fetch("../ADMIN/simpan_pesanan.php", {
              method: "POST",
              headers: { "Content-Type": "application/json", Accept: "application/json" },
              body: JSON.stringify(payload),
            });

            const json = await res.json().catch(() => null);
            if (!res.ok || !json || json.status !== "success") {
              const msg = (json && (json.message || json.error)) || "Gagal menyimpan pesanan ke database.";
              throw new Error(msg);
            }

            // redirect ke bukti berdasarkan order_id DB
            window.location.href = `../Bukti/bukti.php?order_id=${(json.order_id || json.id)}`;
          }

          if (metode === "kasir") {
            saveOrderToDB("kasir").catch((err) => alert("❌ " + err.message));
            return;
          }

          let html = "";
          if (metode === "transfer") {
            let va = "000";
            if (bank === "bca") va = "8801234567890";
            if (bank === "bri") va = "1209876543210";
            if (bank === "mandiri") va = "3301122334455";

            html = `
              <h2>🏦 Transfer Bank ${bank.toUpperCase()}</h2>
              <p>Silakan transfer ke nomor VA berikut:</p>
              <div class="va-code"><strong>${va}</strong></div>
              <p class="nominal">💰 Total: <strong>${totalNominal}</strong></p>
              <p id="status">⏳ Menunggu pembayaran...</p>
              <p id="timer">Sisa waktu: <span id="count">30</span> detik</p>
              <button id="confirm-paid" class="confirm-btn">✅ Saya sudah bayar</button>`;
          } else if (metode === "ewallet") {
            html = `
              <h2>📱 Pembayaran via ${ewallet.toUpperCase()}</h2>
              <p>Scan QR di bawah ini:</p>
              <img src="../img/qris.png" class="qris-img" id="qris-img">
              <p class="nominal">💰 Total: <strong>${totalNominal}</strong></p>
              <p id="status">⏳ Menunggu pembayaran...</p>
              <p id="timer">Sisa waktu: <span id="count">30</span> detik</p>
              <button id="confirm-paid" class="confirm-btn">✅ Saya sudah bayar</button>`;
          }

          popupBody.innerHTML = html;
          popup.style.display = "flex";

          const countDisplay = document.getElementById("count");
          const statusText = document.getElementById("status");
          const confirmPaid = document.getElementById("confirm-paid");
          const qrisImg = document.getElementById("qris-img");

          let timeLeft = 30;
          const countdown = setInterval(() => {
            timeLeft--;
            if (countDisplay) countDisplay.textContent = timeLeft;
            if (timeLeft <= 0) {
              clearInterval(countdown);
              if (statusText)
                statusText.textContent = "❌ Waktu habis, silakan coba lagi.";
              if (confirmPaid) confirmPaid.disabled = true;
            }
          }, 1000);

          if (confirmPaid) {
            confirmPaid.addEventListener("click", () => {
              if (confirmPaid.disabled) return;
              clearInterval(countdown);
              if (statusText)
                statusText.textContent =
                  "✅ Pembayaran dikonfirmasi! Mohon tunggu 10 detik...";
              const timerElt = document.getElementById("timer");
              if (timerElt) timerElt.style.display = "none";
              confirmPaid.style.display = "none";
              if (qrisImg) qrisImg.style.filter = "grayscale(40%)";

              const label = metode === "ewallet" ? ewallet : metode;
              setTimeout(() => {
                saveOrderToDB(label).catch((err) => alert("❌ " + err.message));
              }, 1000);
            });
          }
        });
      }

      if (closePopup)
        closePopup.addEventListener("click", () => (popup.style.display = "none"));
      window.addEventListener("click", (e) => {
        if (e.target === popup) popup.style.display = "none";
      });

      renderOrder();
      updateTotal();
    });
  </script>
</body>
</html>
