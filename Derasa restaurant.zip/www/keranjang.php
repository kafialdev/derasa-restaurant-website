<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Keranjang Anda - Restoran DeRasa</title>
  
  <!-- FONT & STYLE -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/checkout.css">
</head>

<body>

  <!-- HEADER -->
  <header>
    <nav class="navbar">
      <div class="logo">🍴 Restoran DeRasa</div>
      <ul class="nav-links">
        <li><a href="index.php">Home</a></li>
        <li><a href="ordermakan.php">Menu</a></li>
        <li><a href="about.php">About</a></li>
        <li><a href="contactus.php">Contact</a></li>
      </ul>
    </nav>
  </header>

  <!-- Bagian CART  -->
  <main class="cart-container" id="cart-page">
    <div class="cart-header-row">
      <div id="cart-back-slot"></div>
      <h2 class="cart-title">Keranjang Anda</h2>
    </div>

    <!--  diisi otomatis oleh cart.js -->
    <div id="cart-items"></div>

    <!-- TOTAL -->
    <div class="cart-summary">
      <h4>Total: <span id="cart-total">Rp 0</span></h4>
      <button id="checkout-btn" class="checkout-btn">Lanjut ke Pembayaran</button>
    </div>

    <!-- Tombol Tambah Menu -->
    <div class="cart-actions">
      <button id="back-to-menu" class="back-btn">➕ Tambah Menu Lain</button>
    </div>
  </main>

  <!--FLOATING ADD BUTTON-->
  <div id="floatingAdd" class="floating-add" title="Tambah Menu Lain">➕</div>

  <!--SCRIPT JS-->
  <script src="js/cart.js"></script>

</body>
</html>
