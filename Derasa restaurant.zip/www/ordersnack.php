<?php
// ordersnack.php (USER) - ambil data menu snack dari database

require_once __DIR__ . '/koneksi.php';

@date_default_timezone_set('Asia/Jakarta');

function resolveMenuImage(string $raw): string {
  $raw = trim($raw);
  if ($raw === '') return 'img/placeholder.png';
  $raw = preg_replace('/\?.*$/', '', $raw);
  $raw = preg_replace('#^(\.{1,2}/)+#', '', $raw);
  $raw = ltrim($raw, '/');
  if (strpos($raw, '/') === false) return 'ADMIN/uploads/' . $raw;
  if (strpos($raw, 'uploads/') === 0) return 'ADMIN/' . $raw;
  if (strpos($raw, 'ADMIN/uploads/') === 0) return $raw;
  return $raw;
}

$result = null;
if ($conn instanceof mysqli) {
  $kategori = 'snack';
  $sql = "
    SELECT id, nama_menu, kategori, harga, stok, status, deskripsi, gambar
    FROM menu_restaurant
    WHERE LOWER(kategori) = ?
      AND (stok IS NULL OR stok > 0)
      AND (
            status IS NULL
            OR TRIM(status) = ''
            OR LOWER(TRIM(status)) IN ('tersedia','1')
          )
    ORDER BY id DESC
  ";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param('s', $kategori);
  $stmt->execute();
  $result = $stmt->get_result();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Order Snack - DeRasa</title>
  <link rel="stylesheet" href="css/order.css">
</head>

<body>
<header class="simple-header">
  <div class="header-left">
    🍴 <span>Restoran DeRasa</span>
  </div>

  <nav class="simple-nav">
    <a href="index.php" class="nav-item">Home</a>
    <a href="ordermakan.php" class="nav-item active">Menu</a>
    <a href="about.php" class="nav-item">About</a>
    <a href="contactus.php" class="nav-item">Contact</a>
  </nav>
</header>

<section class="menu-section">
  <div class="menu-filter">
    <a href="ordermakan.php" class="filter-btn">🍛 Makanan</a>
    <a href="orderminum.php" class="filter-btn">☕ Minuman</a>
    <a href="ordersnack.php" class="filter-btn active">🍟 Snack</a>
  </div>

  <h2>Special <span>Snack</span></h2>

  <div class="menu-container" id="menuContainer">
    <?php if ($result && $result->num_rows > 0): ?>
      <?php while ($row = $result->fetch_assoc()):
        $id = (int)$row['id'];
        $nama = htmlspecialchars($row['nama_menu'] ?? '');
        $harga = (int)($row['harga'] ?? 0);
        $deskripsi = htmlspecialchars($row['deskripsi'] ?? '');
        $gambar = resolveMenuImage((string)($row['gambar'] ?? ''));
      ?>
        <div class="menu-item"
             data-id="<?= $id ?>"
             data-name="<?= $nama ?>"
             data-price="<?= $harga ?>"
             data-img="<?= htmlspecialchars($gambar) ?>">

          <img src="<?= htmlspecialchars($gambar) ?>" alt="<?= $nama ?>" onerror="this.src='img/placeholder.png'">

          <div class="menu-info">
            <h3><?= $nama ?></h3>
            <p><?= $deskripsi ?></p>
          </div>

          <div class="menu-action">
            <span class="price">Rp <?= number_format($harga, 0, ',', '.') ?></span>
            <div class="action-btns">
              <button class="add-btn">➕</button>
            </div>
          </div>

        </div>
      <?php endwhile; ?>
    <?php else: ?>
      <p style="text-align:center;color:#777;">Belum ada snack tersedia.</p>
    <?php endif; ?>
  </div>
</section>

<!-- FLOATING CART -->
<div class="floating-cart" id="floatingCart">
  <div class="floating-cart-header">
    <span id="cart-count">0 item</span>
    <span id="cart-total">Rp 0</span>
  </div>

  <div class="floating-cart-list" id="floating-items"></div>

  <button id="view-cart">Lihat Pesanan Anda</button>
  <button id="clear-cart" class="clear-btn">🗑 Hapus Pilihan</button>
</div>

<div id="notifBox" class="notif-floating"></div>

<script src="js/order.js"></script>
</body>
</html>

<?php
if ($result instanceof mysqli_result) { $result->free(); }
?>
