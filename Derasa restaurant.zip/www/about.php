<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="utf-8">
  <title>Sejarah Restoran DeRasa</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="Restoran DeRasa - Kisah dan sejarah berdirinya restoran terbaik di Surabaya." name="description">

  <!-- Favicon -->
  <link href="img/favicon.ico" rel="icon">

  <!-- Icon Font Stylesheet -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

  <!-- Libraries Stylesheet -->
  <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

  <!-- Customized Bootstrap Stylesheet -->
  <link href="css/bootstrap.min.css" rel="stylesheet">

  <!-- Template Stylesheet -->
  <link href="css/style.css" rel="stylesheet">

  <!-- ⭐ ANIMASI MODERN (ANTI LAG) -->
  <style>
      .fade-anim {
        opacity: 0;
        transform: translateY(25px);
        transition: all .9s ease-out;
      }
      .fade-anim.visible {
        opacity: 1;
        transform: translateY(0);
      }
  </style>
</head>

<body>
  <div class="container-xxl bg-white p-0">

<!-- Navbar & Hero Start -->
<div class="container-xxl position-relative p-0 fade-anim">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark px-4 px-lg-5 py-3 py-lg-0">
        
        <!-- LOGO -->
        <a href="index.php" class="navbar-brand p-0">
            <h1 class="text-primary m-0">
                <i class="fa fa-utensils me-3"></i>DeRasa
            </h1>
        </a>

        <!-- TOGGLER -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarCollapse">
            <span class="fa fa-bars"></span>
        </button>

        <!-- MENU -->
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav ms-auto py-0 pe-4">
                <a href="index.php" class="nav-item nav-link">Home</a>
                <a href="about.php" class="nav-item nav-link active">About</a>
                <a href="contactus.php" class="nav-item nav-link">Contact Us</a>
                <a href="menu.php" class="nav-item nav-link">Menu</a>
            </div>

            <!-- BUTTON (scroll ke reservation section di INDEX) -->
            <a href="index.php#reservasi" class="btn btn-primary py-2 px-4">
                Book A Table
            </a>
        </div>

    </nav>

    <!-- HERO HEADER -->
    <div class="container-xxl py-5 bg-dark hero-header mb-5">
        <div class="container text-center my-5 pt-5 pb-4 fade-anim">
            <h1 class="display-3 text-white mb-3">Sejarah DeRasa</h1>

            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center text-uppercase">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item text-white active" aria-current="page">Sejarah</li>
                </ol>
            </nav>
        </div>
    </div>
</div>
<!-- Navbar & Hero End -->


    <!-- Sejarah Start -->
    <div class="container-xxl py-5 fade-anim">
      <div class="container">

        <!-- Bagian 1 -->
        <div class="row g-5 align-items-center fade-anim">
          <div class="col-lg-6">
            <img class="img-fluid rounded shadow-lg" loading="lazy" src="img/about-1.jpg" alt="Restoran DeRasa">
          </div>
          <div class="col-lg-6">
            <h5 class="section-title ff-secondary text-start text-primary fw-normal">Kisah Kami</h5>
            <h1 class="mb-4">Awal Berdirinya <i class="fa fa-utensils text-primary me-2"></i>DeRasa</h1>
            <p class="mb-4">
              Restoran <strong>DeRasa</strong> lahir dari sebuah dapur kecil di Surabaya pada tahun <b>2010</b>.
            </p>
            <p class="mb-4">
              Nama “DeRasa” berasal dari kata “Rasa” — karena kami percaya bahwa setiap hidangan menyimpan cerita dan perasaan.
            </p>
          </div>
        </div>

        <!-- Bagian 2 -->
        <div class="row g-5 align-items-center mt-5 fade-anim">
          <div class="col-lg-6 order-lg-2">
            <img class="img-fluid rounded shadow-lg" loading="lazy" src="img/about-4.jpg" alt="Interior Restoran DeRasa">
          </div>
          <div class="col-lg-6">
            <h2 class="text-primary mb-3">Perjalanan Menuju Kepercayaan Pelanggan</h2>
            <p>
              Dalam lebih dari satu dekade, DeRasa telah melewati banyak tantangan — dari menjaga kualitas bahan segar hingga meningkatkan pelayanan.
            </p>
            <p>
              Setiap menu yang Anda nikmati adalah hasil perpaduan resep turun-temurun dan inovasi modern.
            </p>
          </div>
        </div>

      </div>
    </div>
    <!-- Sejarah End -->


        <!-- Footer Start -->
        <div id="targetService" class="bg-dark text-light footer pt-5 mt-5 wow fadeIn" data-wow-delay="0.1s">
            <div class="container py-5">
                <div class="row g-5">
                    <div class="col-lg-3 col-md-6">
                        <h4 class="section-title ff-secondary text-start text-primary fw-normal mb-4">Company</h4>
                        <a class="btn btn-link" href="about.php">About Us</a>
                        <a class="btn btn-link" href="contactus.php">Contact Us</a>
                        <a class="btn btn-link" href="index.php#reservasi">Reservation</a>
                        <a class="btn btn-link" href="index.php#Chef">Chef</a>
                        <a class="btn btn-link" href="index.php#Testimoni">Rating Customer</a>

                    </div>
                    <div class="col-lg-3 col-md-6">
                        <h4 class="section-title ff-secondary text-start text-primary fw-normal mb-4">Contact</h4>
                        <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>Jalan Taman Gapura, Citraland nomor 07, Surabaya</p>
                        <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>+6287798765432</p>
                        <p class="mb-2"><i class="fa fa-envelope me-3"></i>@derasa.restaurant</p>
                        <div class="d-flex pt-2">
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-youtube"></i></a>
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-linkedin-in"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <h4 class="section-title ff-secondary text-start text-primary fw-normal mb-4">Opening</h4>
                        <h5 class="text-light fw-normal">Monday - Saturday</h5>
                        <p>09AM - 09PM</p>
                        <h5 class="text-light fw-normal">Sunday</h5>
                        <p>10AM - 08PM</p>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <h4 class="section-title ff-secondary text-start text-primary fw-normal mb-4">Newsletter</h4>
                        <p>Terimakasih atas kunjungan anda, sampai jumpaa!</p>
                        <div class="position-relative mx-auto" style="max-width: 400px;">
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="copyright">
                    <div class="row">
                        <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
							
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
  </div>

  <!-- JavaScript Libraries -->
  <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>

  <!-- Animasi WOW.js DIMATIKAN (dihapus) -->
  <!-- <script src="lib/wow/wow.min.js"></script> -->

  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="lib/tempusdominus/js/moment.min.js"></script>
  <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

  <!-- Template Javascript -->
  <script src="js/main.js"></script>

  <!-- ⭐ ANIMASI MODERN (Intersection Observer) -->
  <script>
      const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
          }
        });
      }, { threshold: 0.2 });

      document.querySelectorAll('.fade-anim')
              .forEach(el => observer.observe(el));
  </script>

</body>
</html>
