 <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Restoran - DeRasa</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">


    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    

</head>

<body>
    <div class="container-xxl bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->

        <!-- Fallback: hide spinner even if CDN/JS gagal -->
        <script>
          (function(){
            function hide(){ var sp=document.getElementById('spinner'); if(sp) sp.classList.remove('show'); }
            if(document.readyState === 'loading'){
              document.addEventListener('DOMContentLoaded', function(){ setTimeout(hide, 50); });
            } else { setTimeout(hide, 50); }
            // hard fallback
            setTimeout(hide, 1500);
          })();
        </script>


        <!-- Navbar & Hero Start -->
        <div class="container-xxl position-relative p-0">
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark px-4 px-lg-5 py-3 py-lg-0">
        <a href="index.php" class="navbar-brand p-0 d-flex align-items-center">
        <img src="img/logofiks.png" alt="Logo Restoran DeRasa" style="width: 300px; height: 400px;">

                    <!-- <img src="img/logo" alt="Logo"> -->
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                    <span class="fa fa-bars"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <div class="navbar-nav ms-auto py-0 pe-4">
                        <a href="index.php" class="nav-item nav-link active">Home</a>
                        <a href="about.php" class="nav-item nav-link">About</a>
                        <a href="contactus.php" class="nav-item nav-link">Contact Us</a>
                        <a href="menu.php" class="nav-item nav-link">Menu</a>
                        <div class="nav-item dropdown">
                            <div class="dropdown-menu m-0">
                                <a href="booking.php" class="dropdown-item">Booking</a>
                                <a href="team.php" class="dropdown-item">Our Team</a>
                                <a href="testimonial.php" class="dropdown-item">Testimonial</a>
                            </div>
                        </div>
                    </div>
                    <a href="#reservasi" class="btn btn-primary py-2 px-4">Book A Table</a>
                </div>
            </nav>

            <div class="container-xxl py-5 bg-dark hero-header mb-5">
                <div class="container my-5 py-5">
                    <div class="row align-items-center g-5">
                        <div class="col-lg-6 text-center text-lg-start">
                            <h1 class="display-3 text-white animated slideInLeft"> Rasa Nusantara<br>Delicious Meal</h1>
                            <p class="text-white animated slideInLeft mb-4 pb-2">DeRasa menghidangkan harmoni cita rasa tradisional dan sentuhan modern dalam setiap sajian — menghadirkan pengalaman kuliner yang menggugah selera dan tak terlupakan</p>
                            
                            <button id="pesanSekarangBtn" class="btn btn-primary py-sm-3 px-sm-5 me-3 animated slideInLeft">
                             Pesan Sekarang
                            </button>

                        <script>
                        document.getElementById("pesanSekarangBtn").addEventListener("click", () => {
                      // Pindah ke halaman order makanan
                      window.location.href = "ordermakan.php";
                        });
                        </script>
                        <script>
                        document.getElementById("pesanSekarangBtn").addEventListener("click", () => {
                         });
                        </script>
            <!-- Clock Start -->
                <div class="clock-container text-center my-4">
                <div id="clock"></div>
            </div>
            <!-- Clock End -->
            </div>
            <div class="col-lg-6 text-center text-lg-end overflow-hidden">
                <img class="img-fluid" src="img/hero.png" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
        <!-- Navbar & Hero End -->

<h2 id="greeting"></h2>

<!-- Service Start -->
<section class="container-xxl py-5 position-relative overflow-hidden">
  <div class="container text-center mb-5">
    <h2 class="fw-bold text-primary mb-3 wow fadeInDown">Layanan Kami</h2>
    <p class="text-muted mb-0 wow fadeInUp">Nikmati pengalaman kuliner terbaik dengan layanan unggulan kami</p>
  </div>

  <div class="row g-4 justify-content-center">
    <div class="col-lg-3 col-md-6 col-sm-6 wow fadeInUp" data-wow-delay="0.1s">
      <button id="scrollToChefButton" class="service-card w-100 h-100">
        <div class="icon-wrapper mx-auto mb-4">
          <i class="fa fa-user-tie"></i>
        </div>
        <h5 class="fw-bold mb-2">Master Chefs</h5>
        <p class="text-muted mb-0">Di balik setiap hidangan, ada chef berpengalaman.</p>
      </button>
    </div>

    <div class="col-lg-3 col-md-6 col-sm-6 wow fadeInUp" data-wow-delay="0.3s">
      <button id="scrollToMenuButton" class="service-card w-100 h-100">
        <div class="icon-wrapper mx-auto mb-4">
          <i class="fa fa-utensils"></i>
        </div>
        <h5 class="fw-bold mb-2">Quality Food</h5>
        <p class="text-muted mb-0">Setiap rasa punya cerita, dan setiap cerita hadir di atas meja.</p>
      </button>
    </div>

    <div class="col-lg-3 col-md-6 col-sm-6 wow fadeInUp" data-wow-delay="0.5s">
      <button id="scrollToBuyButton"
        class="service-card w-100 h-100"
        onclick="window.location.href='ordermakan.php'">
        <div class="icon-wrapper mx-auto mb-4">
          <i class="fa fa-cart-plus"></i>
        </div>
        <h5 class="fw-bold mb-2">Online Order</h5>
        <p class="text-muted mb-0">Jangan Khawatir sekarang bisa langsung melakukan order online!!!</p>
      </button>
    </div>

    <div class="col-lg-3 col-md-6 col-sm-6 wow fadeInUp" data-wow-delay="0.7s">
      <button id="scrollToServiceButton" class="service-card w-100 h-100">
        <div class="icon-wrapper mx-auto mb-4">
          <i class="fa fa-headset"></i>
        </div>
        <h5 class="fw-bold mb-2">24/7 Service</h5>
        <p class="text-muted mb-0">Ada keluhan? Hubungi kami segera!</p>
      </button>
    </div>
  </div>
</section>
<!-- Service End -->

       <!-- About Start -->
<div class="container-xxl py-5 about-section">
  <div class="container">
    <div class="row g-5 align-items-center flex-row-reverse">
      <!-- Bagian Gambar (Sekarang di kanan) -->
      <div class="col-lg-6">
        <div class="row g-3">
          <div class="col-6 text-start">
            <img class="img-fluid rounded w-100 zoom-img" src="img/resto1.jpg" alt="Restoran 1">
          </div>
          <div class="col-6 text-start">
            <img class="img-fluid rounded w-75 zoom-img" src="img/resto2.jpg" alt="Restoran 2" style="margin-top: 25%;">
          </div>
          <div class="col-6 text-end">
            <img class="img-fluid rounded w-75 zoom-img" src="img/resto3.jpg" alt="Restoran 3">
          </div>
          <div class="col-6 text-end">
            <img class="img-fluid rounded w-100 zoom-img" src="img/resto4.jpg" alt="Restoran 4">
          </div>
        </div>
      </div>

      <!-- Bagian Teks (Sekarang di kiri) -->
      <div class="col-lg-6">
        <h5 class="section-title ff-secondary text-start text-primary fw-normal">About Us</h5>
        <h1 class="mb-4">
          Welcome to <i class="fa fa-utensils text-primary me-2"></i>DeRasa
        </h1>
        <p class="mb-4">
          Selamat datang di DeRasa. Bagi kami, makanan bukan hanya soal rasa, tetapi juga tentang cerita, kehangatan, dan kebersamaan. Dari bahan segar pilihan hingga proses masak penuh cinta, setiap hidangan kami hadirkan untuk memberikan kenyamanan dan pengalaman yang tak terlupakan. Mari duduk sejenak, nikmati suasana, dan biarkan rasa membawa Anda pulang.
        </p>

        <div class="row g-4 mb-4">
          <div class="col-sm-6">
            <div class="d-flex align-items-center border-start border-5 border-primary px-3 stat-box">
              <h1 class="flex-shrink-0 display-5 text-primary mb-0" data-toggle="counter-up">15</h1>
              <div class="ps-4">
                <p class="mb-0">Years of</p>
                <h6 class="text-uppercase mb-0">Experience</h6>
              </div>
            </div>
          </div>
          <div class="col-sm-6">
            <div class="d-flex align-items-center border-start border-5 border-primary px-3 stat-box">
              <h1 class="flex-shrink-0 display-5 text-primary mb-0" data-toggle="counter-up">50</h1>
              <div class="ps-4">
                <p class="mb-0">Popular</p>
                <h6 class="text-uppercase mb-0">Master Chefs</h6>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
</div>
<!-- About End -->


        <!-- Menu Start -->
        <div id="targetMenu" class="container-xxl py-5">
            <div class="container">
                <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                    <h5 class="section-title ff-secondary text-center text-primary fw-normal">Food Menu</h5>
                    <h1 class="mb-5">Most Popular Items</h1>
                </div>
                <div class="tab-class text-center wow fadeInUp" data-wow-delay="0.1s">
                    <ul class="nav nav-pills d-inline-flex justify-content-center border-bottom mb-5">
                        <li class="nav-item">
                            <a class="d-flex align-items-center text-start mx-3 pb-3" data-bs-toggle="pill" href="#tab-1">
                                <i class="fa fa-hamburger fa-2x text-primary"></i>
                                <div class="ps-3">
                                    <small class="text-body">Popular</small>
                                    <h6 class="mt-n1 mb-0">Makanan</h6>
                                </div>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="d-flex align-items-center text-start mx-3 ms-0 pb-3 active" data-bs-toggle="pill" href="#tab-2">
                                <i class="fa fa-coffee fa-2x text-primary"></i>
                                <div class="ps-3">
                                    <small class="text-body">Special</small>
                                    <h6 class="mt-n1 mb-0">Minuman</h6>
                                </div>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="d-flex align-items-center text-start mx-3 me-0 pb-3" data-bs-toggle="pill" href="#tab-3">
                                <i class="fa fa-utensils fa-2x text-primary"></i>
                                <div class="ps-3">
                                    <small class="text-body">Favorite</small>
                                    <h6 class="mt-n1 mb-0">Snack</h6>
                                </div>
                            </a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div id="tab-1" class="tab-pane fade show p-0 active">
                            <div class="row g-4">
                                <div class="col-lg-6">
                                    <div class="d-flex align-items-center">
                                        <img class="flex-shrink-0 img-fluid rounded" src="img/Rendabg.jpg" alt="" style="width: 80px;">
                                        <div class="w-100 d-flex flex-column text-start ps-4">
                                            <h5 class="d-flex justify-content-between border-bottom pb-2">
                                                <span>Rendang Nusantara</span>
                                                <span class="text-primary">Rp 39.000</span>
                                            </h5>
                                            <small class="fst-italic">Rendang sapi empuk dengan bumbu rempah khas Minang</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="d-flex align-items-center">
                                        <img class="flex-shrink-0 img-fluid rounded" src="img/pempek.jpg" alt="" style="width: 80px;">
                                        <div class="w-100 d-flex flex-column text-start ps-4">
                                            <h5 class="d-flex justify-content-between border-bottom pb-2">
                                                <span>Pempek Makasar</span>
                                                <span class="text-primary">Rp 25.000</span>
                                            </h5>
                                            <small class="fst-italic">Olahan ikan khas Palembang dengan tekstur kenyal, disajikan dengan kuah cuko</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="d-flex align-items-center">
                                        <img class="flex-shrink-0 img-fluid rounded" src="img/nasgor.jpg" alt="" style="width: 80px;">
                                        <div class="w-100 d-flex flex-column text-start ps-4">
                                            <h5 class="d-flex justify-content-between border-bottom pb-2">
                                                <span>Nasi Goreng</span>
                                                <span class="text-primary"> Rp 29.000</span>
                                            </h5>
                                            <small class="fst-italic">Nasi goreng khas Indonesia dengan cita rasa gurih dan aroma menggoda</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="d-flex align-items-center">
                                        <img class="flex-shrink-0 img-fluid rounded" src="img/Pecel-Lele.webp" alt="" style="width: 80px;">
                                        <div class="w-100 d-flex flex-column text-start ps-4">
                                            <h5 class="d-flex justify-content-between border-bottom pb-2">
                                                <span>Lele Nusantara</span>
                                                <span class="text-primary">Rp 25.000</span>
                                            </h5>
                                            <small class="fst-italic">Lele goreng renyah disajikan dengan sambal pedas khas dan lalapan segar</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="d-flex align-items-center">
                                        <img class="flex-shrink-0 img-fluid rounded" src="img/ikanbakar.webp" alt="" style="width: 80px;">
                                        <div class="w-100 d-flex flex-column text-start ps-4">
                                            <h5 class="d-flex justify-content-between border-bottom pb-2">
                                                <span>Ikan Bakar</span>
                                                <span class="text-primary">Rp 33.000</span>
                                            </h5>
                                            <small class="fst-italic">Ikan segar dibakar dengan bumbu rempah khas, menghasilkan cita rasa gurih dan smoky</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="d-flex align-items-center">
                                        <img class="flex-shrink-0 img-fluid rounded" src="img/Mie-Aceh.webp" alt="" style="width: 80px;">
                                        <div class="w-100 d-flex flex-column text-start ps-4">
                                            <h5 class="d-flex justify-content-between border-bottom pb-2">
                                                <span>Mie Aceh</span>
                                                <span class="text-primary">Rp 28.000</span>
                                            </h5>
                                            <small class="fst-italic">Mi Aceh dengan bumbu rempah khas, disajikan gurih dan pedas menggugah selera</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="d-flex align-items-center">
                                        <img class="flex-shrink-0 img-fluid rounded" src="img/rujak.jpg" alt="" style="width: 80px;">
                                        <div class="w-100 d-flex flex-column text-start ps-4">
                                            <h5 class="d-flex justify-content-between border-bottom pb-2">
                                                <span>Rujak Sayur</span>
                                                <span class="text-primary">Rp 27.000</span>
                                            </h5>
                                            <small class="fst-italic">Rujak sayur dengan aneka rebusan segar disiram bumbu kacang gurih pedas</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="d-flex align-items-center">
                                        <img class="flex-shrink-0 img-fluid rounded" src="img/ayam kari.jpg" alt="" style="width: 80px;">
                                        <div class="w-100 d-flex flex-column text-start ps-4">
                                            <h5 class="d-flex justify-content-between border-bottom pb-2">
                                                <span>Ayam Kari</span>
                                                <span class="text-primary">Rp 35.000</span>
                                            </h5>
                                            <small class="fst-italic">Ayam kari dengan kuah santan gurih dan rempah harum khas Nusantara</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="tab-2" class="tab-pane fade show p-0">
                            <div class="row g-4">
                                <div class="col-lg-6">
                                    <div class="d-flex align-items-center">
                                        <img class="flex-shrink-0 img-fluid rounded" src="img/dawet.webp" alt="" style="width: 80px;">
                                        <div class="w-100 d-flex flex-column text-start ps-4">
                                            <h5 class="d-flex justify-content-between border-bottom pb-2">
                                                <span>Dawet Nusantara</span>
                                                <span class="text-primary">Rp 15.000</span>
                                            </h5>
                                            <small class="fst-italic">Minuman tradisional Jawa yang menyegarkan, perpaduan cendol, santan, dan gula aren</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="d-flex align-items-center">
                                        <img class="flex-shrink-0 img-fluid rounded" src="img/pisangijo.webp" alt="" style="width: 80px;">
                                        <div class="w-100 d-flex flex-column text-start ps-4">
                                            <h5 class="d-flex justify-content-between border-bottom pb-2">
                                                <span>Es Pisang Ijo</span>
                                                <span class="text-primary">Rp 25.000</span>
                                            </h5>
                                            <small class="fst-italic">Hidangan segar khas Makassar, pisang dibalut adonan hijau lembut dengan saus santan dan sirup merah</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="d-flex align-items-center">
                                        <img class="flex-shrink-0 img-fluid rounded" src="img/esbuah.jpg" alt="" style="width: 80px;">
                                        <div class="w-100 d-flex flex-column text-start ps-4">
                                            <h5 class="d-flex justify-content-between border-bottom pb-2">
                                                <span>Es Campur Nusantara</span>
                                                <span class="text-primary">Rp 19.000</span>
                                            </h5>
                                            <small class="fst-italic">Es buah segar dengan aneka potongan buah pilihan, disajikan manis dan menyegarkan</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="d-flex align-items-center">
                                        <img class="flex-shrink-0 img-fluid rounded" src="img/ronde.jpg" alt="" style="width: 80px;">
                                        <div class="w-100 d-flex flex-column text-start ps-4">
                                            <h5 class="d-flex justify-content-between border-bottom pb-2">
                                                <span>Wedang Ronde</span>
                                                <span class="text-primary">Rp 15.000</span>
                                            </h5>
                                            <small class="fst-italic">Wedang ronde hangat dengan bola ketan isi kacang, berpadu kuah jahe manis yang menghangatkan</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="d-flex align-items-center">
                                        <img class="flex-shrink-0 img-fluid rounded" src="img/doger.avif" alt="" style="width: 80px;">
                                        <div class="w-100 d-flex flex-column text-start ps-4">
                                            <h5 class="d-flex justify-content-between border-bottom pb-2">
                                                <span>Es Doger</span>
                                                <span class="text-primary">Rp 17.000</span>
                                            </h5>
                                            <small class="fst-italic">Kesegaran es doger dengan cita rasa manis gurih yang unik dan menggugah selera</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="d-flex align-items-center">
                                        <img class="flex-shrink-0 img-fluid rounded" src="img/degan.jpg" alt="" style="width: 80px;">
                                        <div class="w-100 d-flex flex-column text-start ps-4">
                                            <h5 class="d-flex justify-content-between border-bottom pb-2">
                                                <span>Es Degan</span>
                                                <span class="text-primary">Rp 15.000</span>
                                            </h5>
                                            <small class="fst-italic">Es degan segar dengan daging kelapa muda lembut dan air kelapa alami</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="d-flex align-items-center">
                                        <img class="flex-shrink-0 img-fluid rounded" src="img/teh.webp" alt="" style="width: 80px;">
                                        <div class="w-100 d-flex flex-column text-start ps-4">
                                            <h5 class="d-flex justify-content-between border-bottom pb-2">
                                                <span>Es Teh</span>
                                                <span class="text-primary">Rp 10.000</span>
                                            </h5>
                                            <small class="fst-italic">Es teh segar dengan rasa manis pas dan sensasi dingin menyegarkan</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="d-flex align-items-center">
                                        <img class="flex-shrink-0 img-fluid rounded" src="img/jeruk.jpeg" alt="" style="width: 80px;">
                                        <div class="w-100 d-flex flex-column text-start ps-4">
                                            <h5 class="d-flex justify-content-between border-bottom pb-2">
                                                <span>Es Jeruk</span>
                                                <span class="text-primary">Rp 15.000</span>
                                            </h5>
                                            <small class="fst-italic">Es jeruk segar dengan perasan jeruk asli, manis alami dan menyegarkan</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="tab-3" class="tab-pane fade show p-0">
                            <div class="row g-4">
                                <div class="col-lg-6">
                                    <div class="d-flex align-items-center">
                                        <img class="flex-shrink-0 img-fluid rounded" src="img/Putu Pandan Sponge Cake.jpg" alt="" style="width: 80px;">
                                        <div class="w-100 d-flex flex-column text-start ps-4">
                                            <h5 class="d-flex justify-content-between border-bottom pb-2">
                                                <span>Putu Pandan</span>
                                                <span class="text-primary">Rp 9.000</span>
                                            </h5>
                                            <small class="fst-italic">Jajanan tradisional dengan aroma pandan wangi, manis gula merah, dan gurih kelapa</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="d-flex align-items-center">
                                        <img class="flex-shrink-0 img-fluid rounded" src="img/pukis.webp" alt="" style="width: 80px;">
                                        <div class="w-100 d-flex flex-column text-start ps-4">
                                            <h5 class="d-flex justify-content-between border-bottom pb-2">
                                                <span>Kue Pukis</span>
                                                <span class="text-primary">Rp 10.000</span>
                                            </h5>
                                            <small class="fst-italic">Kue pukis lembut dengan aroma harum, manis legit, dan tekstur empuk</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="d-flex align-items-center">
                                        <img class="flex-shrink-0 img-fluid rounded" src="img/lemper.jpg" alt="" style="width: 80px;">
                                        <div class="w-100 d-flex flex-column text-start ps-4">
                                            <h5 class="d-flex justify-content-between border-bottom pb-2">
                                                <span>Lemper Ayam</span>
                                                <span class="text-primary">Rp 15.000</span>
                                            </h5>
                                            <small class="fst-italic">Lemper pulen berisi suwiran ayam berbumbu gurih, dibungkus daun pisang harum</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="d-flex align-items-center">
                                        <img class="flex-shrink-0 img-fluid rounded" src="img/lapis.webp" alt="" style="width: 80px;">
                                        <div class="w-100 d-flex flex-column text-start ps-4">
                                            <h5 class="d-flex justify-content-between border-bottom pb-2">
                                                <span>Kue Lapis</span>
                                                <span class="text-primary">Rp 18.000</span>
                                            </h5>
                                            <small class="fst-italic">Lemper pulen berisi suwiran ayam berbumbu gurih, dibungkus daun pisang harum</small>
                                        </div>
                                    </div>
                             </div> 
                                <div class="col-lg-6">
                                    <div class="d-flex align-items-center">
                                        <img class="flex-shrink-0 img-fluid rounded" src="img/lukcup.jpg" alt="" style="width: 80px;">
                                        <div class="w-100 d-flex flex-column text-start ps-4">
                                            <h5 class="d-flex justify-content-between border-bottom pb-2">
                                                <span>Kue Lukchup</span>
                                                <span class="text-primary">Rp 22.000</span>
                                            </h5>
                                            <small class="fst-italic">Manisan kacang hijau khas Thailand berbentuk buah mini dengan rasa manis lembut</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="d-flex align-items-center">
                                        <img class="flex-shrink-0 img-fluid rounded" src="img/martabak.webp" alt="" style="width: 80px;">
                                        <div class="w-100 d-flex flex-column text-start ps-4">
                                            <h5 class="d-flex justify-content-between border-bottom pb-2">
                                                <span>Martabak</span>
                                                <span class="text-primary">Rp 17.000</span>
                                            </h5>
                                            <small class="fst-italic">Hidangan gurih berisi telur, daging cincang, dan bumbu rempah, dibungkus adonan tipis yang digoreng hingga renyah</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="d-flex align-items-center">
                                        <img class="flex-shrink-0 img-fluid rounded" src="img/otak.webp" alt="" style="width: 80px;">
                                        <div class="w-100 d-flex flex-column text-start ps-4">
                                            <h5 class="d-flex justify-content-between border-bottom pb-2">
                                                <span>Otak-Otak</span>
                                                <span class="text-primary">Rp 17.000</span>
                                            </h5>
                                            <small class="fst-italic">Camilan gurih dari ikan giling berbumbu, dibungkus daun pisang lalu dibakar atau dikukus hingga harum dan lezat</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="d-flex align-items-center">
                                        <img class="flex-shrink-0 img-fluid rounded" src="img/Tahu bakso.jpg" alt="" style="width: 80px;">
                                        <div class="w-100 d-flex flex-column text-start ps-4">
                                            <h5 class="d-flex justify-content-between border-bottom pb-2">
                                                <span>Tahu Bakso</span>
                                                <span class="text-primary">Rp 18.000</span>
                                            </h5>
                                            <small class="fst-italic">Tahu isi adonan bakso daging yang gurih, cocok dinikmati hangat sebagai camilan atau lauk</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Menu End -->


<!-- Reservation Section Start -->
<section id="reservasi" class="reservation-section py-5">
  <div class="container">
    <div class="reservation-box row g-0 shadow-lg rounded-4 overflow-hidden">

      <!-- Left Video -->
      <div class="col-lg-6 position-relative p-0 video-wrapper">
        <video class="video-blur" autoplay muted loop playsinline>
          <source src="img/videoplayback.mp4" type="video/mp4">
        </video>

        <video class="video-main" autoplay muted loop playsinline>
          <source src="img/videoplayback.mp4" type="video/mp4">
        </video>
      </div>

      <!-- Right Form -->
      <div class="col-lg-6 form-side bg-dark text-light p-5">
        <h5 class="section-title text-uppercase text-primary mb-2">Reservation</h5>
        <h1 class="fw-bold mb-4">Book Your Table Now</h1>

<!-- FORM MULAI -->
<!--
  Reservasi user disimpan ke tabel `reservations`.
  Endpoint utama: proses_reservasi.php (support AJAX & POST biasa).
-->
<form id="reservationForm" action="proses_reservasi.php" method="POST">

  <div class="row g-3">

    <div class="col-md-6">
      <div class="form-floating">
        <input type="text" class="form-control" id="name" name="name" placeholder="Your Name" required>
        <label for="name">Your Name</label>
      </div>
    </div>

    <div class="col-md-6">
      <div class="form-floating">
        <input type="tel" class="form-control" id="phone" name="phone" placeholder="Phone Number" required>
        <label for="phone">Phone Number</label>
      </div>
    </div>

    <div class="col-md-6">
      <div class="form-floating">
        <input type="datetime-local" class="form-control" id="datetime" name="datetime" required>
        <label for="datetime">Date & Time</label>
      </div>
    </div>

    <div class="col-md-6">
      <div class="form-floating">
        <select class="form-select" id="people" name="people">
          <option>1 Person</option>
          <option>2 People</option>
          <option>3 People</option>
          <option>4 People</option>
          <option>5+ People</option>
        </select>
        <label for="people">Guests</label>
      </div>
    </div>

    <div class="col-12">
      <div class="form-floating">
        <textarea class="form-control" id="message" name="message" placeholder="Special Request" style="height: 100px"></textarea>
        <label for="message">Special Request</label>
      </div>
    </div>

    <div class="col-12">
      <!--
        UX fix:
        Klik "Reserve Now" langsung simpan reservasi ke database,
        lalu tampilkan popup bukti (download PDF opsional).
      -->
      <!--
        IMPORTANT:
        Pakai type="submit" (bukan button biasa) supaya pasti jalan walau JS error.
        JS (main.js) akan intercept submit untuk AJAX + popup, tapi fallback POST biasa tetap tersimpan.
      -->
      <button type="submit" class="btn btn-primary w-100 py-3 reserve-btn" id="reserveBtn">
        Reserve Now
      </button>
    </div>

  </div>

<!-- POPUP -->
<div id="receiptPopup" class="receipt-popup" style="display:none;">
  <div class="receipt-content">

    <h3 class="text-center mb-3">Reservation Receipt</h3>

    <div class="receipt-info">
      <p><strong>Name:</strong> <span id="r_name"></span></p>
      <p><strong>Phone:</strong> <span id="r_phone"></span></p>

      <!-- Date & Time (sudah diformat dari JS) -->
      <p><strong>Date & Time:</strong> 
        <span id="r_datetime" style="white-space:nowrap;"></span>
      </p>

      <p><strong>Guests:</strong> <span id="r_people"></span></p>
      <p><strong>Request:</strong> <span id="r_message"></span></p>
    </div>

    <!-- Alert box -->
    <div class="alert alert-success mt-3 text-center">
      Reservasi Anda telah diterima oleh restoran.
    </div>

    <!-- Warning merah -->
    <div class="receipt-warning">
      Jika meja penuh, CS kami akan menghubungi Anda melalui nomor Anda!
      <br>
      Download Bukti PDF Reservasi (opsional), lalu klik "Tutup".
    </div>

    <!-- Buttons -->
    <div class="receipt-buttons">
      <button type="button" class="btn-pdf" onclick="downloadPDF()">DOWNLOAD PDF</button>
      <button type="button" class="btn-confirm" onclick="closeReceiptPopup()">TUTUP</button>
      <button type="button" class="btn-cancel" onclick="closeReceiptPopup()">BATAL</button>
    </div>

  </div>
</div>

<script>
function closeReceiptPopup() {
  document.getElementById("receiptPopup").style.display = "none";
}
</script>



      </div>
    </div>
  </div>
</section>
<!-- Reservation Section End -->



  <!-- Video Modal -->
  <div class="modal fade" id="videoModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
      <div class="modal-content bg-dark">
        <div class="modal-body p-0">
          <div class="ratio ratio-16x9">
            <iframe id="video" src="" allowfullscreen allow="autoplay"></iframe>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script>
    function redirectToOrder() {
      window.location.href = "ordermakan.php";
    }
  </script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- Team Start -->
<div id="Chef" class="team-section container-xxl py-5">
    <div class="container">
        <div class="team-header text-center">
            <h5 class="section-subtitle">Team Members</h5>
            <h1 class="section-title">Our Master Chefs</h1>
        </div>

        <?php
        // TEAM (Chef) - terintegrasi dengan ADMIN + DB
        // Catatan: beberapa user masih punya tabel karyawan versi lama (tanpa kolom is_chef/visible)
        // sehingga query bisa fatal error. Di bawah ini dibuat lebih aman.

        include "ADMIN/koneksi.php"; // pakai koneksi yang sama dengan ADMIN

        // alias jika ada file lama pakai $koneksi
        if (!isset($conn) && isset($koneksi)) { $conn = $koneksi; }

        // ambil daftar kolom supaya query tidak error jika kolom belum ada
        $cols = [];
        if ($conn instanceof mysqli) {
          if ($resCols = $conn->query("SHOW COLUMNS FROM karyawan")) {
            while ($c = $resCols->fetch_assoc()) { $cols[] = $c['Field']; }
            $resCols->free();
          }
        }

        $where = [];
        if (in_array('is_chef', $cols, true)) $where[] = "is_chef = 1";
        if (in_array('visible', $cols, true)) $where[] = "visible = 1";

        $sqlTeam = "SELECT * FROM karyawan";
        if (!empty($where)) $sqlTeam .= " WHERE " . implode(" AND ", $where);
        $sqlTeam .= " ORDER BY id DESC";

        $query = ($conn instanceof mysqli) ? $conn->query($sqlTeam) : false;
        ?>

        <div class="row g-4">
            <?php if ($query && $query->num_rows > 0) { while ($row = $query->fetch_assoc()) { ?>
                <div class="col-lg-3 col-md-6">
                    <div class="team-card">
                        <div class="team-img">
                            <?php
                              $img = !empty($row['image']) ? ('uploads/' . ltrim($row['image'], '/')) : 'img/team-1.jpg';
                            ?>
                            <img src="<?= htmlspecialchars($img, ENT_QUOTES) ?>" alt="<?= htmlspecialchars($row['nama'] ?? 'Team', ENT_QUOTES) ?>">
                        </div>
                        <div class="team-info">
                            <h5><?= $row['nama']; ?></h5>
                            <p><?= $row['posisi']; ?></p>
                            <div class="social-links">
                                <a href="#"><i class="fab fa-facebook-f"></i></a>
                                <a href="#"><i class="fab fa-twitter"></i></a>
                                <a href="#"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php } } else { ?>
              <div class="col-12">
                <div class="alert alert-warning text-center" style="border-radius:14px;">
                  Data team belum ada / belum ditandai sebagai <b>Chef</b> di admin.
                </div>
              </div>
            <?php } ?>
        </div>

    </div>
</div>
<!-- Team End -->


<?php
// Sambungkan ke database
require_once __DIR__ . '/ADMIN/koneksi.php';
// jika koneksi.php memakai $mysqli, kita set agar index bisa pakai $conn
if (!isset($conn) && isset($mysqli)) {
    $conn = $mysqli;
}

// ---------------------------
// Ambil 4 rating terbaru (tabel `reviews` sudah dihapus)
// Sumber: order_ratings JOIN pesanan_masuk
// ---------------------------
$reviews = [];

$sql = "SELECT p.pelanggan AS name,
               r.rating    AS star,
               r.saran     AS comment,
               r.created_at AS time
        FROM order_ratings r
        JOIN pesanan_masuk p ON p.id = r.order_id
        ORDER BY r.id DESC
        LIMIT 4";

$result4 = $mysqli->query($sql);
if ($result4) {
  while ($row = $result4->fetch_assoc()) {
    $reviews[] = $row;
  }
}
?>



      <!-- === Testimonial Start === -->
<div id="Testimoni" class="container-xxl py-5 wow fadeInUp" data-wow-delay="0.1s">
  <div class="container">
    <!-- Judul Section -->
    <div class="text-center mb-5">
      <h5 class="section-title ff-secondary text-primary fw-normal">Testimonial</h5>
      <h1 class="fw-bold mb-4">Apa Kata Pelanggan Kami</h1>
      <p class="text-muted">Beberapa ulasan jujur dari pelanggan yang telah menikmati cita rasa Nusantara kami 🍽️</p>
    </div>

    <!-- Carousel -->
    <div class="owl-carousel testimonial-carousel">

      <?php if (!empty($reviews)): ?>
        <?php foreach ($reviews as $r): ?>
          <div class="testimonial-item bg-transparent border rounded p-4 text-center">
            <i class="fa fa-quote-left fa-2x text-primary mb-3"></i>

            <p>"<?= htmlspecialchars($r['comment']) ?>"</p>

            <!-- Rating bintang -->
            <div class="mb-2">
              <?php for ($i = 1; $i <= 5; $i++): ?>
                <i class="fa <?= $i <= (int)$r['star'] ? 'fa-star text-warning' : 'fa-star-o text-muted' ?>"></i>
              <?php endfor; ?>
            </div>

            <div class="d-flex align-items-center justify-content-center mt-3">
              <!-- Avatar huruf depan nama -->
              <div class="flex-shrink-0 rounded-circle bg-primary d-flex align-items-center justify-content-center text-white fw-bold"
                   style="width: 60px; height: 60px;">
                <?php
                  // huruf pertama nama, dukung nama Indonesia
                  echo strtoupper(mb_substr($r['name'], 0, 1, 'UTF-8'));
                ?>
              </div>
              <div class="ps-3 text-start">
                <h5 class="mb-1"><?= htmlspecialchars($r['name']) ?></h5>
                <small>Customer</small>
              </div>
            </div>
          </div>
        <?php endforeach; ?>

      <?php else: ?>
        <!-- Fallback kalau belum ada review di database -->
        <div class="testimonial-item bg-transparent border rounded p-4 text-center">
          <i class="fa fa-quote-left fa-2x text-primary mb-3"></i>
          <p>"Belum ada ulasan pelanggan untuk saat ini."</p>
          <div class="d-flex align-items-center justify-content-center mt-3">
            <div class="flex-shrink-0 rounded-circle bg-secondary d-flex align-items-center justify-content-center text-white fw-bold"
                 style="width: 60px; height: 60px;">
              🙂
            </div>
            <div class="ps-3 text-start">
              <h5 class="mb-1">Customer</h5>
              <small>Menunggu review pertama</small>
            </div>
          </div>
        </div>
      <?php endif; ?>

    </div>
<!-- === Testimonial End === -->


        </div>
</div>
</div>
</div>
<!-- Footer Start -->
        <div id="targetService" class="bg-dark text-light footer pt-5 mt-5 wow fadeIn" data-wow-delay="0.1s">
            <div class="container py-5">
                <div class="row g-5">
                    <div class="col-lg-3 col-md-6">
                        <h4 class="section-title ff-secondary text-start text-primary fw-normal mb-4">Company</h4>
                        <a class="btn btn-link" href="about.php">About Us</a>
                        <a class="btn btn-link" href="contactus.php">Contact Us</a>
                        <a class="btn btn-link" href="index.php#reservasi">Reservation</a>
                        <a class="btn btn-link" href="index.php#Chef">Chef</a>
                        <a class="btn btn-link" href="index.php#Testimoni">Rating Customer</a>

                    </div>
                    <div class="col-lg-3 col-md-6">
                        <h4 class="section-title ff-secondary text-start text-primary fw-normal mb-4">Contact</h4>
                        <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>Jalan Taman Gapura, Citraland nomor 07, Surabaya</p>
                        <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>+6287798765432</p>
                        <p class="mb-2"><i class="fa fa-envelope me-3"></i>@derasa.restaurant</p>
                        <div class="d-flex pt-2">
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-youtube"></i></a>
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-linkedin-in"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <h4 class="section-title ff-secondary text-start text-primary fw-normal mb-4">Opening</h4>
                        <h5 class="text-light fw-normal">Monday - Saturday</h5>
                        <p>09AM - 09PM</p>
                        <h5 class="text-light fw-normal">Sunday</h5>
                        <p>10AM - 08PM</p>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <h4 class="section-title ff-secondary text-start text-primary fw-normal mb-4">Newsletter</h4>
                        <p>Terimakasih atas kunjungan anda, sampai jumpaa!</p>
                        <div class="position-relative mx-auto" style="max-width: 400px;">
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="copyright">
                    <div class="row">
                        <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
        <p>&copy; 2025 Derasa Restaurant. All Rights Reserved.</p>
      </div>
    </div>
  </div>
        <!-- Footer End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>



    <!-- Template Javascript -->
    <script src="js/main.js"></script>
    <script>
      // Jika user submit tanpa AJAX (fallback), tampilkan notifikasi dari query string
      (function(){
        try{
          const p = new URLSearchParams(window.location.search);
          const ok = p.get('ok');
          const msg = p.get('msg');
          if (ok === '1') {
            if (window.showReservationToast) window.showReservationToast('Reservasi berhasil!', msg || 'Kami akan menghubungi Anda.', 'success');
          } else if (ok === '0' && msg) {
            if (window.showReservationToast) window.showReservationToast('Reservasi gagal', msg, 'error');
          }
        }catch(e){}
      })();
    </script>
    <!-- NOTE: Jangan load script admin di halaman user karena bisa override fungsi reservation (submitReservation/showReservationPopup) -->

    <?php
if (isset($mysqli)) {
    $mysqli->close();
}
?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>

</body>
</html>