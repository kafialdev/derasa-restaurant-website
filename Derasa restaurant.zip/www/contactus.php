 <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Restoran - DeRasa</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">


    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    

</head>

<body>
  <div class="container-xxl bg-white p-0">

<!-- Navbar & Hero Start -->
<div class="container-xxl position-relative p-0 fade-anim">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark px-4 px-lg-5 py-3 py-lg-0">
        
        <!-- LOGO -->
        <a href="index.php" class="navbar-brand p-0">
            <h1 class="text-primary m-0">
                <i class="fa fa-utensils me-3"></i>DeRasa
            </h1>
        </a>

        <!-- TOGGLER -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarCollapse">
            <span class="fa fa-bars"></span>
        </button>

        <!-- MENU -->
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav ms-auto py-0 pe-4">
                <a href="index.php" class="nav-item nav-link">Home</a>
                <a href="about.php" class="nav-item nav-link">About</a>
                <a href="contactus.php" class="nav-item nav-link active">Contact Us</a>
                <a href="menu.php" class="nav-item nav-link">Menu</a>
            </div>

            <!-- BUTTON (scroll ke reservation section di INDEX) -->
            <a href="index.php#reservasi" class="btn btn-primary py-2 px-4">
                Book A Table
            </a>
        </div>

    </nav>

<!-- HERO HEADER -->
<div class="container-xxl py-5 bg-dark hero-header mb-5">
    <div class="container text-center my-5 pt-5 pb-4 hero-anim">

        <h1 class="display-3 text-white mb-3">Contact Derasa</h1>

        <nav aria-label="breadcrumb">
            <ol class="breadcrumb justify-content-center text-uppercase">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                <li class="breadcrumb-item text-white active" aria-current="page">contact</li>
            </ol>
        </nav>

    </div>
</div>

<!-- Contact Section -->
<section class="contact-section">
  <div class="container">
    <div class="contact-wrapper">

      <!-- Info Kiri -->
      <div class="contact-info">
        <h4>Contact Information</h4>
        <p>Jika Anda memiliki pertanyaan, masukan, atau membutuhkan bantuan, tim kami dengan senang hati akan membantu Anda.
        Silakan hubungi kami melalui formulir, telepon, atau kunjungi langsung restoran kami.</p>
      <p><i class="fas fa-phone-alt"></i> 📞 0812-1111-8456</p>
      <p><i class="fas fa-envelope"></i> 📧 derasarestaurant@gmail.com</p>
      <p><i class="fas fa-map-marker-alt"></i> 📍 Jalan Taman Gapura, Citraland No. 07, Surabaya</p>
      </div>

      <!-- Form Kanan -->
      <form class="contact-form" method="POST" action="ADMIN/contact/contact_proses.php">
        <div class="mb-3">
          <label for="name">Name</label>
          <input type="text" name="name" id="name" placeholder="Your Name" required>
        </div>

        <div class="mb-3">
          <label for="email">Email</label>
          <input type="email" name="email" id="email" placeholder="Your Email" required>
        </div>

        <div class="mb-3">
          <label for="phone">Phone Number</label>
          <input type="text" name="phone" id="phone" placeholder="Your Phone Number">
        </div>

        <div class="mb-3">
          <label for="message">Message</label>
          <textarea name="message" id="message" rows="4" placeholder="Your Message" required></textarea>
        </div>

        <button type="submit">SEND</button>
      </form>

    </div>
  </div>
</section>

        <!-- Footer Start -->
        <div id="targetService" class="bg-dark text-light footer pt-5 mt-5 wow fadeIn" data-wow-delay="0.1s">
            <div class="container py-5">
                <div class="row g-5">
                    <div class="col-lg-3 col-md-6">
                        <h4 class="section-title ff-secondary text-start text-primary fw-normal mb-4">Company</h4>
                        <a class="btn btn-link" href="about.php">About Us</a>
                        <a class="btn btn-link" href="contactus.php">Contact Us</a>
                        <a class="btn btn-link" href="index.php#reservasi">Reservation</a>
                        <a class="btn btn-link" href="index.php#Chef">Chef</a>
                        <a class="btn btn-link" href="index.php#Testimoni">Rating Customer</a>

                    </div>
                    <div class="col-lg-3 col-md-6">
                        <h4 class="section-title ff-secondary text-start text-primary fw-normal mb-4">Contact</h4>
                        <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>Jalan Taman Gapura, Citraland nomor 07, Surabaya</p>
                        <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>+6287798765432</p>
                        <p class="mb-2"><i class="fa fa-envelope me-3"></i>@derasa.restaurant</p>
                        <div class="d-flex pt-2">
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-youtube"></i></a>
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-linkedin-in"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <h4 class="section-title ff-secondary text-start text-primary fw-normal mb-4">Opening</h4>
                        <h5 class="text-light fw-normal">Monday - Saturday</h5>
                        <p>09AM - 09PM</p>
                        <h5 class="text-light fw-normal">Sunday</h5>
                        <p>10AM - 08PM</p>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <h4 class="section-title ff-secondary text-start text-primary fw-normal mb-4">Newsletter</h4>
                        <p>Terimakasih atas kunjungan anda, sampai jumpaa!</p>
                        <div class="position-relative mx-auto" style="max-width: 400px;">
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="copyright">
                    <div class="row">
                        <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
							
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Footer End -->

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="lib/wow/wow.min.js"></script>

<!-- ✅ FIX: counterUp error -->
<script>
  jQuery.fn.counterUp = jQuery.fn.counterUp || function(){ return this; };
</script>

<script src="js/main.js"></script>

</body>
</html>
