<?php
require_once 'koneksi.php'; // $conn (mysqli)

// ===============================
// VALIDASI REQUEST
// ===============================
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die('Akses tidak valid');
}

// ===============================
// AMBIL & AMANKAN DATA FORM
// ===============================
$pelanggan          = trim($_POST['pelanggan'] ?? '');
$metode_pembayaran  = trim($_POST['metode_pembayaran'] ?? '');
$status             = trim($_POST['status'] ?? 'pending');
$catatan            = trim($_POST['catatan'] ?? '');
$total              = (int) ($_POST['total'] ?? 0);

// validasi wajib
if ($pelanggan === '' || $total <= 0) {
    echo "<script>
        alert('❌ Data pesanan tidak lengkap');
        history.back();
    </script>";
    exit;
}

// waktu sekarang
$waktu = date('Y-m-d H:i:s');

// ===============================
// SIMPAN KE DATABASE (AMAN)
// ===============================
$stmt = $conn->prepare("
    INSERT INTO pesanan_masuk
    (waktu, pelanggan, metode_pembayaran, status, catatan, total)
    VALUES (?, ?, ?, ?, ?, ?)
");

$stmt->bind_param(
    "sssssi",
    $waktu,
    $pelanggan,
    $metode_pembayaran,
    $status,
    $catatan,
    $total
);

try {
    $stmt->execute();
    $order_id = $stmt->insert_id;

    echo "<script>
        alert('✅ Pesanan berhasil disimpan!');
        window.location.href = 'ADMIN/pesananmasuk.php';
    </script>";

} catch (Exception $e) {
    echo "<script>
        alert('❌ Gagal menyimpan pesanan');
        console.error(" . json_encode($e->getMessage()) . ");
        history.back();
    </script>";
}

$stmt->close();
$conn->close();
