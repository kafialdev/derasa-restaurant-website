<?php
header("Content-Type: application/json");
error_reporting(0);
ini_set("display_errors", 0);

require_once __DIR__ . '/../koneksi.php';

/*
 ────────────────────────────────────────────────
  PARAMETER:
  - q = pencarian nama menu
  - kategori = filter kategori (Makanan / Minuman / Snack)
 ────────────────────────────────────────────────
*/

$q = isset($_GET['q']) ? trim($_GET['q']) : '';
$kategori = isset($_GET['kategori']) ? trim($_GET['kategori']) : '';

$sql = "
    SELECT 
        id,
        nama_menu,
        kategori,
        harga,
        stok,
        status,
        deskripsi,
        gambar
    FROM menu_restaurant
    WHERE 1
";

/* ────────────────────────────────────────────────
   FILTER KATEGORI (untuk Web Pelanggan)
──────────────────────────────────────────────── */
if ($kategori !== '') {
    $sql .= " AND kategori = ? ";
}

/* ────────────────────────────────────────────────
   FILTER PENCARIAN (untuk Admin)
──────────────────────────────────────────────── */
if ($q !== '') {
    $sql .= " AND nama_menu LIKE CONCAT('%', ?, '%')";
}

/* ────────────────────────────────────────────────
   BUILD PREPARED STATEMENT
──────────────────────────────────────────────── */
$params = [];
$types = "";

if ($kategori !== '') {
    $types .= "s";
    $params[] = &$kategori;
}

if ($q !== '') {
    $types .= "s";
    $params[] = &$q;
}

$stmt = $mysqli->prepare($sql);

if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$res = $stmt->get_result();

/* ────────────────────────────────────────────────
   KONVERSI & PERAPIHAN DATA
──────────────────────────────────────────────── */
$data = [];

while ($row = $res->fetch_assoc()) {

    // jika status null, isi kosong
    if (!isset($row['status']) || $row['status'] === null) {
        $row['status'] = "";
    }

    // konversi angka ke label
    if ($row['status'] === "0") {
        $row['status'] = "Habis";
    } elseif ($row['status'] === "1") {
        $row['status'] = "Tersedia";
    }

    $data[] = $row;
}

/* ────────────────────────────────────────────────
   RESPONSE JSON
──────────────────────────────────────────────── */

echo json_encode([
    "ok" => true,
    "data" => $data
]);

exit;
?>
