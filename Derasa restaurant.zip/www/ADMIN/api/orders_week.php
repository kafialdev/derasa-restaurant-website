<?php
require_once __DIR__ . '/../koneksi.php';

// jumlah hari, default 7
$days = isset($_GET['days']) ? (int)$_GET['days'] : 7;

$sql = "
    SELECT DATE(completed_at) AS tgl, COUNT(*) AS jumlah
    FROM orders
    WHERE status = 'selesai'
      AND completed_at >= DATE(NOW()) - INTERVAL $days DAY
    GROUP BY DATE(completed_at)
    ORDER BY tgl ASC
";

$q = $conn->query($sql);

$data = [];
while($row = $q->fetch_assoc()){
    $data[] = $row;
}

echo json_encode([
    "status" => "success",
    "days" => $days,
    "data" => $data
]);
