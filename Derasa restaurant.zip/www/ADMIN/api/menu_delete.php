<?php
header('Content-Type: application/json');
error_reporting(0);
ini_set('display_errors', 0);
require_once __DIR__ . '/../koneksi.php'; 


$raw = file_get_contents('php://input');
$body = json_decode($raw, true);
$id = (int)($body['id'] ?? 0);
if ($id<=0) { echo json_encode(["ok"=>false, "error"=>"ID invalid"]); exit; }

$stmt = $mysqli->prepare("DELETE FROM menu_restaurant WHERE id=?");
$stmt->bind_param('i', $id);
$ok = $stmt->execute();
echo json_encode(["ok"=>$ok, "error"=>$ok?null:$mysqli->error]);
