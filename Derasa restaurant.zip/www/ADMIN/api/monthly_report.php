<?php
require_once __DIR__ . '/../koneksi.php';
session_start();

$thisMonth = date("Y-m");

if (!isset($_SESSION['last_month'])) {
    $_SESSION['last_month'] = $thisMonth;
}

$shouldCreate = false;

if ($_SESSION['last_month'] != $thisMonth) {
    $shouldCreate = true;
    $_SESSION['last_month'] = $thisMonth;

    // ambil data laporan bulan lalu
    $lastMonth = date("Y-m", strtotime("-1 month"));

    $sql = "
        SELECT COUNT(*) AS total_order,
               SUM(total_harga) AS total_revenue
        FROM orders
        WHERE status = 'selesai'
          AND DATE_FORMAT(completed_at, '%Y-%m') = '$lastMonth'
    ";

    $report = $conn->query($sql)->fetch_assoc();

    // simpan laporan
    $conn->query("
        INSERT INTO laporan_bulanan (bulan, total_order, total_revenue)
        VALUES ('$lastMonth', '{$report['total_order']}', '{$report['total_revenue']}')
    ");
}

echo json_encode([
    "create_report" => $shouldCreate,
    "month" => $thisMonth
]);
