<?php
session_start();

$todayWeek = date("W");  // nomor minggu sekarang

if (!isset($_SESSION['last_week'])) {
    $_SESSION['last_week'] = $todayWeek;
}

$shouldReset = false;

if ($_SESSION['last_week'] != $todayWeek) {
    $shouldReset = true;
    $_SESSION['last_week'] = $todayWeek;
}

echo json_encode([
    "reset" => $shouldReset,
    "week"  => $todayWeek
]);
