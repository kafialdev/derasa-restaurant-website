<?php
// /ADMIN/api/menu_create.php
header('Content-Type: application/json; charset=utf-8');

error_reporting(E_ALL);
// Saat hosting, lebih aman tidak menampilkan error mentah
ini_set('display_errors', 0);

require_once __DIR__ . '/../koneksi.php';

function json_out(bool $ok, ?string $error = null, array $extra = []): void {
  echo json_encode(array_merge([
    'ok' => $ok,
    'error' => $ok ? null : ($error ?? 'Terjadi kesalahan')
  ], $extra));
  exit;
}

/**
 * Simpan gambar dari base64 data URL ke folder /ADMIN/uploads
 * Return: nama file yang disimpan (tanpa path), atau null jika tidak ada gambar.
 */
function save_menu_image_from_base64(?string $imgBase64): ?string {
  $imgBase64 = $imgBase64 ? trim($imgBase64) : '';
  if ($imgBase64 === '') return null;

  if (!preg_match('#^data:image/([a-zA-Z0-9.+-]+);base64,#', $imgBase64, $m)) {
    // jika bukan format data URL, abaikan (biar tidak error)
    return null;
  }

  // decode base64
  $raw = substr($imgBase64, strpos($imgBase64, ',') + 1);
  $bin = base64_decode($raw, true);
  if ($bin === false) {
    json_out(false, 'Base64 gambar tidak valid');
  }

  // batas ukuran 5MB (bisa disesuaikan)
  if (strlen($bin) > 5 * 1024 * 1024) {
    json_out(false, 'Ukuran gambar terlalu besar (maks 5MB)');
  }

  // validasi benar-benar gambar
  $imgInfo = @getimagesizefromstring($bin);
  if ($imgInfo === false || empty($imgInfo['mime'])) {
    json_out(false, 'File yang diunggah bukan gambar yang valid');
  }

  $mime = strtolower($imgInfo['mime']);
  $extMap = [
    'image/jpeg' => 'jpg',
    'image/jpg'  => 'jpg',
    'image/png'  => 'png',
    'image/gif'  => 'gif',
    'image/webp' => 'webp',
  ];
  $ext = $extMap[$mime] ?? 'jpg';

  $uploadsDir = dirname(__DIR__) . '/uploads';
  if (!is_dir($uploadsDir)) {
    // 0755 aman untuk hosting, 0777 sering diblokir/dianggap tidak aman
    @mkdir($uploadsDir, 0755, true);
  }

  // fallback kalau mkdir gagal (misal permission)
  if (!is_dir($uploadsDir) || !is_writable($uploadsDir)) {
    json_out(false, 'Folder uploads tidak bisa ditulis. Pastikan permission folder /ADMIN/uploads sudah benar.');
  }

  $fname = 'menu_' . date('Ymd_His') . '_' . bin2hex(random_bytes(6)) . '.' . $ext;
  $abs   = $uploadsDir . '/' . $fname;

  if (file_put_contents($abs, $bin) === false) {
    json_out(false, 'Gagal menyimpan file gambar di server');
  }

  return $fname;
}

// -----------------------------
// BACA PAYLOAD JSON
// -----------------------------
$data = json_decode(file_get_contents('php://input'), true);
if (!$data) {
  json_out(false, 'Payload tidak valid (JSON)');
}

$nama     = trim($data['name'] ?? '');
$kategori = trim($data['category'] ?? 'Makanan');
$harga    = (int)($data['price'] ?? 0);
$stok     = (int)($data['stock'] ?? 0);
$status   = trim($data['status'] ?? 'Tersedia');
$desk     = trim($data['desc'] ?? '');
$imgBase  = $data['img'] ?? null;

if ($nama === '' || $kategori === '' || $harga <= 0) {
  json_out(false, 'Nama, kategori, dan harga wajib diisi');
}

// simpan gambar (jika ada), lalu simpan NAMA FILE saja ke DB
$imgFileName = save_menu_image_from_base64($imgBase);

// -----------------------------
// INSERT KE DATABASE
// -----------------------------
$stmt = $mysqli->prepare("
  INSERT INTO menu_restaurant (nama_menu, kategori, harga, stok, status, deskripsi, gambar)
  VALUES (?,?,?,?,?,?,?)
");
if (!$stmt) {
  json_out(false, 'Prepare query gagal');
}

$stmt->bind_param(
  "ssiisss",
  $nama,
  $kategori,
  $harga,
  $stok,
  $status,
  $desk,
  $imgFileName
);

$ok = $stmt->execute();
if (!$ok) {
  json_out(false, $stmt->error);
}

json_out(true, null, ['id' => $stmt->insert_id, 'gambar' => $imgFileName]);
