<?php
// /ADMIN/api/menu_update.php
header('Content-Type: application/json; charset=utf-8');

error_reporting(E_ALL);
ini_set('display_errors', 0);

require_once __DIR__ . '/../koneksi.php';

function json_out(bool $ok, ?string $error = null, array $extra = []): void {
  echo json_encode(array_merge([
    'ok' => $ok,
    'error' => $ok ? null : ($error ?? 'Terjadi kesalahan')
  ], $extra));
  exit;
}

/**
 * Normalisasi nilai gambar lama (bisa berupa /ADMIN/uploads/xxx.jpg, ADMIN/uploads/xxx.jpg, uploads/xxx.jpg, atau hanya filename).
 * Return: filename saja.
 */
function normalize_old_image_to_filename(?string $val): ?string {
  $val = $val ? trim($val) : '';
  if ($val === '') return null;

  // jika URL penuh, ambil basename saja
  $val = preg_replace('#\\?.*$#', '', $val); // buang query string jika ada
  $base = basename($val);
  return $base ?: null;
}

function save_menu_image_from_base64(?string $imgBase64): ?string {
  $imgBase64 = $imgBase64 ? trim($imgBase64) : '';
  if ($imgBase64 === '') return null;

  if (!preg_match('#^data:image/([a-zA-Z0-9.+-]+);base64,#', $imgBase64)) {
    return null;
  }

  $raw = substr($imgBase64, strpos($imgBase64, ',') + 1);
  $bin = base64_decode($raw, true);
  if ($bin === false) json_out(false, 'Base64 gambar tidak valid');

  if (strlen($bin) > 5 * 1024 * 1024) {
    json_out(false, 'Ukuran gambar terlalu besar (maks 5MB)');
  }

  $imgInfo = @getimagesizefromstring($bin);
  if ($imgInfo === false || empty($imgInfo['mime'])) {
    json_out(false, 'File yang diunggah bukan gambar yang valid');
  }

  $mime = strtolower($imgInfo['mime']);
  $extMap = [
    'image/jpeg' => 'jpg',
    'image/jpg'  => 'jpg',
    'image/png'  => 'png',
    'image/gif'  => 'gif',
    'image/webp' => 'webp',
  ];
  $ext = $extMap[$mime] ?? 'jpg';

  $uploadsDir = dirname(__DIR__) . '/uploads';
  if (!is_dir($uploadsDir)) {
    @mkdir($uploadsDir, 0755, true);
  }
  if (!is_dir($uploadsDir) || !is_writable($uploadsDir)) {
    json_out(false, 'Folder uploads tidak bisa ditulis. Pastikan permission folder /ADMIN/uploads sudah benar.');
  }

  $fname = 'menu_' . date('Ymd_His') . '_' . bin2hex(random_bytes(6)) . '.' . $ext;
  $abs   = $uploadsDir . '/' . $fname;

  if (file_put_contents($abs, $bin) === false) {
    json_out(false, 'Gagal menyimpan file gambar di server');
  }

  return $fname;
}

// -----------------------------
// BACA PAYLOAD JSON
// -----------------------------
$data = json_decode(file_get_contents('php://input'), true);
if (!$data) {
  json_out(false, 'Payload tidak valid');
}

$id       = (int)($data['id'] ?? 0);
$nama     = trim($data['name'] ?? '');
$kategori = trim($data['category'] ?? '');
$harga    = (int)($data['price'] ?? 0);
$status   = trim($data['status'] ?? 'Tersedia');
$stok     = (int)($data['stock'] ?? 0);
$desk     = trim($data['desc'] ?? '');
$imgBase  = $data['img'] ?? null;

if ($id <= 0 || $nama === '' || $kategori === '' || $harga <= 0) {
  json_out(false, 'Data wajib tidak lengkap');
}

// Ambil gambar lama (untuk dihapus jika diganti)
$oldImg = null;
$stmtOld = $conn->prepare('SELECT gambar FROM menu_restaurant WHERE id = ? LIMIT 1');
$stmtOld->bind_param('i', $id);
$stmtOld->execute();
$resOld = $stmtOld->get_result();
if ($row = $resOld->fetch_assoc()) {
  $oldImg = $row['gambar'] ?? null;
}
$stmtOld->close();

$oldFileName = normalize_old_image_to_filename($oldImg);

// Simpan gambar baru (opsional)
$newFileName = save_menu_image_from_base64($imgBase);

// Jika ada gambar baru, update juga kolom gambar (yang disimpan: filename saja)
if ($newFileName) {
  $stmt = $conn->prepare('UPDATE menu_restaurant SET nama_menu=?, harga=?, kategori=?, status=?, stok=?, deskripsi=?, gambar=? WHERE id=?');
  $stmt->bind_param('sississi', $nama, $harga, $kategori, $status, $stok, $desk, $newFileName, $id);
} else {
  $stmt = $conn->prepare('UPDATE menu_restaurant SET nama_menu=?, harga=?, kategori=?, status=?, stok=?, deskripsi=? WHERE id=?');
  $stmt->bind_param('sissisi', $nama, $harga, $kategori, $status, $stok, $desk, $id);
}

$ok = $stmt->execute();
if (!$ok) {
  json_out(false, $stmt->error);
}
$stmt->close();

// Hapus file lama jika diganti
if ($newFileName && $oldFileName) {
  $uploadsDir = dirname(__DIR__) . '/uploads';
  $oldAbs = $uploadsDir . '/' . $oldFileName;
  // hanya hapus kalau memang file ada di folder uploads kita
  if (is_file($oldAbs)) {
    @unlink($oldAbs);
  }
}

json_out(true, null, ['gambar' => $newFileName ?: $oldFileName]);
