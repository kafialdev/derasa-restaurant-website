<?php
require_once __DIR__ . '/../koneksi.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $name     = $_POST["name"] ?? '';
    $email    = $_POST["email"] ?? '';
    $phone    = $_POST["phone"] ?? '';
    $message  = $_POST["message"] ?? '';

    if ($name === "" || $email === "" || $message === "") {
        echo "<script>alert('Semua field wajib diisi!');
              window.history.back();</script>";
        exit;
    }

    $stmt = $mysqli->prepare("
        INSERT INTO contact_messages (name, email, phone, message, created_at)
        VALUES (?, ?, ?, ?, NOW())
    ");

    $stmt->bind_param("ssss", $name, $email, $phone, $message);

if ($stmt->execute()) {
    echo "<script>
            alert('Pesan anda telah tersampaikan! Jika ada respon, CS kami akan menghubungi Anda.');
            window.location.href='../../index.php';
          </script>";
} else {
    echo 'SQL Error: ' . $stmt->error;
}

    $stmt->close();
}
?>
