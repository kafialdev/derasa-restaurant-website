<?php
require_once __DIR__ . '/../koneksi.php';

$id = $_GET['id'] ?? 0;

if ($id > 0) {
    $mysqli->query("DELETE FROM contact_messages WHERE id = $id");
}

echo "<script>alert('Pesan berhasil dihapus'); window.location.href='contact_list.php';</script>";
