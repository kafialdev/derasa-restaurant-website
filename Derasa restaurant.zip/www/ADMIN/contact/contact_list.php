<?php
require_once __DIR__ . '/../koneksi.php';

// Ambil data
$result = $mysqli->query("SELECT * FROM contact_messages ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Data Pesan Pelanggan</title>

<!-- Google Font -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>
    body {
        font-family: "Poppins", sans-serif;
        background: linear-gradient(135deg, #e8f0ff 0%, #f4f7ff 100%);
        margin: 0;
        padding: 0;
        overflow-x: hidden;
    }

    /* HEADER BOX */
    .title-box {
        width: 90%;
        margin: 40px auto 25px auto;
        background: linear-gradient(90deg, #0f50d4, #2f7dff);
        padding: 22px 30px;
        border-radius: 18px;
        color: white;
        display: flex;
        align-items: center;
        gap: 15px;
        font-size: 22px;
        font-weight: 600;
        box-shadow: 0 10px 25px rgba(0,0,0,0.15);
        animation: slideDown 0.6s ease-out;
    }

    .title-icon {
        font-size: 32px;
        animation: bounce 1.5s infinite;
    }

    @keyframes bounce {
        0%,100% { transform: translateY(0); }
        50% { transform: translateY(-6px); }
    }

    @keyframes slideDown {
        from { opacity: 0; transform: translateY(-20px); }
        to { opacity: 1; transform: translateY(0); }
    }

    /* WRAPPER CARD */
    .table-wrapper {
        width: 90%;
        margin: auto;
        background: #ffffff;
        padding: 25px;
        border-radius: 18px;
        box-shadow: 0 12px 40px rgba(0,0,0,0.12);
        animation: fadeIn 0.8s ease-out;
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }

    /* TABLE */
    table {
        width: 100%;
        border-collapse: collapse;
        overflow: hidden;
        border-radius: 12px;
    }

    thead {
        background: #0945b8;
        color: white;
    }

    thead th {
        padding: 15px;
        font-size: 15px;
        font-weight: 600;
        letter-spacing: .3px;
    }

    tbody tr {
        animation: fadeRow 0.6s ease;
    }

    @keyframes fadeRow {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }

    tbody td {
        padding: 15px;
        font-size: 14px;
        border-bottom: 1px solid #eef2ff;
    }

    tbody tr:hover {
        background: #e9f1ff;
        transition: .25s;
    }

    /* FEEDBACK BUTTON */
    .btn-feedback {
        background: #1e90ff;
        border: none;
        padding: 7px 14px;
        border-radius: 8px;
        color: white;
        cursor: pointer;
        font-size: 13px;
        font-weight: 600;
        transition: .3s;
        margin-right: 6px;
    }
    .btn-feedback:hover {
        background: #1673d4;
        transform: scale(1.05);
    }

    /* DELETE BUTTON */
    .btn-delete {
        background: #ff4a4a;
        border: none;
        padding: 7px 14px;
        border-radius: 8px;
        color: white;
        cursor: pointer;
        font-size: 13px;
        font-weight: 600;
        transition: .3s;
    }

    .btn-delete:hover {
        background: #d93838;
        transform: scale(1.05);
        animation: shake .3s;
    }

    @keyframes shake {
        0% { transform: translateX(0); }
        25% { transform: translateX(-2px); }
        50% { transform: translateX(2px); }
        100% { transform: translateX(0); }
    }

    /* MODAL */
    .modal-bg {
        display: none;
        position: fixed;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.45);
        z-index: 99;
        align-items: center;
        justify-content: center;
    }

    .modal-box {
        width: 420px;
        background: #fff;
        padding: 25px;
        border-radius: 15px;
        box-shadow: 0 8px 20px rgba(0,0,0,0.15);
        animation: fadeIn .4s ease-out;
    }

    .modal-box h3 {
        margin-top: 0;
        font-size: 20px;
        font-weight: 600;
        color: #0f50d4;
    }

    .modal-box textarea {
        width: 100%;
        height: 120px;
        padding: 10px;
        border-radius: 10px;
        border: 1px solid #cdd6f8;
        resize: none;
        font-family: "Poppins";
    }

    .modal-buttons {
        margin-top: 15px;
        display: flex;
        justify-content: flex-end;
        gap: 10px;
    }

    .btn-close {
        background: #aaa;
        border: none;
        padding: 7px 15px;
        border-radius: 8px;
        color: white;
        cursor: pointer;
    }

    .btn-send-feedback {
        background: #1e90ff;
        border: none;
        padding: 7px 15px;
        border-radius: 8px;
        color: white;
        cursor: pointer;
        font-weight: 600;
    }

    .no-data {
        text-align: center;
        padding: 25px;
        font-size: 16px;
        color: #555;
    }
.btn-back{
        margin-left:auto;
        background: rgba(255,255,255,0.25);
        border: 1px solid rgba(255,255,255,0.45);
        padding: 10px 14px;
        border-radius: 12px;
        color: #fff;
        text-decoration: none;
        font-weight: 600;
        font-size: 14px;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        transition: 0.2s ease;
        backdrop-filter: blur(10px);
    }
    .btn-back:hover{
        transform: translateY(-1px);
        background: rgba(255,255,255,0.35);
    }
</style>
</head>

<body>

<!-- HEADER -->
<div class="title-box">
    <div class="title-icon">📩</div>
    <div>Data Pesan Pelanggan</div>
    <a class="btn-back" href="../index.php">← Kembali</a>
</div>

<!-- TABLE -->
<div class="table-wrapper">
    <?php if ($result->num_rows > 0): ?>
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Nama</th>
                <th>Email</th>
                <th>No HP</th>
                <th>Pesan</th>
                <th>Tanggal</th>
                <th>Aksi</th>
            </tr>
        </thead>

        <tbody>
            <?php 
            $no = 1;
            while ($row = $result->fetch_assoc()): 
            ?>
            <tr>
                <td><?= $no++; ?></td>
                <td><?= htmlspecialchars($row['name']); ?></td>
                <td><?= htmlspecialchars($row['email']); ?></td>
                <td><?= htmlspecialchars($row['phone']); ?></td>
                <td><?= nl2br(htmlspecialchars($row['message'])); ?></td>
                <td><?= $row['created_at']; ?></td>
                <td>
                    <button class="btn-feedback" onclick="openFeedbackModal('<?= $row['email'] ?>')">
                        Feedback
                    </button>

                    <button class="btn-delete" onclick="hapusPesan(<?= $row['id'] ?>)">
                        Delete
                    </button>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <?php else: ?>
        <div class="no-data">Belum ada pesan dari pelanggan.</div>
    <?php endif; ?>

</div>

<!-- FEEDBACK MODAL -->
<div class="modal-bg" id="feedbackModal">
    <div class="modal-box">
        <h3>Kirim Feedback</h3>

        <p style="margin-bottom:8px;">Ke: 
            <span id="feedbackEmail" style="font-weight:600;"></span>
        </p>

        <textarea id="feedbackMessage" placeholder="Tulis balasan Anda..."></textarea>

        <div class="modal-buttons">
            <button class="btn-close" onclick="closeFeedbackModal()">Tutup</button>
            <button class="btn-send-feedback" onclick="sendFeedback()">Kirim</button>
        </div>
    </div>
</div>

<script>
function hapusPesan(id) {
    if (confirm("Yakin ingin menghapus pesan ini?")) {
        window.location.href = "delete_contact.php?id=" + id;
    }
}

let selectedEmail = "";

// OPEN MODAL
function openFeedbackModal(email) {
    selectedEmail = email;
    document.getElementById("feedbackEmail").innerText = email;
    document.getElementById("feedbackModal").style.display = "flex";
}

// CLOSE MODAL
function closeFeedbackModal() {
    document.getElementById("feedbackModal").style.display = "none";
}

// SEND FEEDBACK (AJAX)
function sendFeedback() {
    let message = document.getElementById("feedbackMessage").value;

    if (message.trim() === "") {
        alert("Isi pesan feedback terlebih dahulu!");
        return;
    }

    fetch("send_feedback.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: "email=" + encodeURIComponent(selectedEmail) +
              "&message=" + encodeURIComponent(message)
    })
    .then(res => res.text())
    .then(data => {
        alert(data);
        closeFeedbackModal();
        document.getElementById("feedbackMessage").value = "";
    });
}
</script>

</body>
</html>
