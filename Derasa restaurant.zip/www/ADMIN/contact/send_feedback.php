<?php

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email   = $_POST["email"] ?? '';
    $message = $_POST["message"] ?? '';

    if ($email == "" || $message == "") {
        echo "Gagal: Email atau pesan kosong!";
        exit;
    }

    // Subjek email
    $subject = "Feedback dari Admin Derasa Restaurant";

    // Isi pesan
    $body =
        "Halo pelanggan Derasa,\n\n".
        "Admin telah memberikan feedback atas pesan Anda:\n\n".
        "$message\n\n".
        "Terima kasih telah menghubungi kami.\n".
        "- Derasa Restaurant";

    // Header email (pengirim)
    $headers  = "From: Derasa Restaurant <noreply@derasa.com>\r\n";
    $headers .= "Reply-To: noreply@derasa.com\r\n";
    $headers .= "X-Mailer: PHP/" . phpversion();

    // Kirim
    if (mail($email, $subject, $body, $headers)) {
        echo "Feedback berhasil dikirim ke $email";
    } else {
        echo "Gagal mengirim email!";
    }

} else {
    echo "Invalid request.";
}
?>
