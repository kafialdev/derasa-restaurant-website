<?php /* /ADMIN/pendapatan.php (DB Integrated - FIX) */ ?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Pendapatan Hari Ini</title>
  <base href="./">

  <style>
    :root{
      --bg:#f6f7fb;
      --card:#ffffff;
      --ink:#1f2430;
      --muted:#6b7280;
      --primary:#3b82f6;
      --accent:#10b981;
      --danger:#ef4444;
      --ring:rgba(59,130,246,.35);
      --shadow: 0 8px 28px rgba(25,35,58,.08);
      --radius: 18px;
    }

    *{box-sizing:border-box}
    html,body{height:100%}
    body{
      margin:0;
      font-family:ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial;
      color:var(--ink);
      background:linear-gradient(180deg,#f7f9ff, #eef2ff 1200px);
    }

    .page-header{
      display:flex; align-items:center; justify-content:space-between;
      padding:24px clamp(16px,3vw,34px);
      background:linear-gradient(90deg,#4f46e5,#60a5fa);
      color:#fff;
      border-bottom-left-radius:28px; border-bottom-right-radius:28px;
      box-shadow:var(--shadow);
      gap:12px;
      flex-wrap:wrap;
    }
    .page-header h1{margin:0 0 6px 0; font-size:clamp(22px,3.4vw,36px)}
    .subtitle{margin:0; opacity:.9}

    .btn{
      background:#fff; color:#1f2937; border:1px solid #e5e7eb;
      border-radius:12px; padding:10px 14px; font-weight:600; cursor:pointer;
      box-shadow:0 4px 14px rgba(0,0,0,.06); transition:.2s;
      text-decoration:none;
      display:inline-block;
    }
    .btn:hover{transform:translateY(-1px)}
    .btn.ghost{background:transparent;border-color:#ffffff55;color:#fff}

    .container{padding:26px clamp(16px,3vw,34px); max-width:1100px; margin:0 auto}
    .kpi-grid{
      display:grid; grid-template-columns:repeat(4,1fr); gap:16px; margin-bottom:18px;
    }
    @media (max-width:980px){ .kpi-grid{grid-template-columns:repeat(2,1fr)} }
    @media (max-width:560px){ .kpi-grid{grid-template-columns:1fr} }

    .kpi-card{
      background:var(--card); border-radius:var(--radius); padding:18px 20px;
      box-shadow:var(--shadow); position:relative; overflow:hidden;
    }
    .kpi-card::after{
      content:""; position:absolute; inset:auto 0 0 0; height:4px;
      background:linear-gradient(90deg,var(--primary),var(--accent));
    }
    .kpi-label{color:var(--muted); font-weight:600}
    .kpi-value{font-size:32px; font-weight:800; margin:6px 0}
    .kpi-value.small{font-size:24px}
    .kpi-sub{color:var(--muted)}

    .toolbar{
      display:flex; align-items:center; justify-content:space-between;
      margin: 8px 0 18px 0;
      gap: 12px;
      flex-wrap: wrap;
    }
    .toolbar input[type="search"]{
      width:min(420px,90%); border:1px solid #e5e7eb; padding:12px 14px; border-radius:12px;
      outline:none; transition:.2s;
    }
    .toolbar input[type="search"]:focus{border-color:var(--primary); box-shadow:0 0 0 4px var(--ring)}

    .card{
      background:var(--card); border-radius:var(--radius); margin-bottom:18px;
      box-shadow:var(--shadow); overflow:hidden;
    }
    .card-head{
      padding:16px 18px; border-bottom:1px solid #eef2ff; display:flex; justify-content:space-between; align-items:baseline;
      gap: 8px;
      flex-wrap: wrap;
    }
    .card-head h3{margin:0}
    .card-body{padding:16px 18px}
    .muted{color:var(--muted); font-size:14px}

    .table-wrapper{overflow:auto}
    .data-table{width:100%; border-collapse:collapse}
    .data-table th, .data-table td{padding:12px 12px; border-bottom:1px solid #eef2ff}
    .data-table thead th{font-size:14px; letter-spacing:.25px; color:#4b5563; text-transform:uppercase}
    .right{text-align:right}
    .data-table tbody tr:hover{background:#fafbff}

    .toast{
      position:fixed; bottom:18px; left:50%; transform:translateX(-50%);
      background:#111827; color:#fff; padding:10px 14px; border-radius:10px;
      opacity:0; pointer-events:none; transition:.25s; box-shadow:var(--shadow);
      font-size: 14px;
      z-index: 9999;
    }
    .toast.show{opacity:1}

    .loading{
      padding:14px 16px;
      border:1px dashed #dbeafe;
      border-radius:14px;
      background:#f8fbff;
      color:#4b5563;
      margin-bottom: 16px;
    }
  </style>

  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
  <header class="page-header">
    <div class="left">
      <h1>Pendapatan Hari Ini</h1>
      <p class="subtitle" id="subtitleDate">Tanggal …</p>
    </div>
    <div class="right" style="display:flex; gap:10px; flex-wrap:wrap;">
      <button class="btn ghost" id="btnRefresh">↻ Refresh</button>
      <a class="btn ghost" href="index.php">← Kembali ke Dashboard</a>
    </div>
  </header>

  <main class="container">
    <div id="loadingBox" class="loading" style="display:none;">Memuat data dari database…</div>

    <section class="kpi-grid">
      <div class="kpi-card">
        <div class="kpi-label">Pendapatan</div>
        <div class="kpi-value" id="kpiRevenue">Rp 0</div>
        <div class="kpi-sub" id="kpiDelta">+0% dari kemarin</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Pesanan Selesai</div>
        <div class="kpi-value" id="kpiOrders">0</div>
        <div class="kpi-sub">Total transaksi hari ini</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Rata-rata Order</div>
        <div class="kpi-value" id="kpiAOV">Rp 0</div>
        <div class="kpi-sub">Average order value</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Metode Populer</div>
        <div class="kpi-value small" id="kpiPopularPay">-</div>
        <div class="kpi-sub">Hari ini</div>
      </div>
    </section>

    <section class="toolbar">
      <div class="left">
        <input id="searchInput" type="search" placeholder="Cari pelanggan / ID pesanan…" />
      </div>
      <div class="right" style="display:flex; gap:10px; flex-wrap:wrap;">
        <button class="btn" id="btnExport">Export CSV</button>
        <button class="btn" id="btnPrint">Cetak</button>
      </div>
    </section>

    <section class="card">
      <div class="card-head">
        <h3>Grafik Pendapatan per Jam</h3>
        <div id="chartNote" class="muted">–</div>
      </div>
      <div class="card-body" style="height:260px;">
        <canvas id="revenueChart"></canvas>
      </div>
    </section>

    <section class="card">
      <div class="card-head">
        <h3>Transaksi Selesai Hari Ini</h3>
        <div class="muted" id="tableCaption">0 transaksi</div>
      </div>
      <div class="card-body">
        <div class="table-wrapper">
          <table class="data-table" id="ordersTable">
            <thead>
              <tr>
                <th>Waktu</th>
                <th>ID Pesanan</th>
                <th>Pelanggan</th>
                <th>Metode</th>
                <th class="right">Total</th>
              </tr>
            </thead>
            <tbody id="ordersTbody"></tbody>
            <tfoot>
              <tr>
                <td colspan="4" class="right"><strong>Total</strong></td>
                <td class="right" id="ordersSum">Rp 0</td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </section>
  </main>

  <div id="toast" class="toast"></div>

  <script>
  (function(){
    const API_URL = "simpan_pesanan.php"; // satu sumber data (DB)
    const fmtIDR = n => `Rp ${Number(n||0).toLocaleString('id-ID')}`;

    let allCompletedFromDB = [];      // semua completed dari DB (bisa banyak tanggal)
    let todaysCompleted = [];         // yang hari ini saja (untuk tabel/chart)
    let chart = null;

    function showToast(msg){
      const t = document.getElementById('toast');
      if (!t) return;
      t.textContent = msg;
      t.classList.add('show');
      setTimeout(()=>t.classList.remove('show'), 2200);
    }

    function setLoading(on){
      const box = document.getElementById('loadingBox');
      if (!box) return;
      box.style.display = on ? '' : 'none';
    }

    // parser datetime MySQL aman (anti masalah timezone)
    function parseMysqlDatetime(dt){
      if(!dt) return null;
      const m = String(dt).match(/^(\d{4})-(\d{2})-(\d{2})\s+(\d{2}):(\d{2})(?::(\d{2}))?$/);
      if(!m) return null;
      const y=+m[1], mo=+m[2]-1, d=+m[3], hh=+m[4], mm=+m[5], ss=+(m[6]||0);
      return new Date(y,mo,d,hh,mm,ss);
    }

    function isSameDay(a, b) {
      return a.getFullYear() === b.getFullYear()
          && a.getMonth() === b.getMonth()
          && a.getDate() === b.getDate();
    }

    // total order: kalau total dari DB ada, pakai itu. kalau tidak, hitung dari items DB.
    function calcTotal(order){
      const t = Number(order?.total || 0);
      if (t > 0) return t;

      if (Array.isArray(order?.items) && order.items.length) {
        // items dari DB: {nama_menu, qty, harga}
        return order.items.reduce((s,i)=> s + (Number(i.harga||0) * Number(i.qty||0)), 0);
      }
      return 0;
    }

    function groupBy(arr, keyFn){
      return arr.reduce((acc, x)=>{
        const k = keyFn(x);
        (acc[k] = acc[k] || []).push(x);
        return acc;
      }, {});
    }

    async function fetchCompletedFromDB(){
      setLoading(true);
      try{
        const res = await fetch(API_URL + "?status=completed", { headers:{Accept:"application/json"} });
        const json = await res.json();
        if(!res.ok || json.status !== "success"){
          throw new Error(json.message || ("HTTP " + res.status));
        }

        const raw = Array.isArray(json.data) ? json.data : [];
        // normalisasi shape
        allCompletedFromDB = raw.map(o=>{
          const time = parseMysqlDatetime(o.waktu);
          return {
            id: Number(o.id),
            waktu: o.waktu,
            time,
            pelanggan: o.pelanggan || '-',
            metode_pembayaran: o.metode_pembayaran || '-',
            status: (o.status || 'completed').toLowerCase(),
            total: Number(o.total || 0),
            items: Array.isArray(o.items) ? o.items : [],
          };
        });

        setLoading(false);
        return true;
      }catch(err){
        console.error(err);
        setLoading(false);
        showToast("Gagal memuat data DB");
        // kosongkan agar UI tetap jalan
        allCompletedFromDB = [];
        return false;
      }
    }

    function render(){
      const subtitle = document.getElementById('subtitleDate');
      const today = new Date();
      if (subtitle) subtitle.textContent = today.toLocaleDateString('id-ID', {
        weekday:'long', year:'numeric', month:'long', day:'numeric'
      });

      // filter hari ini
      todaysCompleted = allCompletedFromDB
        .filter(o => o.time && isSameDay(o.time, today));

      // KPI hari ini
      const revenue = todaysCompleted.reduce((s,o)=> s + calcTotal(o), 0);

      // kemarin untuk delta
      const y = new Date(today); y.setDate(today.getDate()-1);
      const yList = allCompletedFromDB.filter(o => o.time && isSameDay(o.time, y));
      const revY = yList.reduce((s,o)=> s + calcTotal(o), 0);

      const delta = revY===0 ? 0 : Math.round(((revenue - revY) / revY) * 100);

      const kpiRevenue = document.getElementById('kpiRevenue');
      const kpiOrders  = document.getElementById('kpiOrders');
      const kpiAOV     = document.getElementById('kpiAOV');
      const kpiPopular = document.getElementById('kpiPopularPay');
      const kpiDelta   = document.getElementById('kpiDelta');

      if (kpiRevenue) kpiRevenue.textContent = fmtIDR(revenue);
      if (kpiOrders)  kpiOrders.textContent  = String(todaysCompleted.length);
      if (kpiAOV)     kpiAOV.textContent     = fmtIDR(todaysCompleted.length ? revenue / todaysCompleted.length : 0);
      if (kpiDelta)   kpiDelta.textContent   = `${delta>=0?'+':''}${delta}% dari kemarin`;

      // metode populer
      const byPay = groupBy(todaysCompleted, o => (o.metode_pembayaran||'-').toLowerCase());
      const popular = Object.entries(byPay).sort((a,b)=>b[1].length-a[1].length)[0]?.[0] || '-';
      if (kpiPopular) kpiPopular.textContent = popular;

      // tabel
      const tbody   = document.getElementById('ordersTbody');
      const caption = document.getElementById('tableCaption');
      const sumCell = document.getElementById('ordersSum');

      if (caption) caption.textContent = `${todaysCompleted.length} transaksi`;
      if (sumCell) sumCell.textContent = fmtIDR(revenue);

      if (tbody){
        tbody.innerHTML = '';

        const list = todaysCompleted.slice().sort((a,b)=> (a.time?.getTime()||0) - (b.time?.getTime()||0));
        list.forEach(o=>{
          const t = o.time ? o.time.toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit'}) : '-';
          const tr = document.createElement('tr');
          tr.innerHTML = `
            <td>${t}</td>
            <td>${String(o.id)}</td>
            <td>${escapeHtml(o.pelanggan)}</td>
            <td>${escapeHtml(o.metode_pembayaran)}</td>
            <td class="right">${fmtIDR(calcTotal(o))}</td>
          `;
          tbody.appendChild(tr);
        });

        if (list.length === 0){
          const tr = document.createElement('tr');
          tr.innerHTML = `<td colspan="5" class="muted">Belum ada transaksi selesai hari ini.</td>`;
          tbody.appendChild(tr);
        }
      }

      buildChart(todaysCompleted);
      handleSearch(); // apply filter jika user sudah mengetik
    }

    function escapeHtml(s){
      return String(s ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
    }

    function buildChart(list){
      const note = document.getElementById('chartNote');
      const buckets = Array.from({length:24}, (_,h)=>({
        h, label: String(h).padStart(2,'0') + ':00', total: 0
      }));

      list.forEach(o=>{
        if (!o.time) return;
        buckets[o.time.getHours()].total += calcTotal(o);
      });

      const labels = buckets.map(b=>b.label);
      const data   = buckets.map(b=>b.total);

      if (note){
        const firstIdx = data.findIndex(v=>v>0);
        const lastIdx  = data.length - 1 - [...data].reverse().findIndex(v=>v>0);
        note.textContent = (firstIdx === -1)
          ? 'Belum ada transaksi'
          : `Aktif: ${labels[firstIdx]} – ${labels[lastIdx]}`;
      }

      const canvas = document.getElementById('revenueChart');
      if (!canvas) return;
      const ctx = canvas.getContext('2d');

      if (chart) chart.destroy();
      chart = new Chart(ctx, {
        type: 'line',
        data: {
          labels,
          datasets: [{
            label: 'Pendapatan',
            data,
            borderColor: '#3b82f6',
            backgroundColor: 'rgba(59,130,246,.15)',
            fill: true,
            tension: .35,
            borderWidth: 3,
            pointRadius: 0
          }]
        },
        options: {
          responsive:true,
          maintainAspectRatio:false,
          scales:{
            y:{ beginAtZero:true, ticks:{ callback:v=>'Rp '+Number(v).toLocaleString('id-ID') } },
            x:{ ticks:{ maxTicksLimit:12 } }
          },
          plugins:{ legend:{ display:false } }
        }
      });
    }

    function exportCSV(){
      const list = todaysCompleted.slice().sort((a,b)=> (a.time?.getTime()||0) - (b.time?.getTime()||0));
      if (list.length===0) { showToast('Tidak ada data untuk diekspor'); return; }

      const rows = [
        ['Waktu','ID Pesanan','Pelanggan','Metode','Total'],
        ...list.map(o=>[
          o.time ? o.time.toLocaleString('id-ID') : '-',
          o.id,
          o.pelanggan,
          o.metode_pembayaran,
          calcTotal(o)
        ])
      ];
      const csv = rows.map(r=>r.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(',')).join('\n');
      const blob = new Blob([csv], {type:'text/csv;charset=utf-8;'});
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = 'pendapatan-hari-ini.csv';
      a.click();
      URL.revokeObjectURL(url);
    }

    function printPage(){ window.print(); }

    function handleSearch(){
      const q = (document.getElementById('searchInput')?.value || '').trim().toLowerCase();
      const rows = Array.from(document.querySelectorAll('#ordersTable tbody tr'));
      let visible = 0;

      rows.forEach(r=>{
        if (r.querySelector('.muted')) {
          r.style.display = q ? 'none' : '';
          return;
        }
        const text = r.textContent.toLowerCase();
        const match = text.includes(q);
        r.style.display = match ? '' : 'none';
        if (match) visible++;
      });

      const caption = document.getElementById('tableCaption');
      if (caption) caption.textContent = q ? `${visible} transaksi (terfilter)` : `${todaysCompleted.length} transaksi`;
    }

    async function refresh(){
      await fetchCompletedFromDB();
      render();
    }

    document.addEventListener('DOMContentLoaded', async ()=>{
      document.getElementById('btnExport')?.addEventListener('click', exportCSV);
      document.getElementById('btnPrint')?.addEventListener('click', printPage);
      document.getElementById('searchInput')?.addEventListener('input', handleSearch);
      document.getElementById('btnRefresh')?.addEventListener('click', refresh);

      await refresh();
    });
  })();
  </script>
</body>
</html>
