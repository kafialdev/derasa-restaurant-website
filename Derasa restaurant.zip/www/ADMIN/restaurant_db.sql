-- =====================================================
-- DATABASE: restaurant (FIXED - INTEGRATED) - FULL RESET
-- =====================================================

CREATE DATABASE IF NOT EXISTS restaurant;
USE restaurant;

SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS order_ratings;
DROP TABLE IF EXISTS detail_pesanan;
DROP TABLE IF EXISTS pesanan_masuk;
DROP TABLE IF EXISTS menu_restaurant;
DROP TABLE IF EXISTS laporan_bulanan;
DROP TABLE IF EXISTS karyawan;
DROP TABLE IF EXISTS reservations;
DROP TABLE IF EXISTS contact_messages;
DROP TABLE IF EXISTS users;

SET FOREIGN_KEY_CHECKS = 1;

-- ------------------------------
-- USERS (ADMIN)
-- ------------------------------
CREATE TABLE users (
  id INT NOT NULL AUTO_INCREMENT,
  username VARCHAR(50) NOT NULL,
  password VARCHAR(255) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_username (username)
);

-- ------------------------------
-- MENU
-- ------------------------------
CREATE TABLE menu_restaurant (
  id INT NOT NULL AUTO_INCREMENT,
  nama_menu VARCHAR(150) NOT NULL,
  kategori VARCHAR(50) NOT NULL,
  harga INT NOT NULL,
  stok INT DEFAULT 0,
  status VARCHAR(20) DEFAULT 'Tersedia',
  deskripsi TEXT,
  gambar VARCHAR(255),
  dibuat_pada DATETIME DEFAULT CURRENT_TIMESTAMP,
  diperbarui_pada DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
);

-- ------------------------------
-- PESANAN (HEADER)
-- status: pending | processing | completed | cancelled
-- ------------------------------
CREATE TABLE pesanan_masuk (
  id INT NOT NULL AUTO_INCREMENT,
  waktu DATETIME DEFAULT CURRENT_TIMESTAMP,
  pelanggan VARCHAR(150) NOT NULL,
  telepon VARCHAR(30) DEFAULT NULL,     -- ✅ INI WAJIB ADA
  metode_pembayaran VARCHAR(50) NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'pending',
  catatan TEXT,
  total INT NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  INDEX idx_status (status),
  INDEX idx_waktu (waktu)
);

-- ------------------------------
-- DETAIL PESANAN
-- ------------------------------
CREATE TABLE detail_pesanan (
  id INT NOT NULL AUTO_INCREMENT,
  order_id INT NOT NULL,
  menu_id INT DEFAULT NULL,
  nama_menu VARCHAR(150) NOT NULL,
  qty INT NOT NULL,
  harga INT NOT NULL,
  PRIMARY KEY (id),
  INDEX idx_order (order_id),
  CONSTRAINT fk_detail_order FOREIGN KEY (order_id) REFERENCES pesanan_masuk(id) ON DELETE CASCADE,
  CONSTRAINT fk_detail_menu  FOREIGN KEY (menu_id)  REFERENCES menu_restaurant(id) ON DELETE SET NULL
);

-- ------------------------------
-- LAPORAN BULANAN (opsional)
-- ------------------------------
CREATE TABLE laporan_bulanan (
  id INT NOT NULL AUTO_INCREMENT,
  bulan VARCHAR(20) NOT NULL,
  tahun INT NOT NULL,
  total_pendapatan INT NOT NULL DEFAULT 0,
  dibuat_pada DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
);

-- ------------------------------
-- KARYAWAN (TEAM)
-- ------------------------------
CREATE TABLE karyawan (
  id INT NOT NULL AUTO_INCREMENT,
  nama VARCHAR(100) NOT NULL,
  posisi VARCHAR(50) DEFAULT NULL,
  deskripsi TEXT,
  is_chef TINYINT(1) NOT NULL DEFAULT 0,
  image VARCHAR(255) DEFAULT NULL,
  visible TINYINT(1) NOT NULL DEFAULT 1,
  dibuat_pada DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
);

-- ------------------------------
-- RESERVATIONS
-- ------------------------------
CREATE TABLE reservations (
  id INT NOT NULL AUTO_INCREMENT,
  name VARCHAR(100) NOT NULL,
  phone VARCHAR(20) NOT NULL,
  datetime DATETIME NOT NULL,
  guests VARCHAR(50),
  message TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
);

-- ------------------------------
-- CONTACT MESSAGES
-- ------------------------------
CREATE TABLE contact_messages (
  id INT NOT NULL AUTO_INCREMENT,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL,
  phone VARCHAR(20),
  message TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
);

-- ------------------------------
-- RATING / SARAN PER PESANAN
-- ------------------------------
CREATE TABLE order_ratings (
  id INT NOT NULL AUTO_INCREMENT,
  order_id INT NOT NULL,
  rating INT DEFAULT NULL,
  saran TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_order_rating (order_id),
  CONSTRAINT fk_rating_order FOREIGN KEY (order_id) REFERENCES pesanan_masuk(id) ON DELETE CASCADE
);
