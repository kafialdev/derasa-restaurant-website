<?php /* /ADMIN/pesananproses.php (DB Integrated - FIX QUEUE CONSISTENT) */ ?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Pesanan Diproses - Admin Cafe</title>

  <style>
    :root{
      --bg:#f6f7fb;
      --card:#ffffff;
      --ink:#1f2430;
      --muted:#6b7280;
      --primary:#4a6fa5;
      --accent:#ff6b6b;
      --danger:#ef4444;
      --success:#2ecc71;
      --light:#f9fafb;
      --dark:#1f2933;
      --shadow:0 20px 40px rgba(0,0,0,0.1);
    }

    *{box-sizing:border-box;margin:0;padding:0;}
    body{
      min-height:100vh;
      font-family:ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial;
      background:linear-gradient(180deg,#f7f9ff,#eef2ff 1200px);
      color:var(--ink);
      display:flex;
      justify-content:center;
      align-items:flex-start;
      padding:24px;
    }
    .container{ width:100%; max-width:1100px; }
    .fade-in{ animation:fadeIn .3s ease; }
    @keyframes fadeIn{ from{opacity:0;transform:translateY(4px);} to{opacity:1;transform:translateY(0);} }

    .btn-action{
      padding:8px 12px;
      font-size:12px;
      border-radius:8px;
      font-weight:800;
      color:#fff;
      background:#4a6fa5;
      border:none;
      cursor:pointer;
      margin-right:6px;
      min-width:120px;
      transition:.15s;
      text-decoration:none;
      display:inline-block;
      text-align:center;
    }
    .btn-action:hover{opacity:.95; transform:translateY(-1px);}
    .btn-danger{background:#ef4444;}
    .btn-primary{background:#2196f3;}
    .btn-success{background:#4caf50;}

    .processed-orders-container{
      background:#fff;
      border-radius:20px;
      overflow:hidden;
      box-shadow: var(--shadow);
      width:100%;
      min-height:600px;
      padding:30px;
    }
    .processed-orders-header{
      display:flex;
      justify-content:space-between;
      align-items:center;
      margin-bottom:30px;
      padding-bottom:15px;
      border-bottom:1px solid #eee;
      gap:12px;
      flex-wrap:wrap;
    }
    .processed-orders-header h1{ font-size:28px; color:var(--dark); }

    .processed-orders-table-container{ overflow-x:auto; }
    .processed-orders-table{
      width:100%;
      border-collapse:collapse;
      min-width:820px;
    }
    .processed-orders-table th,
    .processed-orders-table td{
      padding:12px 15px;
      text-align:left;
      border-bottom:1px solid #eee;
      font-size:13px;
      vertical-align:top;
    }
    .processed-orders-table th{
      background:var(--light);
      font-weight:800;
      color:var(--dark);
      text-transform:uppercase;
      font-size:12px;
    }
    .processed-orders-table tbody tr:hover{
      background: rgba(74,111,165,0.03);
    }

    .order-status-badge{
      padding:6px 10px;
      border-radius:20px;
      font-size:12px;
      font-weight:800;
      display:inline-block;
      text-transform:capitalize;
    }
    .status-processing{
      background: rgba(74,111,165,0.2);
      color: var(--primary);
    }
    .status-completed{
      background: rgba(78,205,196,0.2);
      color: var(--success);
    }
    .status-cancelled{
      background: rgba(255,107,107,0.2);
      color: var(--accent);
    }

    .btn-detail{
      background: linear-gradient(135deg, #28527e, #224264);
      color:#fff;
      border:none;
      border-radius:8px;
      padding:8px 14px;
      font-weight:800;
      font-size:12px;
      cursor:pointer;
      transition:.2s;
    }
    .btn-detail:hover{ transform:translateY(-1px); opacity:.95; }

    /* Modal */
    .modal-overlay{
      position:fixed;
      inset:0;
      background:rgba(0,0,0,.4);
      display:none;
      justify-content:center;
      align-items:center;
      z-index:1000;
    }
    .modal{
      background:#fff;
      border-radius:16px;
      width:min(680px,94vw);
      max-height:90vh;
      box-shadow:0 18px 40px rgba(15,23,42,.2);
      display:flex;
      flex-direction:column;
      overflow:hidden;
      animation:fadeIn .25s ease;
    }
    .modal-header{
      padding:16px 20px;
      border-bottom:1px solid #f3f4f6;
      display:flex;
      justify-content:space-between;
      align-items:center;
      gap:10px;
    }
    .modal-header h2{ margin:0; font-size:18px; }
    .close-modal{
      background:none;
      border:none;
      font-size:24px;
      cursor:pointer;
      line-height:1;
    }
    .modal-body{
      padding:16px 20px;
      overflow-y:auto;
    }
    .form-actions{
      padding:12px 16px 14px;
      border-top:1px solid #f3f4f6;
      display:flex;
      justify-content:flex-end;
      gap:8px;
      flex-wrap:wrap;
    }

    .detail-item{
      margin-bottom:10px;
      padding-bottom:6px;
      border-bottom:1px dashed #eee;
      font-size:14px;
    }
    .detail-item strong{
      color:var(--dark);
      display:inline-block;
      width:160px;
    }
    .order-items-list{
      list-style:none;
      padding:0;
      margin-top:10px;
    }
    .order-items-list li{
      padding:6px 0;
      border-bottom:1px dotted #f0f0f0;
      display:flex;
      justify-content:space-between;
      gap:12px;
      font-size:14px;
    }
    .order-total{
      font-size:1.1em;
      font-weight:900;
      text-align:right;
      margin-top:15px;
      color:var(--primary);
    }

    .toast{
      position:fixed;
      bottom:18px;
      left:50%;
      transform:translateX(-50%);
      background:#111827;
      color:#fff;
      padding:10px 14px;
      border-radius:10px;
      opacity:0;
      pointer-events:none;
      transition:.25s;
      box-shadow:0 12px 28px rgba(15,23,42,.35);
      font-size:14px;
      z-index:1200;
    }
    .toast.show{opacity:1;}

    @media (max-width:768px){
      body{padding:16px;}
      .processed-orders-container{padding:20px;margin:20px 0;}
      .processed-orders-header h1{font-size:24px;}
      .processed-orders-table th,.processed-orders-table td{padding:8px 10px;}
      .detail-item strong{width:140px;}
    }
  </style>
</head>

<body>
  <div class="container">
    <div class="processed-orders-container fade-in">
      <div class="processed-orders-header">
        <h1>Pesanan Diproses</h1>
        <div style="display:flex; gap:8px; flex-wrap:wrap;">
          <a href="index.php" class="btn-action">Kembali ke Dashboard</a>
          <button class="btn-action" onclick="loadOrders()">Refresh</button>
        </div>
      </div>

      <div class="processed-orders-table-container">
        <table class="processed-orders-table">
          <thead>
            <tr>
              <th>No. Antrian</th>
              <th>ID Pesanan</th>
              <th>Tanggal &amp; Waktu</th>
              <th>Pelanggan</th>
              <th>Total</th>
              <th>Status</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody id="processedOrdersTableBody"></tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- Modal Detail -->
  <div class="modal-overlay" id="ordersModalOverlay">
    <div class="modal modal-order-details">
      <div class="modal-header">
        <h2>Detail Pesanan <span id="orderDetailId"></span></h2>
        <button class="close-modal" onclick="closeOrderDetailsModal()">&times;</button>
      </div>
      <div class="modal-body">
        <div class="detail-item"><strong>Waktu Pesanan:</strong> <span id="orderDetailTime"></span></div>
        <div class="detail-item"><strong>Nama Pelanggan:</strong> <span id="orderDetailCustomer"></span></div>
        <div class="detail-item"><strong>Telepon:</strong> <span id="orderDetailPhone"></span></div>
        <div class="detail-item"><strong>Metode Pembayaran:</strong> <span id="orderDetailPayment"></span></div>
        <div class="detail-item"><strong>Status:</strong> <span id="orderDetailStatus"></span></div>
        <div class="detail-item"><strong>Catatan:</strong> <span id="orderDetailNotes"></span></div>

        <h3 style="margin-top:14px; margin-bottom:6px;">Item Pesanan:</h3>
        <ul id="orderDetailItems" class="order-items-list"></ul>

        <div class="order-total">
          Total: <span id="orderDetailTotal"></span>
        </div>
      </div>

      <div class="form-actions">
        <button type="button" class="btn-action" onclick="closeOrderDetailsModal()">Tutup</button>
        <button type="button" class="btn-action btn-danger" onclick="updateStatusFromDetail('cancelled')">Batalkan</button>
        <button type="button" class="btn-action btn-primary" onclick="window.print()">Cetak Struk</button>
        <button type="button" class="btn-action btn-success" onclick="updateStatusFromDetail('completed')">Selesai</button>
      </div>
    </div>
  </div>

  <div class="toast" id="toast"></div>

  <script>
    const API_URL = "simpan_pesanan.php";

    let ordersProcessing = [];    // data status=processing (buat tabel)
    let ordersAllForQueue = [];   // semua status (buat no antrian stabil)
    let selectedOrderId = null;

    function showToast(msg){
      const t = document.getElementById('toast');
      t.textContent = msg;
      t.classList.add('show');
      setTimeout(()=>t.classList.remove('show'), 2200);
    }

    function escapeHtml(s){
      return String(s ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
    }

    function pad3(n){ return String(n).padStart(3,'0'); }

    function parseMysqlDatetime(dt){
      if(!dt) return null;
      const m = String(dt).match(/^(\d{4})-(\d{2})-(\d{2})\s+(\d{2}):(\d{2})(?::(\d{2}))?$/);
      if(!m) return null;
      const y=+m[1], mo=+m[2]-1, d=+m[3], hh=+m[4], mm=+m[5], ss=+(m[6]||0);
      return new Date(y,mo,d,hh,mm,ss);
    }

    function formatDateTime(mysqlDt){
      const d = parseMysqlDatetime(mysqlDt);
      if(!d) return {date:'-', time:'', full:'-'};
      const date = d.toLocaleDateString('id-ID',{day:'2-digit',month:'2-digit',year:'numeric'});
      const time = d.toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit'});
      return { date, time, full: d.toLocaleString('id-ID') };
    }

    function getDbDateKey(mysqlDt){
      return (mysqlDt && String(mysqlDt).length >= 10) ? String(mysqlDt).slice(0,10) : '';
    }

    function buildQueueMapByDate(){
      const map = {};      // order_id -> queue_no
      const groups = {};   // dateKey -> orders[]

      for(const o of ordersAllForQueue){
        const key = getDbDateKey(o.waktu);
        if(!key) continue;
        if(!groups[key]) groups[key] = [];
        groups[key].push(o);
      }

      Object.keys(groups).forEach(dateKey=>{
        const arr = groups[dateKey].slice().sort((a,b)=>{
          const ta = parseMysqlDatetime(a.waktu)?.getTime() || 0;
          const tb = parseMysqlDatetime(b.waktu)?.getTime() || 0;
          if(ta === tb) return (Number(a.id)||0) - (Number(b.id)||0);
          return ta - tb;
        });
        arr.forEach((o, idx)=>{
          map[Number(o.id)] = idx + 1;
        });
      });

      return map;
    }

    async function loadOrders(){
      const tbody = document.getElementById("processedOrdersTableBody");
      tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding:20px;">Memuat data...</td></tr>`;

      try{
        // 1) processing (buat tabel)
        const resProc = await fetch(API_URL + "?status=processing", { headers:{Accept:"application/json"}});
        const jsonProc = await resProc.json();
        if(!resProc.ok || jsonProc.status !== "success") throw new Error(jsonProc.message || ("HTTP " + resProc.status));
        ordersProcessing = Array.isArray(jsonProc.data) ? jsonProc.data : [];

        // 2) semua status (buat nomor antrian stabil, sama seperti pesananmasuk.php)
        const resAll = await fetch(API_URL, { headers:{Accept:"application/json"}});
        const jsonAll = await resAll.json();
        if(!resAll.ok || jsonAll.status !== "success") throw new Error(jsonAll.message || ("HTTP " + resAll.status));
        ordersAllForQueue = Array.isArray(jsonAll.data) ? jsonAll.data : [];

        renderProcessingOrders();
      }catch(err){
        console.error(err);
        tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding:20px; color:#ef4444;">
          Gagal memuat data dari database.<br>${escapeHtml(err.message)}
        </td></tr>`;
        showToast("Gagal load dari DB");
      }
    }

    function renderProcessingOrders(){
      const tbody = document.getElementById("processedOrdersTableBody");
      tbody.innerHTML = "";

      if(ordersProcessing.length === 0){
        tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding:20px;">Tidak ada pesanan yang sedang diproses.</td></tr>`;
        return;
      }

      const queueMap = buildQueueMapByDate();

      // urutkan processing by waktu ASC (stabil)
      const list = ordersProcessing.slice().sort((a,b)=>{
        const ta = parseMysqlDatetime(a.waktu)?.getTime() || 0;
        const tb = parseMysqlDatetime(b.waktu)?.getTime() || 0;
        if(ta === tb) return (Number(a.id)||0) - (Number(b.id)||0);
        return ta - tb;
      });

      list.forEach(o=>{
        const q = queueMap[Number(o.id)] || 1;         // nomor antrian STABIL!
        const noAntrian = pad3(q);
        const orderCode = String(o.id);                // ID Pesanan KONSISTEN = id DB
        const dt = formatDateTime(o.waktu);

        const row = document.createElement("tr");
        row.innerHTML = `
          <td>${noAntrian}</td>
          <td>${escapeHtml(orderCode)}</td>
          <td>${dt.date}<br><span style="font-size:11px;color:#6b7280;">${dt.time}</span></td>
          <td>${escapeHtml(o.pelanggan || "-")}</td>
          <td>Rp ${Number(o.total||0).toLocaleString("id-ID")}</td>
          <td><span class="order-status-badge status-processing">processing</span></td>
          <td>
            <button class="btn-detail" onclick="openOrderDetailsModal(${Number(o.id)})">Detail</button>
            <select class="btn-action" onchange="changeOrderStatus(${Number(o.id)}, this.value)">
              <option value="">Ubah Status</option>
              <option value="processing" selected>Processing</option>
              <option value="completed">Completed</option>
              <option value="cancelled">Cancelled</option>
            </select>
          </td>
        `;
        tbody.appendChild(row);
      });
    }

    function openOrderDetailsModal(orderId){
      const order = ordersProcessing.find(o => Number(o.id) === Number(orderId))
                || ordersAllForQueue.find(o => Number(o.id) === Number(orderId));

      if(!order){ showToast("Pesanan tidak ditemukan"); return; }

      selectedOrderId = Number(orderId);

      const dt = formatDateTime(order.waktu);
      document.getElementById("orderDetailId").textContent = String(order.id);
      document.getElementById("orderDetailTime").textContent = dt.full;
      document.getElementById("orderDetailCustomer").textContent = order.pelanggan || "-";
      document.getElementById("orderDetailPhone").textContent = order.telepon || "-";
      document.getElementById("orderDetailPayment").textContent = order.metode_pembayaran || "-";
      document.getElementById("orderDetailStatus").textContent = order.status || "processing";
      document.getElementById("orderDetailNotes").textContent = order.catatan || "-";

      const ul = document.getElementById("orderDetailItems");
      ul.innerHTML = "";
      let total = 0;

      (order.items || []).forEach(it=>{
        const nama = it.nama_menu || it.name || "Item";
        const qty  = Number(it.qty ?? it.quantity ?? 0);
        const harga = Number(it.harga ?? it.price ?? 0);
        const sub = qty * harga;
        total += sub;

        const li = document.createElement("li");
        li.innerHTML = `<span>${escapeHtml(nama)} x ${qty}</span><span>Rp ${sub.toLocaleString("id-ID")}</span>`;
        ul.appendChild(li);
      });

      const totalFinal = Number(order.total || total);
      document.getElementById("orderDetailTotal").textContent = "Rp " + totalFinal.toLocaleString("id-ID");

      document.getElementById("ordersModalOverlay").style.display = "flex";
    }

    function closeOrderDetailsModal(){
      document.getElementById("ordersModalOverlay").style.display = "none";
      selectedOrderId = null;
    }

    async function changeOrderStatus(orderId, newStatus){
      if(!newStatus) return;
      await updateOrderStatus(orderId, newStatus);
    }

    async function updateStatusFromDetail(newStatus){
      if(!selectedOrderId) return showToast("ID pesanan tidak terbaca");
      await updateOrderStatus(selectedOrderId, newStatus);
      closeOrderDetailsModal();

      if(newStatus === "completed") window.location.href = "pesananselesai.php";
      if(newStatus === "cancelled") window.location.href = "pesananbatal.php";
    }

    async function updateOrderStatus(orderId, newStatus){
      try{
        const res = await fetch(API_URL, {
          method:"POST",
          headers:{"Content-Type":"application/json","Accept":"application/json"},
          body: JSON.stringify({ action:"update_status", order_id:Number(orderId), status:newStatus })
        });
        const json = await res.json();
        if(!res.ok || json.status !== "success") throw new Error(json.message || ("HTTP " + res.status));

        showToast("Status berhasil diupdate");
        await loadOrders();
      }catch(err){
        console.error(err);
        alert("Gagal update status: " + err.message);
        showToast("Gagal update status");
      }
    }

    document.addEventListener("DOMContentLoaded", loadOrders);
  </script>
</body>
</html>
