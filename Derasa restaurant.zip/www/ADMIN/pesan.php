<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Form Pemesanan - Restoran DeRasa</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f5f6fa;
      padding: 20px;
    }
    h2 {
      text-align: center;
      color: #333;
    }
    form {
      max-width: 400px;
      margin: auto;
      background: white;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 0 5px rgba(0,0,0,0.1);
    }
    label {
      display: block;
      margin-top: 10px;
    }
    input, select, textarea {
      width: 100%;
      padding: 8px;
      margin-top: 5px;
      border: 1px solid #ccc;
      border-radius: 4px;
    }
    button {
      background: #007bff;
      color: white;
      padding: 10px;
      border: none;
      border-radius: 5px;
      margin-top: 15px;
      width: 100%;
      cursor: pointer;
    }
    button:hover {
      background: #0056b3;
    }
  </style>
</head>
<body>
  <h2>🍽️ Form Pemesanan</h2>
  <form action="pesananotomatis.php" method="POST">
    <label>Nama Pelanggan:</label>
    <input type="text" name="pelanggan" required>

    <label>Metode Pembayaran:</label>
    <select name="metode_pembayaran" required>
      <option value="Tunai">Tunai</option>
      <option value="QRIS">QRIS</option>
      <option value="Transfer Bank">Transfer Bank</option>
    </select>

    <label>Status Pesanan:</label>
    <select name="status">
      <option value="Diproses">Diproses</option>
      <option value="Selesai">Selesai</option>
      <option value="Batal">Batal</option>
    </select>

    <label>Catatan:</label>
    <textarea name="catatan"></textarea>

    <label>Total (Rp):</label>
    <input type="number" name="total" required>

    <button type="submit">Kirim Pesanan</button>
  </form>
</body>
</html>
