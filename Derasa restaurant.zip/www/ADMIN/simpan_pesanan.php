<?php
@date_default_timezone_set('Asia/Jakarta');
// /ADMIN/simpan_pesanan.php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/koneksi.php'; // harus menyediakan $conn = new mysqli(...)

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

function json_out($arr, $code = 200) {
  http_response_code($code);
  echo json_encode($arr);
  exit;
}

function norm_status($s) {
  $s = strtolower(trim((string)$s));
  $allow = ['pending','processing','completed','cancelled'];
  return in_array($s, $allow, true) ? $s : null;
}

try {

  // =========================
  // GET: ambil order (admin)
  // =========================
  if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $status_raw = $_GET['status'] ?? null; // kalau null => ambil SEMUA status
    $status     = ($status_raw === null || $status_raw === '' || strtolower($status_raw) === 'all')
                    ? null
                    : norm_status($status_raw);

    $order_id = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;

    // 1) Detail 1 order + items
    if ($order_id > 0) {
      $stmt = $conn->prepare("SELECT pm.*, DATE_FORMAT(pm.waktu, '%Y%m%d%H%i%s') AS order_code
                              FROM pesanan_masuk pm
                              WHERE pm.id=? LIMIT 1");
      $stmt->bind_param("i", $order_id);
      $stmt->execute();
      $order = $stmt->get_result()->fetch_assoc();
      $stmt->close();

      if (!$order) json_out(['status'=>'error','message'=>'Pesanan tidak ditemukan'], 404);

      $stmt = $conn->prepare("SELECT id, order_id, menu_id, nama_menu, qty, harga
                              FROM detail_pesanan
                              WHERE order_id=?
                              ORDER BY id ASC");
      $stmt->bind_param("i", $order_id);
      $stmt->execute();
      $items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
      $stmt->close();

      $order['items'] = $items;

      // queue_no konsisten per tanggal (tanpa peduli status)
      $orderDate = substr((string)$order['waktu'], 0, 10);

      $stmt = $conn->prepare("
        SELECT COUNT(*) AS q
        FROM pesanan_masuk x
        WHERE DATE(x.waktu)=?
          AND (x.waktu < ? OR (x.waktu = ? AND x.id <= ?))
      ");
      $stmt->bind_param("sssi", $orderDate, $order['waktu'], $order['waktu'], $order_id);
      $stmt->execute();
      $q = (int)$stmt->get_result()->fetch_assoc()['q'];
      $stmt->close();

      $order['queue_no'] = $q;

      json_out(['status'=>'success','data'=>$order]);
    }

    // 2) List orders (status opsional)
    //    - kalau status NULL => ambil SEMUA status
    //    - kalau status invalid => error
    if ($status_raw !== null && $status === null && strtolower($status_raw) !== 'all' && $status_raw !== '') {
      json_out(['status'=>'error','message'=>'Parameter status tidak valid'], 400);
    }

    if ($status === null) {
      // ambil semua status
      $sql = "SELECT
                pm.*,
                DATE_FORMAT(pm.waktu, '%Y%m%d%H%i%s') AS order_code,
                (
                  SELECT COUNT(*)
                  FROM pesanan_masuk x
                  WHERE DATE(x.waktu)=DATE(pm.waktu)
                    AND (x.waktu < pm.waktu OR (x.waktu = pm.waktu AND x.id <= pm.id))
                ) AS queue_no
              FROM pesanan_masuk pm
              ORDER BY pm.waktu ASC, pm.id ASC";
      $stmt = $conn->prepare($sql);
    } else {
      // ambil berdasarkan status
      $sql = "SELECT
                pm.*,
                DATE_FORMAT(pm.waktu, '%Y%m%d%H%i%s') AS order_code,
                (
                  SELECT COUNT(*)
                  FROM pesanan_masuk x
                  WHERE DATE(x.waktu)=DATE(pm.waktu)
                    AND (x.waktu < pm.waktu OR (x.waktu = pm.waktu AND x.id <= pm.id))
                ) AS queue_no
              FROM pesanan_masuk pm
              WHERE pm.status=?
              ORDER BY pm.waktu ASC, pm.id ASC";
      $stmt = $conn->prepare($sql);
      $stmt->bind_param("s", $status);
    }

    $stmt->execute();
    $orders = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    if (!$orders) json_out(['status'=>'success','data'=>[]]);

    // attach items batch
    $ids = array_map(fn($r)=> (int)$r['id'], $orders);
    if (count($ids) > 0) {
      $placeholders = implode(',', array_fill(0, count($ids), '?'));
      $types = str_repeat('i', count($ids));

      $sql = "SELECT order_id, menu_id, nama_menu, qty, harga
              FROM detail_pesanan
              WHERE order_id IN ($placeholders)
              ORDER BY id ASC";
      $stmt = $conn->prepare($sql);
      $stmt->bind_param($types, ...$ids);
      $stmt->execute();
      $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
      $stmt->close();

      $byOrder = [];
      foreach ($rows as $r) {
        $oid = (int)$r['order_id'];
        $byOrder[$oid][] = $r;
      }

      foreach ($orders as &$o) {
        $o['items'] = $byOrder[(int)$o['id']] ?? [];
      }
      unset($o);
    } else {
      foreach ($orders as &$o) { $o['items'] = []; }
      unset($o);
    }

    json_out(['status'=>'success','data'=>$orders]);
  }

  // =========================
  // POST: create OR update_status
  // =========================
  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    if (!is_array($data)) json_out(['status'=>'error','message'=>'JSON tidak valid'], 400);

    // A) UPDATE STATUS (admin)
    if (($data['action'] ?? '') === 'update_status') {
      $order_id = (int)($data['order_id'] ?? 0);
      $status   = norm_status($data['status'] ?? '');

      if ($order_id <= 0 || !$status) {
        json_out(['status'=>'error','message'=>'Parameter update_status tidak valid'], 400);
      }

      $stmt = $conn->prepare("UPDATE pesanan_masuk SET status=? WHERE id=?");
      $stmt->bind_param("si", $status, $order_id);
      $stmt->execute();
      $stmt->close();

      json_out(['status'=>'success','message'=>'Status berhasil diupdate']);
    }

    // B) CREATE ORDER (user)
    $pelanggan = trim($data['customer'] ?? 'Tanpa Nama');
    $telepon   = trim($data['phone'] ?? '');
    $metode    = trim($data['paymentMethod'] ?? 'Cash');
    $status    = norm_status($data['status'] ?? 'pending') ?? 'pending';
    $catatan   = trim($data['notes'] ?? '');
    $items     = is_array($data['items'] ?? null) ? $data['items'] : [];

    if ($pelanggan === '' || empty($items)) {
      json_out(['status'=>'error','message'=>'Data pesanan tidak lengkap'], 400);
    }

    $waktu = date('Y-m-d H:i:s'); // selalu pakai waktu server (realtime & konsisten)

    // =====================================================
    // VALIDASI MENU (stok + status) + DECREMENT STOK
    // - jika stok habis / status habis => pesanan ditolak
    // - harga & nama diambil dari DB untuk mencegah manipulasi
    // =====================================================
    $conn->begin_transaction();

    $normalized = [];
    $total = 0;

    $stmtCheck = $conn->prepare("SELECT id, nama_menu, harga, stok, status FROM menu_restaurant WHERE id=? FOR UPDATE");
    if (!$stmtCheck) {
      throw new Exception('Gagal menyiapkan validasi stok');
    }

    foreach ($items as $it) {
      $menu_id = (int)($it['menuId'] ?? 0);
      $qty     = max(1, (int)($it['quantity'] ?? 1));

      if ($menu_id <= 0) {
        throw new Exception('Item menu tidak valid');
      }

      $stmtCheck->bind_param('i', $menu_id);
      $stmtCheck->execute();
      $m = $stmtCheck->get_result()->fetch_assoc();
      if (!$m) {
        throw new Exception('Menu tidak ditemukan (ID: ' . $menu_id . ')');
      }

      $stok = isset($m['stok']) ? (int)$m['stok'] : 0;
      $st   = strtolower(trim((string)($m['status'] ?? '')));
      $isAvailableStatus = ($st === '' || $st === 'tersedia' || $st === '1');

      // status habis/kosong/0 => dianggap tidak tersedia
      if (!$isAvailableStatus || $stok <= 0) {
        throw new Exception('Menu "' . (string)$m['nama_menu'] . '" sedang habis');
      }
      if ($stok < $qty) {
        throw new Exception('Stok menu "' . (string)$m['nama_menu'] . '" tidak cukup (tersisa ' . $stok . ')');
      }

      $hargaDb = (int)$m['harga'];
      $namaDb  = (string)$m['nama_menu'];

      $normalized[] = [
        'menu_id' => $menu_id,
        'qty' => $qty,
        'harga' => $hargaDb,
        'nama' => $namaDb,
      ];

      $total += $hargaDb * $qty;
    }

    $stmtCheck->close();

    $stmt = $conn->prepare("INSERT INTO pesanan_masuk (waktu,pelanggan,telepon,metode_pembayaran,status,catatan,total)
                            VALUES (?,?,?,?,?,?,?)");
    $stmt->bind_param("ssssssi", $waktu, $pelanggan, $telepon, $metode, $status, $catatan, $total);
    $stmt->execute();
    $order_id = $stmt->insert_id;
    $stmt->close();


    // simpan detail (menggunakan data DB)
    $stmtDetail = $conn->prepare("INSERT INTO detail_pesanan (order_id,menu_id,nama_menu,qty,harga) VALUES (?,?,?,?,?)");
    $stmtUpd    = $conn->prepare("UPDATE menu_restaurant
                                  SET stok = stok - ?,
                                      status = CASE WHEN (stok - ?) <= 0 THEN 'Habis' ELSE 'Tersedia' END
                                  WHERE id = ?");

    foreach ($normalized as $it) {
      $menu_id = (int)$it['menu_id'];
      $nama    = (string)$it['nama'];
      $qty     = (int)$it['qty'];
      $harga   = (int)$it['harga'];

      $stmtDetail->bind_param("iisii", $order_id, $menu_id, $nama, $qty, $harga);
      $stmtDetail->execute();

      // decrement stok + auto set habis bila 0
      $stmtUpd->bind_param('iii', $qty, $qty, $menu_id);
      $stmtUpd->execute();
    }

    $stmtDetail->close();
    $stmtUpd->close();

    $conn->commit();

    json_out(['status'=>'success','message'=>'Pesanan berhasil disimpan','order_id'=>$order_id]);
  }

  json_out(['status'=>'error','message'=>'Method tidak didukung'], 405);

} catch (Throwable $e) {
  if (isset($conn) && $conn instanceof mysqli) {
    try { $conn->rollback(); } catch (Throwable $t) {}
  }
  json_out(['status'=>'error','message'=>$e->getMessage()], 500);
}
