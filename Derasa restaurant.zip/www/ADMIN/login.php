<?php
session_start();
$host = "localhost";
$db = "restaurant";
$user = "root";
$pass = "";

// Koneksi database
$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$toastMessage = '';
$toastSuccess = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    $user_id = null;

    // =================================================================
    // CEK APAKAH PENGGUNA SUDAH ADA DI DATABASE
    // =================================================================
    $stmt = $conn->prepare("SELECT id, password FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $userData = $result->fetch_assoc();
        // Verifikasi password
        if (password_verify($password, $userData['password'])) {
            $user_id = $userData['id'];
            $toastMessage = 'Login pengguna lama berhasil! Mengarahkan...';
            $toastSuccess = true;
        } else {
            $toastMessage = 'Password salah!';
            $toastSuccess = false;
        }
    } else {
        // PENGGUNA BARU, SIMPAN KE DATABASE
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $stmt_insert = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
        $stmt_insert->bind_param("ss", $username, $hashedPassword);

        if ($stmt_insert->execute()) {
            $user_id = $conn->insert_id;
            $toastMessage = 'Pengguna baru berhasil terdaftar dan login! Mengarahkan...';
            $toastSuccess = true;
        } else {
            $toastMessage = 'Gagal menyimpan data pengguna baru: ' . $conn->error;
            $toastSuccess = false;
        }

        $stmt_insert->close();
    }

    $stmt->close();

    // =================================================================
    // PROSES LOGIN
    // =================================================================
    if ($user_id !== null) {
        $_SESSION['user_id'] = $user_id;
        header("Refresh:1; url=index.php");
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login Admin Restoran</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"/>
<style>
body {
    background: linear-gradient(135deg, #f0f4f8, #d9e2ec);
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    margin: 0;
    overflow: hidden;
}
.login-container {
    background: #ffffff;
    padding: 3rem 2.5rem;
    border-radius: 20px;
    box-shadow: 0 15px 40px rgba(0, 0, 0, 0.1);
    width: 100%;
    max-width: 420px;
    text-align: center;
    position: relative;
    animation: fadeIn 1s ease forwards;
}
.login-container h1 { margin-bottom: 0.5rem; color: #1f2937; font-weight: 700; letter-spacing: 1px; }
.login-container p { color: #4b5563; margin-bottom: 2rem; font-size: 0.95rem; }
.form-control {
    border-radius: 12px;
    padding: 0.75rem 1rem;
    border: 1px solid #cbd5e1;
    transition: all 0.3s ease;
    font-size: 0.95rem;
}
.form-control:focus {
    border-color: #7f9cf5;
    box-shadow: 0 0 12px rgba(127, 156, 245, 0.3);
    transform: scale(1.02);
    outline: none;
}
.btn-login {
    width: 100%;
    padding: 0.75rem;
    background: linear-gradient(135deg, #7f9cf5, #6b7280);
    border: none;
    border-radius: 12px;
    color: white;
    font-weight: 600;
    font-size: 1.05rem;
    cursor: pointer;
    transition: all 0.4s ease;
    position: relative;
    overflow: hidden;
}
.btn-login::after {
    content: "";
    position: absolute;
    width: 120%;
    height: 100%;
    background: rgba(255, 255, 255, 0.15);
    top: 0;
    left: -100%;
    transform: skewX(-25deg);
    transition: all 0.5s ease;
}
.btn-login:hover::after { left: 100%; }
.btn-login:hover { transform: translateY(-3px); box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15); }
.toast {
    position: fixed;
    bottom: 30px;
    right: 30px;
    color: #fff;
    padding: 1rem 1.5rem;
    border-radius: 12px;
    display: none;
    z-index: 999;
    opacity: 0;
    transition: all 0.5s ease;
    font-size: 0.95rem;
    box-shadow: 0 5px 20px rgba(0,0,0,0.2);
}
.toast.success { background: #28a745; }
.toast.error { background: #dc3545; }
@keyframes fadeIn { 0% { opacity: 0; transform: translateY(-20px); } 100% { opacity: 1; transform: translateY(0); } }
@media (max-width: 480px) {
    .login-container { padding: 2rem 1.5rem; }
    .btn-login { font-size: 1rem; }
}
</style>
</head>
<body>

<div class="login-container">
    <h1>Admin Restoran</h1>
    <p>Silakan masuk untuk mengelola restoran</p>

    <form method="POST" action="login.php" autocomplete="off" onsubmit="clearInputs()">
        <div class="mb-3">
            <input type="text" class="form-control" id="username" name="username" placeholder="Username" required autocomplete="off">
        </div>
        <div class="mb-3">
            <input type="password" class="form-control" id="password" name="password" placeholder="Password" required autocomplete="new-password">
        </div>
        <button type="submit" class="btn-login">Masuk</button>
    </form>
</div>

<div class="toast <?= $toastSuccess ? 'success' : 'error' ?>" id="toast"><?= htmlspecialchars($toastMessage) ?></div>

<script>
const toast = document.getElementById('toast');
const toastMessage = "<?= $toastMessage ?>";
if (toastMessage !== '') {
    toast.style.display = 'block';
    setTimeout(() => { toast.style.opacity = '1'; }, 50);
    setTimeout(() => { 
        toast.style.opacity = '0'; 
        setTimeout(() => { toast.style.display = 'none'; }, 500);
    }, 3000);
}

function clearInputs() {
    setTimeout(() => {
        document.getElementById('username').value = '';
        document.getElementById('password').value = '';
    }, 50);
}
</script>

</body>
</html>
