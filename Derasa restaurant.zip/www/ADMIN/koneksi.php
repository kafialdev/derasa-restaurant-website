<?php
// Config hosting (opsional): jika ada file ../config.php, akan dipakai.
$APP_DEBUG = false;
if (file_exists(__DIR__ . '/../config.php')) {
  require __DIR__ . '/../config.php';
}
if (!isset($servername)) { $servername = 'localhost'; }
if (!isset($username)) { $username = 'root'; }
if (!isset($password)) { $password = ''; }
if (!isset($dbname)) { $dbname = 'restaurant'; }
if (!function_exists('date_default_timezone_set')) { /* noop */ } else {
  @date_default_timezone_set('Asia/Jakarta');
}
if (!isset($APP_DEBUG)) { $APP_DEBUG = (($_SERVER['SERVER_NAME'] ?? '') === 'localhost'); }

error_reporting(E_ALL);
ini_set('display_errors', $APP_DEBUG ? '1' : '0');

// koneksi utama
$conn = mysqli_connect($servername, $username, $password, $dbname);

// jika gagal konek, hentikan lebih awal
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Pastikan timezone sesi MySQL = WIB
@mysqli_query($conn, "SET time_zone = '+07:00'");

// supaya file lama yang pakai $mysqli TETAP BISA
$mysqli = $conn;

// set charset
mysqli_set_charset($conn, "utf8");

/* =========================================================
   AUTO-SCHEMA (khusus tabel karyawan/team)
   Menghindari error di halaman user/admin jika database masih versi lama
   (contoh: Unknown column 'is_chef' / 'visible').
   ========================================================= */

function _tbl_exists(mysqli $conn, string $table): bool {
    $table = $conn->real_escape_string($table);
    $sql = "SHOW TABLES LIKE '{$table}'";
    $res = $conn->query($sql);
    $ok = ($res && $res->num_rows > 0);
    if ($res) $res->free();
    return $ok;
}

function _col_exists(mysqli $conn, string $table, string $col): bool {
    $table = $conn->real_escape_string($table);
    $col   = $conn->real_escape_string($col);
    $res = $conn->query("SHOW COLUMNS FROM `{$table}` LIKE '{$col}'");
    $ok = ($res && $res->num_rows > 0);
    if ($res) $res->free();
    return $ok;
}

function ensure_karyawan_schema(mysqli $conn): void {
    if (!_tbl_exists($conn, 'karyawan')) {
        // buat tabel jika belum ada
        $conn->query("CREATE TABLE IF NOT EXISTS karyawan (
          id INT NOT NULL AUTO_INCREMENT,
          nama VARCHAR(100) NOT NULL,
          posisi VARCHAR(50) DEFAULT NULL,
          deskripsi TEXT,
          is_chef TINYINT(1) NOT NULL DEFAULT 0,
          image VARCHAR(255) DEFAULT NULL,
          visible TINYINT(1) NOT NULL DEFAULT 1,
          dibuat_pada DATETIME DEFAULT CURRENT_TIMESTAMP,
          PRIMARY KEY (id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
        return;
    }

    // tambahkan kolom yang hilang (database versi lama)
    if (!_col_exists($conn, 'karyawan', 'deskripsi')) {
        $conn->query("ALTER TABLE karyawan ADD COLUMN deskripsi TEXT NULL AFTER posisi");
    }
    if (!_col_exists($conn, 'karyawan', 'is_chef')) {
        $conn->query("ALTER TABLE karyawan ADD COLUMN is_chef TINYINT(1) NOT NULL DEFAULT 0 AFTER deskripsi");
    }
    if (!_col_exists($conn, 'karyawan', 'image')) {
        $conn->query("ALTER TABLE karyawan ADD COLUMN image VARCHAR(255) NULL AFTER is_chef");
    }
    if (!_col_exists($conn, 'karyawan', 'visible')) {
        $conn->query("ALTER TABLE karyawan ADD COLUMN visible TINYINT(1) NOT NULL DEFAULT 1 AFTER image");
    }
    if (!_col_exists($conn, 'karyawan', 'dibuat_pada')) {
        $conn->query("ALTER TABLE karyawan ADD COLUMN dibuat_pada DATETIME NULL DEFAULT CURRENT_TIMESTAMP AFTER visible");
    }
}

// jalankan sekali saat koneksi dibuka
if ($conn instanceof mysqli) {
    ensure_karyawan_schema($conn);
}
?>
