<?php
include "../koneksi.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $nama       = $_POST["nama"];
    $posisi     = $_POST["posisi"];
    $deskripsi  = $_POST["deskripsi"];
    $is_chef    = isset($_POST["is_chef"]) ? 1 : 0;
    $visible    = isset($_POST["visible"]) ? 1 : 0;

    // Upload gambar
    $fileName = null;
    if (!empty($_FILES["image"]["name"])) {
        $fileName = time() . "_" . basename($_FILES["image"]["name"]);
        move_uploaded_file(
            $_FILES["image"]["tmp_name"],
            __DIR__ . "/../../uploads/" . $fileName
        );
    }

    // INSERT ke database
    $stmt = $conn->prepare("INSERT INTO karyawan 
        (nama, posisi, deskripsi, is_chef, image, visible) 
        VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssisi", $nama, $posisi, $deskripsi, $is_chef, $fileName, $visible);
    $stmt->execute();

    // Redirect
    header("Location: karyawan.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Tambah Karyawan</title>

    <style>
:root{
  --bg:#eef1f7;
  --card:#ffffff;
  --ink:#1f2937;
  --muted:#6b7280;
  --primary:#2563eb;
  --primary-2:#1d4ed8;
  --border:#e5e7eb;
  --shadow:0 14px 35px rgba(15,23,42,.08);
  --radius:18px;
}

*{box-sizing:border-box}
body{
  font-family:'Poppins',sans-serif;
  background:linear-gradient(135deg,#edf1f7,#f8fbff);
  margin:0;
  padding:26px;
  color:var(--ink);
}

.wrap{
  max-width:860px;
  margin:0 auto;
}

.card{
  background:var(--card);
  border-radius:var(--radius);
  box-shadow:var(--shadow);
  padding:26px;
  border:1px solid rgba(255,255,255,.7);
}

.top{
  display:flex;
  justify-content:space-between;
  align-items:flex-start;
  gap:14px;
  margin-bottom:18px;
}

h2{
  margin:0;
  font-size:30px;
  font-weight:800;
  letter-spacing:.2px;
}

.sub{
  margin-top:6px;
  color:var(--muted);
  font-size:14px;
}

.grid{
  display:grid;
  grid-template-columns:1fr 1fr;
  gap:14px;
}

.label{
  display:block;
  font-weight:700;
  margin:12px 0 8px;
  font-size:14px;
  color:#0f172a;
}

input[type="text"], textarea, input[type="file"]{
  width:100%;
  padding:12px 14px;
  border:1px solid var(--border);
  border-radius:14px;
  font-size:15px;
  background:#f9fbff;
  outline:none;
  transition:.18s ease;
}

textarea{ min-height:140px; resize:vertical; }

input[type="text"]:focus, textarea:focus, input[type="file"]:focus{
  border-color:#93c5fd;
  background:#fff;
  box-shadow:0 0 0 4px rgba(59,130,246,.12);
}

.checks{
  display:flex;
  gap:18px;
  flex-wrap:wrap;
  padding:10px 0 4px;
}

.check{
  display:flex;
  align-items:center;
  gap:10px;
  background:#f8fafc;
  border:1px solid var(--border);
  padding:10px 12px;
  border-radius:14px;
}

.check input{ width:18px; height:18px; }

.actions{
  display:flex;
  gap:12px;
  flex-wrap:wrap;
  margin-top:20px;
}

.btn{
  display:inline-flex;
  align-items:center;
  gap:10px;
  padding:12px 16px;
  border-radius:14px;
  border:1px solid transparent;
  font-weight:800;
  cursor:pointer;
  text-decoration:none;
  transition:.18s ease;
}

.btn-primary{
  background:var(--primary);
  color:#fff;
  box-shadow:0 10px 22px rgba(37,99,235,.18);
}
.btn-primary:hover{ background:var(--primary-2); transform:translateY(-1px); }

.btn-ghost{
  background:#fff;
  border-color:var(--border);
  color:var(--ink);
}
.btn-ghost:hover{ transform:translateY(-1px); }

.note{
  color:var(--muted);
  font-size:12px;
  margin-top:8px;
}

@media (max-width:720px){
  .grid{ grid-template-columns:1fr; }
  body{ padding:18px; }
  .card{ padding:20px; }
}
</style>
</head>

<body>

<div class="wrap">
  <div class="card">
    <div class="top">
      <div>
        <h2>Add Employees</h2>
        <div class="sub">Isi data karyawan. Centang <b>Show on Website</b> agar tampil di halaman Team pengguna.</div>
      </div>
      <a class="btn btn-ghost" href="karyawan.php">← Back</a>
    </div>

    <form method="POST" enctype="multipart/form-data">
      <div class="grid">
        <div>
          <label class="label">Name</label>
          <input type="text" name="nama" required placeholder="Contoh: Andi Pratama">
        </div>
        <div>
          <label class="label">Position</label>
          <input type="text" name="posisi" placeholder="Contoh: Barista / Kasir / Chef">
        </div>
      </div>

      <label class="label">Description</label>
      <textarea name="deskripsi" placeholder="Deskripsi singkat (opsional)"></textarea>

      <div class="checks">
        <label class="check">
          <input type="checkbox" name="is_chef">
          <span>Chef?</span>
        </label>
        <label class="check">
          <input type="checkbox" name="visible">
          <span>Show on Website?</span>
        </label>
      </div>

      <label class="label">Photo</label>
      <input type="file" name="image" accept=".jpg,.jpeg,.png,.webp">
      <div class="note">Format yang disarankan: JPG/PNG/WEBP, rasio 1:1 supaya foto bulat terlihat rapi.</div>

      <div class="actions">
        <button class="btn btn-primary" type="submit">Save</button>
        <a class="btn btn-ghost" href="karyawan.php">Cancel</a>
      </div>
    </form>
  </div>
</div>


</body>
</html>
