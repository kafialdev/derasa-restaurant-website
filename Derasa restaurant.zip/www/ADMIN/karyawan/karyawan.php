<?php
include "../koneksi.php";
$result = $conn->query("SELECT * FROM karyawan ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Karyawan</title>

<style>
:root{
  --bg:#eef1f7;
  --card:#ffffff;
  --ink:#1f2937;
  --muted:#6b7280;
  --primary:#2563eb;
  --primary-2:#1d4ed8;
  --danger:#ef4444;
  --border:#e5e7eb;
  --shadow:0 14px 35px rgba(15,23,42,.08);
  --radius:18px;
}

*{box-sizing:border-box}
body{
  margin:0;
  font-family:'Poppins',sans-serif;
  background:var(--bg);
  color:var(--ink);
  padding:28px;
}

.page{
  max-width:1100px;
  margin:0 auto;
}

.header{
  display:flex;
  align-items:flex-end;
  justify-content:space-between;
  gap:16px;
  margin-bottom:18px;
}

.header-actions{
  display:flex;
  align-items:center;
  gap:10px;
}

.header h2{
  margin:0;
  font-size:28px;
  font-weight:700;
  letter-spacing:.2px;
}

.header .sub{
  margin-top:6px;
  color:var(--muted);
  font-size:14px;
}

.btn{
  display:inline-flex;
  align-items:center;
  gap:10px;
  padding:10px 14px;
  border-radius:12px;
  font-weight:600;
  text-decoration:none;
  border:1px solid transparent;
  user-select:none;
  transition:.18s ease;
}

.btn-primary{
  background:var(--primary);
  color:#fff;
  box-shadow:0 10px 22px rgba(37,99,235,.18);
}
.btn-primary:hover{ background:var(--primary-2); transform:translateY(-1px); }

.btn-ghost{
  background:#fff;
  color:var(--ink);
  border-color:var(--border);
}
.btn-ghost:hover{ transform:translateY(-1px); }

.btn-danger{
  background:#fff;
  color:var(--danger);
  border-color:#fecaca;
}
.btn-danger:hover{ background:#fff1f2; transform:translateY(-1px); }

.card{
  background:var(--card);
  border-radius:var(--radius);
  box-shadow:var(--shadow);
  border:1px solid rgba(255,255,255,.6);
  overflow:hidden;
}

.table-wrap{
  width:100%;
  overflow:auto;
}

table{
  width:100%;
  border-collapse:separate;
  border-spacing:0;
  min-width:840px;
}

thead th{
  text-align:left;
  font-size:13px;
  letter-spacing:.3px;
  color:#0f172a;
  background:#0b5ed7;
  color:#fff;
  padding:14px 16px;
  position:sticky;
  top:0;
  z-index:1;
}

thead th:first-child{ border-top-left-radius:var(--radius); }
thead th:last-child{ border-top-right-radius:var(--radius); }

tbody td{
  padding:14px 16px;
  border-bottom:1px solid var(--border);
  vertical-align:middle;
  font-size:14px;
  color:var(--ink);
  background:#fff;
}

tbody tr:hover td{ background:#f8fafc; }

.badge{
  display:inline-flex;
  align-items:center;
  padding:6px 10px;
  border-radius:999px;
  font-size:12px;
  font-weight:700;
  border:1px solid var(--border);
  color:var(--muted);
  background:#f9fafb;
}
.badge.ok{ color:#0f766e; border-color:#99f6e4; background:#f0fdfa; }
.badge.no{ color:#b91c1c; border-color:#fecaca; background:#fff1f2; }

.actions{
  display:flex;
  flex-wrap:wrap;
  gap:10px;
}

.avatar{
  width:52px;
  height:52px;
  border-radius:999px;
  object-fit:cover;
  border:3px solid #eef2ff;
  box-shadow:0 3px 10px rgba(2,6,23,.10);
}

.empty{
  padding:26px;
  color:var(--muted);
  text-align:center;
  font-size:14px;
}

@media (max-width:640px){
  body{ padding:18px; }
  .header{ flex-direction:column; align-items:flex-start; }
  .header-actions{ width:100%; }
  .header-actions .btn{ width:100%; justify-content:center; }
  table{ min-width:760px; }
}
</style>

</head>
<body>
<div class="page">
  <div class="header">
    <div>
      <h2>Employee Data</h2>
      <div class="sub">Kelola data karyawan (nama, posisi, foto) dan atur apakah tampil di website.</div>
    </div>
    <div class="header-actions">
      <a href="../index.php" class="btn btn-ghost">← Back to Dashboard</a>
      <a href="tambah_karyawan.php" class="btn btn-primary">+ Add Employee</a>
    </div>
  </div>

  <div class="card">
    <div class="table-wrap">
      <table>
        <thead>
          <tr>
            <th style="width:90px;">Photo</th>
            <th>Name</th>
            <th>Position</th>
            <th style="width:120px;">Chef?</th>
            <th style="width:160px;">Show on Website?</th>
            <th style="width:210px;">Action</th>
          </tr>
        </thead>
        <tbody>
          <?php if($result && $result->num_rows > 0){ ?>
            <?php while($row = $result->fetch_assoc()) { ?>
              <tr>
                <td>
                  <?php if(!empty($row['image'])) { ?>
                    <img class="avatar" src="../../uploads/<?= htmlspecialchars($row['image']) ?>" alt="photo">
                  <?php } else { ?>
                    <div class="badge">No Photo</div>
                  <?php } ?>
                </td>
                <td><?= htmlspecialchars($row['nama']) ?></td>
                <td><?= htmlspecialchars($row['posisi']) ?></td>
                <td>
                  <?php if($row['is_chef']){ ?>
                    <span class="badge ok">Yes</span>
                  <?php } else { ?>
                    <span class="badge">No</span>
                  <?php } ?>
                </td>
                <td>
                  <?php if($row['visible']){ ?>
                    <span class="badge ok">Shown</span>
                  <?php } else { ?>
                    <span class="badge no">Hidden</span>
                  <?php } ?>
                </td>
                <td>
                  <div class="actions">
                    <a class="btn btn-ghost" href="edit_karyawan.php?id=<?= (int)$row['id'] ?>">Edit</a>
                    <a class="btn btn-danger" href="hapus_karyawan.php?id=<?= (int)$row['id'] ?>" onclick="return confirm('Yakin ingin menghapus?')">Delete</a>
                  </div>
                </td>
              </tr>
            <?php } ?>
          <?php } else { ?>
            <tr>
              <td colspan="6">
                <div class="empty">Belum ada data karyawan. Klik <b>Add Employee</b> untuk menambahkan.</div>
              </td>
            </tr>
          <?php } ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
</body>
</html>
