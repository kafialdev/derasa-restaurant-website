<?php
include "../koneksi.php";

$id = $_GET["id"];

$conn->query("DELETE FROM karyawan WHERE id=$id");

header("Location: karyawan.php");
exit;
?>
