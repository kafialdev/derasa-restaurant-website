<?php
// ====================
// 🔧 AKTIFKAN ERROR DEBUG + TIMEZONE
// ====================
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Jakarta');

// ====================
// 🔗 KONEKSI DATABASE
// ====================
require_once __DIR__ . '/../koneksi.php';
if (!isset($mysqli) || $mysqli->connect_error) {
    die('❌ Koneksi database gagal: ' . $mysqli->connect_error);
}

// ====================
// 📅 FILTER TANGGAL
// ====================
$tanggalMulai   = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-d');
$tanggalSelesai = isset($_GET['end_date'])   ? $_GET['end_date']   : date('Y-m-d');

// ====================
// 🧾 AMBIL REVIEW TERFILTER TANGGAL
// ====================
$stmt = $mysqli->prepare("
    SELECT r.id,
           p.pelanggan AS name,
           r.rating    AS star,
           r.saran     AS comment,
           r.created_at AS time
    FROM order_ratings r
    JOIN pesanan_masuk p ON p.id = r.order_id
    WHERE DATE(r.created_at) BETWEEN ? AND ?
    ORDER BY r.created_at DESC
");
$stmt->bind_param("ss", $tanggalMulai, $tanggalSelesai);
$stmt->execute();
$result = $stmt->get_result();

// ====================
// 🔢 HITUNG RINGKASAN
// ====================
$totalReview = 0;
$totalStar   = 0;
$rows        = [];
$starCount   = [1 => 0, 2 => 0, 3 => 0, 4 => 0, 5 => 0];

while ($row = $result->fetch_assoc()) {
    $rows[] = $row;
    $totalReview++;
    $totalStar += (int)$row['star'];

    $s = (int)$row['star'];
    if ($s >= 1 && $s <= 5) {
        $starCount[$s]++;
    }
}

$avgStar = $totalReview > 0 ? round($totalStar / $totalReview, 1) : 0;
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>⭐ Laporan Review Pelanggan</title>
<style>
    :root{
        --primary:#007bff;
        --primary-dark:#0056b3;
        --bg:#eef4ff;
        --card:#ffffff;
        --border:#e3e8f5;
        --text:#1f2a44;
        --muted:#6b7280;
    }
    *{box-sizing:border-box}
    body{
        font-family:"Poppins", Arial, sans-serif;
        background:var(--bg);
        margin:0;
        padding:40px 16px;
        color:var(--text);
    }
    .wrap{
        max-width:1200px;
        margin:0 auto;
        background:var(--card);
        border-radius:18px;
        box-shadow:0 12px 28px rgba(0,0,0,.07);
        overflow:hidden;
    }

    /* HEADER */
    .header{
        padding:24px 28px;
        border-bottom:1px solid var(--border);
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:16px;
        flex-wrap:wrap;
        background:#fff;
    }
    .header h1{
        margin:0;
        font-size:1.5rem;
        color:#1a237e;
        letter-spacing:.2px;
    }
    .actions{
        display:flex;
        gap:10px;
        flex-wrap:wrap;
    }
    .btn{
        background:var(--primary);
        color:#fff;
        padding:10px 14px;
        border-radius:8px;
        text-decoration:none;
        display:inline-flex;
        align-items:center;
        gap:8px;
        border:none;
        cursor:pointer;
        font-weight:600;
        font-size:.92rem;
        box-shadow:0 6px 14px rgba(0,123,255,.25);
        transition:.2s;
    }
    .btn:hover{
        background:var(--primary-dark);
        transform:translateY(-2px);
    }
    .btn.secondary{
        background:#e8eefc;
        color:#1a237e;
        box-shadow:none;
    }
    .btn.secondary:hover{
        background:#d8e4ff;
    }

    /* FILTER BAR */
    .filters{
        padding:18px 28px 8px 28px;
        display:flex;
        flex-wrap:wrap;
        gap:10px;
        align-items:center;
        background:#fff;
    }
    .filters label{
        font-weight:600;
    }
    .filters input[type="date"]{
        padding:9px 10px;
        border:1px solid var(--border);
        border-radius:8px;
        outline:none;
        background:#fff;
        min-width:180px;
    }
    .preset{
        display:flex;
        gap:8px;
        flex-wrap:wrap;
        margin-left:auto;
    }
    .chip{
        border:1px solid var(--border);
        background:#fff;
        padding:8px 12px;
        border-radius:999px;
        cursor:pointer;
        font-weight:600;
        font-size:.88rem;
        color:#374151;
        transition:.15s;
    }
    .chip:hover{
        border-color:var(--primary);
        color:var(--primary);
    }

    /* SUMMARY */
    .summary{
        margin:12px 28px 18px 28px;
        display:grid;
        grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
        gap:14px;
    }
    .card{
        background:#f8fbff;
        border:1px solid #dce4f9;
        border-radius:12px;
        padding:14px 18px;
        box-shadow:0 4px 14px rgba(0,123,255,.08);
    }
    .card .label{
        font-size:.86rem;
        color:var(--muted);
        margin-bottom:6px;
    }
    .card .value{
        font-size:1.3rem;
        font-weight:800;
        color:#1a237e;
    }
    .card .extra{
        font-size:.85rem;
        margin-top:4px;
        color:var(--muted);
    }

    .subtle{
        color:var(--muted);
        font-size:.9rem;
        margin:4px 28px 16px 28px;
        text-align:center;
    }

    /* TABLE */
    .table-wrap{
        background:#fff;
        border-top:1px solid var(--border);
    }
    .table-scroll{
        overflow:auto;
        max-height:65vh;
    }
    table{
        width:100%;
        border-collapse:separate;
        border-spacing:0;
        min-width:800px;
    }
    thead th{
        position:sticky;
        top:0;
        z-index:1;
        background:var(--primary);
        color:#fff;
        text-align:center;
        padding:12px 14px;
        font-weight:700;
        border-bottom:1px solid var(--border);
        font-size:.95rem;
    }
    tbody td{
        border-bottom:1px solid var(--border);
        text-align:center;
        padding:12px 14px;
        background:#fff;
        font-size:.93rem;
    }
    tbody tr:nth-child(even) td{ background:#fbfdff; }
    tbody tr:hover td{ background:#f2f7ff; }

    .right{text-align:right}

    /* STAR BADGE */
    .star-badge{
        display:inline-flex;
        align-items:center;
        justify-content:center;
        gap:4px;
        padding:6px 10px;
        border-radius:999px;
        background:#fff7e6;
        border:1px solid #ffdf9a;
        font-size:.85rem;
        font-weight:600;
        color:#9a6b00;
    }
    .star-badge span.star-icon{
        color:#f59e0b;
        font-size:1rem;
    }

    /* PRINT */
    @media print{
        body{background:#fff;padding:0}
        .header,.filters,.preset,.actions,.subtle{display:none!important}
        .wrap{box-shadow:none;border-radius:0}
        thead th{background:#ddd!important;color:#000!important;-webkit-print-color-adjust:exact}
    }

    @media (max-width:680px){
        .header{padding:18px}
        .filters{padding:16px}
        .summary{margin:10px 18px}
    }
</style>
</head>
<body>
<div class="wrap">
    <!-- HEADER -->
    <div class="header">
        <h1>⭐ Laporan Review Pelanggan</h1>
        <div class="actions">
            <a class="btn" href="#" onclick="location.reload()">🔄 Refresh</a>
            <!-- balik ke halaman daftar laporan (masih satu folder /laporan/) -->
            <a class="btn secondary" href="laporan.php">⬅ Kembali ke Laporan</a>
            <button class="btn" onclick="window.print()">🖨️ Cetak</button>
        </div>
    </div>

    <!-- FILTER TANGGAL -->
    <form class="filters" method="get">
        <label for="sd">Dari</label>
        <input id="sd" type="date" name="start_date" value="<?= htmlspecialchars($tanggalMulai) ?>">
        <label for="ed">Sampai</label>
        <input id="ed" type="date" name="end_date" value="<?= htmlspecialchars($tanggalSelesai) ?>">
        <button class="btn" type="submit">Tampilkan</button>

        <div class="preset">
            <span class="chip" onclick="setRange('today')">Hari Ini</span>
            <span class="chip" onclick="setRange('week')">Minggu Ini</span>
            <span class="chip" onclick="setRange('month')">Bulan Ini</span>
        </div>
    </form>

    <!-- RINGKASAN -->
    <div class="summary">
        <div class="card">
            <div class="label">
                Total Review
                (<?= date('d M Y', strtotime($tanggalMulai)) ?> – <?= date('d M Y', strtotime($tanggalSelesai)) ?>)
            </div>
            <div class="value"><?= number_format($totalReview, 0, ',', '.') ?></div>
        </div>
        <div class="card">
            <div class="label">Rating Rata-rata</div>
            <div class="value"><?= number_format($avgStar, 1, ',', '.') ?> / 5.0</div>
            <div class="extra">
                <?php if ($totalReview > 0): ?>
                    Berdasarkan <?= $totalReview ?> review.
                <?php else: ?>
                    Belum ada review pada rentang tanggal ini.
                <?php endif; ?>
            </div>
        </div>
        <div class="card">
            <div class="label">Distribusi Bintang</div>
            <div class="extra">
                5⭐: <?= $starCount[5] ?> &nbsp;·&nbsp;
                4⭐: <?= $starCount[4] ?> &nbsp;·&nbsp;
                3⭐: <?= $starCount[3] ?> &nbsp;·&nbsp;
                2⭐: <?= $starCount[2] ?> &nbsp;·&nbsp;
                1⭐: <?= $starCount[1] ?>
            </div>
        </div>
    </div>

    <p class="subtle">
        Menampilkan review dari <b><?= date('d M Y', strtotime($tanggalMulai)) ?></b>
        hingga <b><?= date('d M Y', strtotime($tanggalSelesai)) ?></b>.
    </p>

    <!-- TABEL REVIEW -->
    <div class="table-wrap">
        <div class="table-scroll">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Waktu</th>
                        <th>Nama Pelanggan</th>
                        <th>Rating</th>
                        <th>Komentar</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (count($rows) > 0): ?>
                    <?php foreach ($rows as $r): ?>
                        <tr>
                            <td>#<?= str_pad($r['id'], 3, '0', STR_PAD_LEFT) ?></td>
                            <td><?= htmlspecialchars($r['time']) ?></td>
                            <td><?= htmlspecialchars($r['name']) ?></td>
                            <td>
                                <div class="star-badge">
                                    <span class="star-icon">⭐</span>
                                    <span><?= (int)$r['star'] ?> / 5</span>
                                </div>
                            </td>
                            <td><?= nl2br(htmlspecialchars($r['comment'])) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="5" style="color:#6b7280">Tidak ada review untuk rentang tanggal ini.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
// Preset tanggal berbasis WAKTU LOKAL (hindari toISOString/UTC)
function pad(n){ return n < 10 ? '0' + n : n; }
function ymdLocal(d){
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
}
function setRange(type){
  const sd = document.querySelector('[name=start_date]');
  const ed = document.querySelector('[name=end_date]');
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate()); // 00:00 lokal

  if(type === 'today'){
    sd.value = ymdLocal(today);
    ed.value = ymdLocal(today);
  }
  if(type === 'week'){
    // Mulai Senin
    const w = new Date(today);
    const day = w.getDay() || 7; // 1=Senin, 7=Minggu
    w.setDate(w.getDate() - day + 1);
    sd.value = ymdLocal(w);
    ed.value = ymdLocal(today);
  }
  if(type === 'month'){
    const m1 = new Date(today.getFullYear(), today.getMonth(), 1);
    sd.value = ymdLocal(m1);
    ed.value = ymdLocal(today);
  }
  sd.form.submit();
}
</script>
</body>
</html>
<?php
// ====================
// 🔒 TUTUP KONEKSI
// ====================
if (isset($stmt)) $stmt->close();
if (isset($result) && $result instanceof mysqli_result) $result->free();
if (isset($mysqli) && $mysqli instanceof mysqli) $mysqli->close();
?>
