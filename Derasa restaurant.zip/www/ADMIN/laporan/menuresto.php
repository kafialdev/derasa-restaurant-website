<?php
// ====================
// 🔧 DEBUG + TIMEZONE
// ====================
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Jakarta');

// ====================
// 🔗 KONEKSI
// ====================
require_once __DIR__ . '/../koneksi.php';
if (!isset($mysqli) || !$mysqli) {
    die('❌ Koneksi database belum tersedia.');
}

// ====================
// 📅 FILTER BESTSELLER
// ====================
$start = $_GET['start_date'] ?? date('Y-m-d');
$end   = $_GET['end_date']   ?? date('Y-m-d');

// ====================
// 🧾 QUERY MENU — SESUAI DATABASE KAMU
// ====================
$sqlMenu = "
    SELECT id, nama_menu, kategori, harga, stok, status, deskripsi, gambar
    FROM menu_restaurant
    ORDER BY id ASC
";
$menus = $mysqli->query($sqlMenu)->fetch_all(MYSQLI_ASSOC);

// ====================
// 🏆 QUERY BEST SELLER
// ====================
$stmt = $mysqli->prepare("
    SELECT d.nama_menu,
           SUM(d.qty) AS terjual,
           SUM(d.qty * d.harga) AS omzet
    FROM detail_pesanan d
    JOIN pesanan_masuk p ON p.id = d.order_id
    WHERE DATE(p.waktu) BETWEEN ? AND ?
    GROUP BY d.nama_menu
    ORDER BY terjual DESC
    LIMIT 10
");
$stmt->bind_param('ss', $start, $end);
$stmt->execute();
$bestsellers = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>🍽️ Daftar Menu Restoran</title>

<style>
/* ============================================================
   🌟 PREMIUM DASHBOARD CSS – CLEAN, MODERN & PROFESSIONAL
   ============================================================ */

:root {
    --primary: #3B82F6;
    --primary-dark: #1E40AF;
    --border: #E5E7EB;
    --text: #111827;
    --muted: #6B7280;
    --bg: #F3F4F6;
    --card: #FFFFFF;

    --green: #059669;
    --green-bg: #ECFDF5;

    --red: #DC2626;
    --red-bg: #FEF2F2;

    --warn: #D97706;
    --warn-bg: #FFFBEB;

    --radius: 14px;
    --shadow: 0 6px 20px rgba(0,0,0,0.06);
}

body {
    font-family: "Poppins", sans-serif;
    margin: 0;
    padding: 26px 14px;
    background: var(--bg);
    color: var(--text);
}

.header {
    background: var(--card);
    padding: 16px 20px;
    border-radius: var(--radius);
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: var(--shadow);
    border: 1px solid var(--border);
}

.header h1 {
    margin: 0;
    font-size: 1.25rem;
    font-weight: 700;
    color: var(--primary-dark);
}

.btn {
    padding: 8px 14px;
    border-radius: 8px;
    border: none;
    cursor: pointer;
    font-weight: 600;
    background: var(--primary);
    color: #fff;
    transition: 0.25s ease;
    box-shadow: 0 4px 10px rgba(59,130,246,0.25);
}

.btn:hover { background: var(--primary-dark); }
.btn.secondary { background: #E0E7FF; color: var(--primary-dark); box-shadow:none; }

.grid {
    margin-top: 16px;
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 16px;
}
@media (max-width:1000px){ .grid { grid-template-columns:1fr; } }

.panel {
    background: var(--card);
    border-radius: var(--radius);
    border: 1px solid var(--border);
    box-shadow: var(--shadow);
    overflow: hidden;
}

/* TABLE MENU */
.table-scroll { max-height: 70vh; overflow-y:auto; }

table { width:100%; border-collapse: separate; border-spacing:0; }

thead th {
    background: var(--primary);
    color: #fff;
    padding: 12px;
    text-align:center;
    position:sticky;
    top:0;
}

tbody td {
    padding: 10px;
    border-bottom: 1px solid var(--border);
    background:#fff;
}

tbody tr:hover td { background:#F3F4F6; }

.status-badge {
    padding: 5px 12px;
    border-radius: 30px;
    font-size: 0.78rem;
    font-weight: 600;
}

.ok { background: var(--green-bg); color: var(--green); }
.no { background: var(--red-bg);   color: var(--red); }
.warn{ background: var(--warn-bg); color: var(--warn); }

.thumb {
    width: 60px;
    height: 60px;
    border-radius: 10px;
    object-fit: cover;
    border:1px solid var(--border);
    box-shadow:0 3px 6px rgba(0,0,0,0.08);
}
.kiri{ text-align:left; }
.right{ text-align:right; }
.muted{ color:var(--muted); }

/* BEST SELLER PANEL */
.side-head {
    padding:14px 16px;
    font-weight:700;
    background:#F9FAFB;
    border-bottom:1px solid var(--border);
    color:var(--primary-dark);
}

.filters {
    padding:14px;
    display:flex;
    flex-wrap:wrap;
    gap:10px;
}
.filters input[type=date]{
    padding:8px; border:1px solid var(--border);
    border-radius:8px; background:#fff;
}

/* Print */
@media print {
    .actions, .filters { display:none!important; }
}
</style>

</head>
<body>

<div class="shell">

  <div class="header">
    <h1>🍽️ Daftar Menu Restoran</h1>
    <div class="actions">
      <a class="btn secondary" href="laporan.php">⬅ Kembali</a>
      <a class="btn" onclick="location.reload()">🔄 Refresh</a>
      <button class="btn" onclick="window.print()">🖨 Cetak</button>
    </div>
  </div>

  <div class="grid">

    <!-- ==========================
         PANEL MENU KIRI
    =========================== -->
    <div class="panel">
      <div class="table-scroll">
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Nama Menu</th>
              <th>Kategori</th>
              <th>Harga</th>
              <th>Stok</th>
              <th>Status</th>
              <th>Deskripsi</th>
              <th>Gambar</th>
            </tr>
          </thead>

          <tbody>
          <?php foreach ($menus as $m): ?>

            <?php
            /* ===================================================================
               FIX GAMBAR — PATH OTOMATIS SESUAI STRUKTUR FOLDER KAMU
               (DB menyimpan: filename saja / uploads/... / ADMIN/uploads/... )
               =================================================================== */
            $img = trim((string)($m['gambar'] ?? ''));

            if ($img !== "") {
                // buang query string + slash depan
                $img = preg_replace('/\?.*$/', '', $img);
                $img = ltrim($img, '/');

                $lower = strtolower($img);

                // kalau masih format lama: ADMIN/uploads/xxx.jpg
                if (strpos($lower, 'admin/uploads/') === 0) {
                    $img = '../uploads/' . basename($img);
                }
                // kalau format: uploads/xxx.jpg
                else if (strpos($lower, 'uploads/') === 0) {
                    $img = '../' . $img; // dari /ADMIN/laporan -> ../uploads/xxx.jpg
                }
                // kalau cuma filename
                else {
                    $img = '../uploads/' . basename($img);
                }
            }
            ?>

            <tr>
              <td>#<?= $m['id'] ?></td>
              <td><?= htmlspecialchars($m['nama_menu']) ?></td>
              <td><?= htmlspecialchars($m['kategori']) ?></td>
              <td class="right">Rp <?= number_format($m['harga'],0,',','.') ?></td>
              <td><?= $m['stok'] ?></td>

              <td>
                <?php 
                  $status = strtolower($m['status']);
                  $cls = ($status === 'tersedia') ? 'ok' : (($status === 'habis') ? 'no' : 'warn');
                ?>
                <span class="status-badge <?= $cls ?>"><?= $m['status'] ?></span>
              </td>

              <td class="kiri"><?= $m['deskripsi'] ?: '-' ?></td>

              <td>
                <?php if (!empty($img)): ?>
                  <img src="<?= $img ?>" class="thumb">
                <?php else: ?>
                  <span class="muted">Tidak ada</span>
                <?php endif; ?>
              </td>
            </tr>

          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>

    <!-- ==========================
         PANEL MENU TERLARIS
    =========================== -->
    <div class="panel">
      <div class="side-head"><h2>🏆 Menu Terlaris</h2></div>

      <form class="filters" method="get">
        <label>Dari</label>
        <input type="date" name="start_date" value="<?= $start ?>">

        <label>Sampai</label>
        <input type="date" name="end_date" value="<?= $end ?>">

        <button class="btn">Tampilkan</button>
      </form>

      <div class="side-body">
        <table class="rank">
          <thead>
            <tr>
              <th>#</th>
              <th class="kiri">Nama Menu</th>
              <th>Terjual</th>
              <th>Omzet</th>
            </tr>
          </thead>

          <tbody>
          <?php if ($bestsellers): $i=1; ?>
            <?php foreach ($bestsellers as $b): ?>
            <tr>
              <td><?= $i++ ?></td>
              <td class="kiri"><?= $b['nama_menu'] ?></td>
              <td><?= $b['terjual'] ?></td>
              <td class="right">Rp <?= number_format($b['omzet'],0,',','.') ?></td>
            </tr>
            <?php endforeach; ?>
          <?php else: ?>
            <tr><td colspan="4" class="muted">Belum ada data</td></tr>
          <?php endif; ?>
          </tbody>
        </table>
      </div>

    </div>

  </div>

</div>

</body>
</html>
