<?php
// ====================
// 🔧 DEBUG (boleh dimatikan di produksi)
// ====================
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan | Admin Restoran</title>
    <style>
        /* 🌐 Global Layout */
        * {
            box-sizing: border-box;
        }
        body {
            font-family: 'Poppins', Arial, sans-serif;
            background: linear-gradient(135deg, #e8f0ff, #f7f9fc);
            margin: 0;
            padding: 0;
            color: #2c3e50;
        }

        /* 🧭 Container */
        .container {
            max-width: 1100px;
            margin: 60px auto;
            background: #ffffff;
            border-radius: 16px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.08);
            padding: 50px;
            animation: fadeIn 0.6s ease-in-out;
        }

        /* ✨ Header */
        h1 {
            text-align: center;
            font-size: 2rem;
            color: #1a237e;
            margin-bottom: 35px;
            position: relative;
        }
        h1::after {
            content: '';
            width: 80px;
            height: 3px;
            background: #007bff;
            display: block;
            margin: 12px auto 0;
            border-radius: 2px;
        }

        /* 🔝 Topbar */
        .topbar {
            text-align: center;
            margin-bottom: 40px;
        }
        .topbar a {
            background: #007bff;
            color: #fff;
            padding: 10px 18px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 500;
            box-shadow: 0 4px 10px rgba(0,123,255,0.3);
            transition: 0.3s;
        }
        .topbar a:hover {
            background: #0056b3;
            transform: translateY(-2px);
        }

        /* 📦 Card Grid */
        .card-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
            gap: 30px;
        }

        /* 🧾 Cards */
        .card {
            background: #f8fbff;
            border: 1px solid #e4e9f7;
            border-radius: 14px;
            padding: 30px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0,0,0,0.06);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        .card:hover {
            transform: translateY(-8px);
            box-shadow: 0 10px 25px rgba(0,123,255,0.15);
            background: #eef5ff;
        }
        .card h2 {
            font-size: 1.4rem;
            color: #007bff;
            margin-bottom: 12px;
        }
        .card p {
            color: #555;
            font-size: 15px;
            margin-bottom: 18px;
            line-height: 1.5;
        }
        a.btn {
            display: inline-block;
            background: #007bff;
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 6px;
            font-weight: 600;
            transition: 0.3s;
            box-shadow: 0 3px 10px rgba(0,123,255,0.3);
        }
        a.btn:hover {
            background: #0056b3;
            transform: translateY(-2px);
        }

        /* 🎨 Icon */
        .emoji {
            font-size: 42px;
            margin-bottom: 12px;
            display: block;
        }

        /* 🪶 Animation */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* 📱 Responsiveness */
        @media (max-width: 768px) {
            .container {
                margin: 30px 15px;
                padding: 30px 20px;
            }
            h1 {
                font-size: 1.7rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>📊 Laporan Restoran</h1>

        <div class="topbar">
            <!-- Dari /ADMIN/laporan/laporan.php kembali ke /ADMIN/index.php -->
            <a href="../index.php">⬅ Kembali ke Dashboard</a>
        </div>

        <div class="card-grid">

            <!-- Laporan Pesanan Masuk -->
            <div class="card">
                <span class="emoji">🧾</span>
                <h2>Laporan Pesanan Masuk</h2>
                <p>Lihat semua data pesanan yang baru masuk dan statusnya secara detail.</p>
                <!-- admin.php berisi rekap pesanan_masuk -->
                <a href="admin.php" class="btn">Lihat Laporan</a>
            </div>

            <!-- Laporan Detail Pesanan -->
            <div class="card">
                <span class="emoji">📋</span>
                <h2>Laporan Detail Pesanan</h2>
                <p>Tampilkan rincian lengkap setiap pesanan pelanggan untuk pengecekan data.</p>
                <!-- detail.php yang tadi sudah kita integrasikan -->
                <a href="detail.php" class="btn">Lihat Detail</a>
            </div>

            <!-- Laporan Menu Restoran -->
            <div class="card">
                <span class="emoji">🍽️</span>
                <h2>Laporan Menu Restoran</h2>
                <p>Lihat daftar menu yang tersedia lengkap dengan status dan deskripsi.</p>
                <a href="menuresto.php" class="btn">Lihat Menu</a>
            </div>

            <!-- ⭐ Laporan Review Pelanggan -->
            <div class="card">
                <span class="emoji">⭐</span>
                <h2>Laporan Review Pelanggan</h2>
                <p>Lihat semua ulasan dan rating pelanggan secara lengkap dan akurat.</p>
                <a href="reviewpelanggan.php" class="btn">Lihat Review</a>
            </div>

        </div> <!-- /.card-grid -->
    </div> <!-- /.container -->
</body>
</html>
