<?php
// ==========================
// DEBUG + TIMEZONE
// ==========================
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Jakarta');

// ==========================
// KONEKSI DB
// ==========================
require_once __DIR__ . '/../koneksi.php';
if (!$mysqli) {
    die("❌ Koneksi DB gagal.");
}

// ==========================
// PARAM
// ==========================
$orderId = isset($_GET['order_id']) ? (int)$_GET['order_id'] : null;
$start   = $_GET['start_date'] ?? date('Y-m-d');
$end     = $_GET['end_date']   ?? date('Y-m-d');

$title = $orderId
    ? "Detail Pesanan #" . str_pad($orderId, 3, '0', STR_PAD_LEFT)
    : "Detail Pesanan (Terfilter Tanggal)";

// ==========================
// QUERY UTAMA
// ==========================
$rows = [];
$totalNilai = 0;
$grandTotal = 0;

// =======================================================
// MODE 1 — DETAIL UNTUK ORDER ID TERTENTU
// =======================================================
if ($orderId) {

    $stmt = $mysqli->prepare("
        SELECT d.id, d.order_id, d.menu_id, d.nama_menu, d.qty, d.harga
        FROM detail_pesanan d
        WHERE d.order_id = ?
        ORDER BY d.id ASC
    ");
    $stmt->bind_param("i", $orderId);
    $stmt->execute();
    $res = $stmt->get_result();

    while ($r = $res->fetch_assoc()) {
        $r['subtotal'] = $r['qty'] * $r['harga'];
        $grandTotal += $r['subtotal'];
        $rows[] = $r;
    }
    $stmt->close();
}

// =======================================================
// MODE 2 — FILTER TANGGAL (SEMUA ORDER, TANPA FILTER STATUS)
// =======================================================
else {

    $stmt = $mysqli->prepare("
        SELECT 
            d.id, d.order_id, d.menu_id, d.nama_menu, d.qty, d.harga,
            DATE(p.waktu) AS tgl
        FROM detail_pesanan d
        JOIN pesanan_masuk p ON p.id = d.order_id
        WHERE DATE(p.waktu) BETWEEN ? AND ?
        ORDER BY d.order_id DESC, d.id ASC
    ");
    $stmt->bind_param("ss", $start, $end);
    $stmt->execute();
    $res = $stmt->get_result();

    while ($r = $res->fetch_assoc()) {
        $r['subtotal'] = $r['qty'] * $r['harga'];
        $totalNilai += $r['subtotal'];
        $rows[] = $r;
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $title ?></title>

<!-- ============================
     PREMIUM UI (TIDAK DIUBAH)
=============================== -->
<style>
:root{
    --primary:#007bff; --primary-dark:#0056b3;
    --bg:#eef4ff; --card:#ffffff; --border:#e3e8f5;
    --text:#1f2a44; --muted:#6b7280;
}
body{
    font-family:"Poppins",sans-serif;
    background:var(--bg);
    margin:0;
    padding:36px 14px;
    color:var(--text);
}
.wrap{
    max-width:1200px;
    margin:auto;
    background:var(--card);
    border-radius:18px;
    box-shadow:0 10px 28px rgba(0,0,0,.08);
    overflow:hidden;
}
.header{
    padding:22px 26px;
    background:#fff;
    display:flex;
    justify-content:space-between;
    flex-wrap:wrap;
    border-bottom:1px solid var(--border);
}
.header h1{
    margin:0;
    font-size:1.35rem;
    font-weight:700;
    color:#1a237e;
}
.actions{ display:flex; gap:10px; flex-wrap:wrap; }
.btn{
    background:var(--primary);
    border:none;
    padding:10px 16px;
    color:white;
    font-weight:600;
    border-radius:8px;
    cursor:pointer;
    text-decoration:none;
    transition:.2s;
}
.btn:hover{ background:var(--primary-dark); }
.btn.secondary{ background:#e8eefc; color:#1a237e; }
.btn.secondary:hover{ background:#dbe5ff; }

.filters{
    padding:18px 26px;
    background:#fff;
    border-bottom:1px solid var(--border);
    display:flex;
    flex-wrap:wrap;
    gap:12px;
}
.filters input[type="date"]{
    padding:8px 10px;
    border-radius:8px;
    border:1px solid var(--border);
}
.chip{
    padding:7px 12px;
    border-radius:20px;
    border:1px solid var(--border);
    cursor:pointer;
    font-weight:600;
}
.chip:hover{ border-color:var(--primary); color:var(--primary); }

.table-wrap{ background:#fff; }
.table-scroll{ overflow:auto; max-height:65vh; }
table{
    width:100%;
    min-width:900px;
    border-collapse:separate;
}
thead th{
    position:sticky; top:0;
    background:var(--primary);
    color:white;
    padding:12px;
    font-size:.9rem;
}
tbody td{
    padding:12px;
    font-size:.9rem;
    border-bottom:1px solid var(--border);
}
tbody tr:nth-child(even) td{
    background:#f8fbff;
}
tbody tr:hover td{
    background:#eef4ff;
}
.badge{
    background:#eef4ff;
    padding:6px 10px;
    border-radius:20px;
    font-size:.78rem;
    font-weight:700;
    border:1px solid #cfd8ff;
}
.order-link{
    color:#0056d6;
    text-decoration:none;
    font-weight:700;
}
.order-link:hover{ text-decoration:underline; }

.total-row td{
    background:#f4f8ff;
    font-weight:800;
}
</style>
</head>
<body>

<div class="wrap">

    <div class="header">
        <h1>🧾 <?= $title ?></h1>

        <div class="actions">
            <a class="btn" href="#" onclick="location.reload()">🔄 Refresh</a>
            <a class="btn secondary" href="laporan.php">⬅ Data Pesanan</a>

            <?php if ($orderId): ?>
                <a class="btn secondary" href="detail.php">📄 Lihat Semua Detail</a>
            <?php endif; ?>

            <button class="btn" onclick="window.print()">🖨 Cetak</button>
        </div>
    </div>

    <?php if (!$orderId): ?>
    <form class="filters" method="get">
        <label>Dari</label>
        <input type="date" name="start_date" value="<?= $start ?>">
        <label>Sampai</label>
        <input type="date" name="end_date" value="<?= $end ?>">

        <button class="btn">Tampilkan</button>

        <span class="chip" onclick="setRange('today')">Hari Ini</span>
        <span class="chip" onclick="setRange('week')">Minggu Ini</span>
        <span class="chip" onclick="setRange('month')">Bulan Ini</span>
    </form>

    <p style="color:#6b7280; text-align:center; margin:10px 0;">
        Menampilkan detail pesanan dari <b><?= date('d M Y', strtotime($start)) ?></b>
        hingga <b><?= date('d M Y', strtotime($end)) ?></b>.
    </p>
    <?php endif; ?>

    <div class="table-wrap">
        <div class="table-scroll">
            <table>
                <thead>
                    <tr>
                        <th>ID Detail</th>
                        <th>Order</th>
                        <th>Menu ID</th>
                        <th>Nama Menu</th>
                        <th>Qty</th>
                        <th>Harga</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>

                <tbody>
                <?php if (count($rows) > 0): ?>
                    <?php foreach ($rows as $r): ?>
                    <tr>
                        <td>#<?= str_pad($r['id'], 3, '0', STR_PAD_LEFT) ?></td>

                        <td>
                            <span class="badge">
                                <a class="order-link" href="detail.php?order_id=<?= $r['order_id'] ?>">
                                    #<?= str_pad($r['order_id'], 3, '0', STR_PAD_LEFT) ?>
                                </a>
                            </span>
                        </td>

                        <td><?= $r['menu_id'] ?></td>
                        <td><?= htmlspecialchars($r['nama_menu']) ?></td>

                        <td><?= $r['qty'] ?></td>

                        <td>Rp <?= number_format($r['harga'], 0, ',', '.') ?></td>

                        <td>Rp <?= number_format($r['subtotal'], 0, ',', '.') ?></td>
                    </tr>
                    <?php endforeach; ?>

                    <!-- Row Total -->
                    <tr class="total-row">
                        <td colspan="6" style="text-align:right;">
                            <?= $orderId ? 'Grand Total' : 'Total Nilai (Rentang Tanggal)' ?>
                        </td>
                        <td>Rp <?= number_format($orderId ? $grandTotal : $totalNilai, 0, ',', '.') ?></td>
                    </tr>

                <?php else: ?>
                    <tr>
                        <td colspan="7" style="text-align:center; color:#6b7280;">
                            Tidak ada data untuk filter ini.
                        </td>
                    </tr>
                <?php endif; ?>

                </tbody>
            </table>
        </div>
    </div>

</div>

<script>
function pad(n){ return n<10 ? '0'+n : n; }
function ymd(d){ return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate()); }

function setRange(t){
    const s = document.querySelector('[name=start_date]');
    const e = document.querySelector('[name=end_date]');
    const today = new Date();

    if(t==='today'){
        s.value = e.value = ymd(today);
    }
    if(t==='week'){
        const w = new Date(today);
        w.setDate(today.getDate() - (today.getDay()+6)%7);
        s.value = ymd(w);
        e.value = ymd(today);
    }
    if(t==='month'){
        const m1 = new Date(today.getFullYear(), today.getMonth(), 1);
        s.value = ymd(m1);
        e.value = ymd(today);
    }
    s.form.submit();
}
</script>

</body>
</html>

<?php
$mysqli->close();
?>
