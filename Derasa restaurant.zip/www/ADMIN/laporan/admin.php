<?php
// ====================
// 🔧 AKTIFKAN ERROR DEBUG
// ====================
error_reporting(E_ALL);
ini_set('display_errors', 1);

// ====================
// 🔗 KONEKSI DATABASE
// ====================
require_once __DIR__ . '/../koneksi.php';
if (!isset($mysqli) || $mysqli->connect_error) {
    die('❌ Koneksi database gagal: ' . $mysqli->connect_error);
}

// ====================
// 📅 FILTER TANGGAL
// ====================
$tanggalMulai   = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-d');
$tanggalSelesai = isset($_GET['end_date'])   ? $_GET['end_date']   : date('Y-m-d');

// ====================
// 🧾 QUERY DATA PESANAN
// ====================
$stmt = $mysqli->prepare("
    SELECT id, waktu, pelanggan, metode_pembayaran, status, catatan, total
    FROM pesanan_masuk
    WHERE DATE(waktu) BETWEEN ? AND ?
    ORDER BY waktu DESC
");
$stmt->bind_param("ss", $tanggalMulai, $tanggalSelesai);
$stmt->execute();
$result = $stmt->get_result();

// ====================
// 🔢 HITUNG RINGKASAN
// ====================
$totalPesanan    = 0;
$totalPendapatan = 0;
$rows = [];

while ($row = $result->fetch_assoc()) {
    $rows[] = $row;
    $totalPesanan++;
    $totalPendapatan += (int)$row['total'];
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>📋 Data Pesanan Masuk</title>
<style>
    :root{
        --primary:#007bff;
        --primary-dark:#0056b3;
        --bg:#f5f6fa;
        --card:#ffffff;
        --border:#e6e9ef;
        --text:#2c3e50;
        --muted:#6b7280;
        --success:#22c55e;
        --warning:#f59e0b;
        --danger:#ef4444;
    }
    *{box-sizing:border-box}
    body{
        font-family: "Poppins", Arial, sans-serif;
        background: linear-gradient(135deg,#eef4ff,#f7f9fc);
        color:var(--text);
        margin:0;
        padding:40px 16px;
    }
    .wrap{
        max-width:1200px;
        margin:0 auto;
        background:var(--card);
        border-radius:16px;
        box-shadow:0 10px 24px rgba(0,0,0,.06);
        overflow:hidden;
    }
    .header{
        padding:24px 28px;
        border-bottom:1px solid var(--border);
        display:flex;align-items:center;justify-content:space-between;gap:16px;
        flex-wrap:wrap;
        background:#fff;
    }
    .header h1{
        margin:0;
        font-size:1.4rem;
        letter-spacing:.2px;
        color:#1a237e;
    }
    .actions{display:flex;gap:10px;flex-wrap:wrap}
    .btn{
        background:var(--primary);
        color:#fff;
        padding:10px 14px;
        border-radius:8px;
        text-decoration:none;
        display:inline-flex;align-items:center;gap:8px;
        border:none;cursor:pointer;font-weight:600;font-size:.92rem;
        box-shadow:0 6px 14px rgba(0,123,255,.25);
        transition:.2s;
    }
    .btn:hover{background:var(--primary-dark);transform:translateY(-2px)}
    .btn.secondary{background:#e8eefc;color:#1a237e;box-shadow:none}
    .btn.secondary:hover{background:#d8e4ff}

    .filters{
        padding:18px 28px 8px 28px;
        display:flex;flex-wrap:wrap;gap:10px;align-items:center;
    }
    .filters label{font-weight:600}
    .filters input[type="date"]{
        padding:9px 10px;border:1px solid var(--border);border-radius:8px;outline:none;
        background:#fff;min-width:180px;
    }
    .preset{
        display:flex;gap:8px;flex-wrap:wrap;margin-left:auto;
    }
    .chip{
        border:1px solid var(--border);
        background:#fff;
        padding:8px 12px;border-radius:999px;cursor:pointer;
        font-weight:600;font-size:.88rem;color:#374151;
        transition:.15s;
    }
    .chip:hover{border-color:var(--primary);color:var(--primary)}

    .summary{
        margin:10px 28px 18px 28px;
        display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;
    }
    .card{
        background:#f8fbff;border:1px solid #e4e9f7;border-radius:12px;padding:14px 16px;
        box-shadow:0 4px 12px rgba(0,123,255,.10);
    }
    .card .label{font-size:.86rem;color:var(--muted);margin-bottom:6px}
    .card .value{font-size:1.2rem;font-weight:800}

    .table-wrap{
        padding:0 0 6px 0;
        background:#fff;
        border-top:1px solid var(--border);
    }
    .table-scroll{
        overflow:auto;
        max-height:65vh;
    }
    table{
        width:100%;
        border-collapse:separate;
        border-spacing:0;
        min-width:900px;
    }
    thead th{
        position:sticky;top:0;z-index:1;
        background:var(--primary);color:#fff;
        text-align:center;padding:12px 14px;
        font-weight:700;border-bottom:1px solid var(--border);
    }
    tbody td{
        border-bottom:1px solid var(--border);
        text-align:center;padding:12px 14px;background:#fff;
    }
    tbody tr:nth-child(even) td{background:#fbfdff}
    tbody tr:hover td{background:#f2f7ff}
    .right{text-align:right}
    .badge{
        padding:6px 10px;border-radius:999px;font-weight:700;font-size:.78rem;display:inline-block;
    }
    .badge.success{background:#eafaf1;color:#0f8a3a;border:1px solid #b9f0cf}
    .badge.warn{background:#fff7e6;color:#a86a05;border:1px solid #fde2a7}
    .badge.danger{background:#feecec;color:#b42318;border:1px solid #ffc5c0}
    .subtle{color:#6b7280;font-size:.9rem;margin:6px 28px 18px 28px;text-align:center}

    /* Print */
    @media print{
        body{background:#fff;padding:0}
        .header,.filters,.preset,.actions,.subtle{display:none!important}
        .wrap{box-shadow:none;border-radius:0}
        thead th{background:#ddd!important;color:#000!important;-webkit-print-color-adjust:exact}
    }
    @media (max-width:680px){
        .header{padding:18px}
        .filters{padding:16px}
        .summary{margin:10px 18px}
    }
</style>
</head>
<body>
<div class="wrap">
    <!-- Header -->
    <div class="header">
        <h1>📋 Data Pesanan Masuk</h1>
        <div class="actions">
            <a class="btn" href="#" onclick="location.reload()">🔄 Refresh</a>
            <!-- laporan detail pesanan -->
            <a class="btn secondary" href="detail.php">📑 Detail Pesanan</a>
            <!-- balik ke dashboard admin (file ini di dalam /ADMIN/laporan/) -->
            <a class="btn secondary" href="../index.php">⬅ Halaman Utama</a>
            <button class="btn" onclick="window.print()">🖨️ Cetak</button>
        </div>
    </div>

    <!-- Filters -->
    <form class="filters" method="get">
        <label for="sd">Dari</label>
        <input id="sd" type="date" name="start_date" value="<?= htmlspecialchars($tanggalMulai) ?>">
        <label for="ed">Sampai</label>
        <input id="ed" type="date" name="end_date" value="<?= htmlspecialchars($tanggalSelesai) ?>">
        <button class="btn" type="submit">Tampilkan</button>

        <div class="preset">
            <span class="chip" onclick="setRange('today')">Hari Ini</span>
            <span class="chip" onclick="setRange('week')">Minggu Ini</span>
            <span class="chip" onclick="setRange('month')">Bulan Ini</span>
        </div>
    </form>

    <!-- Summary -->
    <div class="summary">
        <div class="card">
            <div class="label">
                Total Pesanan
                (<?= date('d M Y', strtotime($tanggalMulai)) ?> – <?= date('d M Y', strtotime($tanggalSelesai)) ?>)
            </div>
            <div class="value"><?= number_format($totalPesanan, 0, ',', '.') ?></div>
        </div>
        <div class="card">
            <div class="label">Total Pendapatan</div>
            <div class="value">Rp <?= number_format($totalPendapatan, 0, ',', '.') ?></div>
        </div>
    </div>

    <p class="subtle">
        Menampilkan data dari <b><?= date('d M Y', strtotime($tanggalMulai)) ?></b>
        hingga <b><?= date('d M Y', strtotime($tanggalSelesai)) ?></b>.
    </p>

    <!-- Table -->
    <div class="table-wrap">
        <div class="table-scroll">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Waktu</th>
                        <th>Pelanggan</th>
                        <th>Metode Pembayaran</th>
                        <th>Status</th>
                        <th>Catatan</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (count($rows) > 0): ?>
                    <?php foreach ($rows as $r): ?>
                        <tr>
                            <td>#<?= str_pad($r['id'], 3, '0', STR_PAD_LEFT) ?></td>
                            <td><?= htmlspecialchars($r['waktu']) ?></td>
                            <td><?= htmlspecialchars($r['pelanggan']) ?></td>
                            <td><?= htmlspecialchars($r['metode_pembayaran']) ?></td>
                            <td>
                                <?php
                                    $status = strtolower(trim($r['status']));
                                    $cls = 'warn';
                                    if (in_array($status, ['completed', 'selesai', 'done', 'finish'])) {
                                        $cls = 'success';
                                    } elseif (in_array($status, ['canceled', 'batal', 'cancel'])) {
                                        $cls = 'danger';
                                    }
                                ?>
                                <span class="badge <?= $cls ?>"><?= htmlspecialchars(ucfirst($r['status'])) ?></span>
                            </td>
                            <td><?= htmlspecialchars($r['catatan']) ?></td>
                            <td class="right">Rp <?= number_format($r['total'], 0, ',', '.') ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="7" style="color:#6b7280">Tidak ada pesanan untuk rentang tanggal ini.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
// Helper tanggal lokal (tanpa UTC shift)
function pad(n){return n < 10 ? '0' + n : n;}
function ymdLocal(d){
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
}
function setRange(type){
  const sd = document.querySelector('[name=start_date]');
  const ed = document.querySelector('[name=end_date]');
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate()); // 00:00 lokal

  if(type === 'today'){
    sd.value = ymdLocal(today);
    ed.value = ymdLocal(today);
  }
  if(type === 'week'){
    // Mulai Senin
    const w = new Date(today);
    const day = w.getDay() || 7; // 1=Senin, 7=Minggu
    w.setDate(w.getDate() - day + 1);
    sd.value = ymdLocal(w);
    ed.value = ymdLocal(today);
  }
  if(type === 'month'){
    const m1 = new Date(today.getFullYear(), today.getMonth(), 1);
    sd.value = ymdLocal(m1);
    ed.value = ymdLocal(today);
  }
  sd.form.submit();
}
</script>
</body>
</html>
<?php
// ====================
// 🔒 TUTUP KONEKSI
// ====================
if (isset($stmt))   $stmt->close();
if (isset($result) && $result instanceof mysqli_result) $result->free();
if (isset($mysqli) && $mysqli instanceof mysqli) $mysqli->close();
?>
