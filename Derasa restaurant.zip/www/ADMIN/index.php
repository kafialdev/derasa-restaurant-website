<?php
/* /ADMIN/index.php - Dashboard Admin Restoran (DB Dynamic + Responsive + Live KPI) */

require_once __DIR__ . '/koneksi.php';
if (!isset($conn) && isset($koneksi)) { $conn = $koneksi; }

$kpi = [
  'pending' => 0,
  'processing' => 0,
  'completed' => 0,
  'cancelled' => 0,
  'today_pending' => 0,
  'today_processing' => 0,
  'today_completed' => 0,
  'today_cancelled' => 0,
  'today_revenue' => 0,
  'rating_count' => 0,
  'avg_rating' => 0,
  'employee_count' => 0,
];

// ---- helper normalisasi status
function normStatusFromDb($raw){
  $s = strtolower(trim((string)$raw));
  if (in_array($s, ['pending','baru','new','menunggu'], true)) return 'pending';
  if (in_array($s, ['processing','diproses','proses','onprocess'], true)) return 'processing';
  if (in_array($s, ['completed','selesai','done','finished','complete'], true)) return 'completed';
  if (in_array($s, ['cancelled','canceled','dibatalkan','batal','cancel'], true)) return 'cancelled';
  return $s;
}

// ---- helper cek tabel ada / tidak (biar reservasi aman)
function table_exists(mysqli $conn, $table){
  $table = $conn->real_escape_string($table);
  $dbRes = $conn->query("SELECT DATABASE() db");
  $dbRow = $dbRes ? $dbRes->fetch_assoc() : null;
  $db = $dbRow['db'] ?? '';
  if (!$db) return false;

  $db = $conn->real_escape_string($db);
  $q = $conn->query("SELECT 1 FROM information_schema.tables WHERE table_schema='{$db}' AND table_name='{$table}' LIMIT 1");
  return ($q && $q->num_rows > 0);
}

$reservasi_rows = []; // <-- data reservasi untuk tabel

if (isset($conn) && $conn instanceof mysqli) {

  // Count per status (all time) dengan normalisasi
  if ($res = $conn->query("SELECT LOWER(TRIM(status)) st, COUNT(*) c FROM pesanan_masuk GROUP BY LOWER(TRIM(status))")) {
    while ($row = $res->fetch_assoc()) {
      $st = normStatusFromDb($row['st']);
      if (isset($kpi[$st])) $kpi[$st] += (int)$row['c'];
    }
  }

  // Count per status (today) dengan normalisasi
  if ($res2 = $conn->query("SELECT LOWER(TRIM(status)) st, COUNT(*) c FROM pesanan_masuk WHERE DATE(waktu)=CURDATE() GROUP BY LOWER(TRIM(status))")) {
    while ($row = $res2->fetch_assoc()) {
      $st = normStatusFromDb($row['st']);
      $key = 'today_' . $st;
      if (isset($kpi[$key])) $kpi[$key] += (int)$row['c'];
    }
  }

  // Revenue today (completed variants)
  $completedList = "'completed','selesai','done','finished','complete'";
  if ($r1 = $conn->query("SELECT COALESCE(SUM(total),0) s FROM pesanan_masuk WHERE LOWER(TRIM(status)) IN ($completedList) AND DATE(waktu)=CURDATE()")) {
    $kpi['today_revenue'] = (int)($r1->fetch_assoc()['s'] ?? 0);
  }

  // Rating
  if (table_exists($conn, 'order_ratings')) {
    if ($rr = $conn->query("SELECT COUNT(*) c, COALESCE(AVG(rating),0) a FROM order_ratings WHERE rating IS NOT NULL")) {
      $row = $rr->fetch_assoc();
      $kpi['rating_count'] = (int)($row['c'] ?? 0);
      $kpi['avg_rating'] = round((float)($row['a'] ?? 0), 1);
    }
  }

  // Karyawan (team)
  if (table_exists($conn, 'karyawan')) {
    if ($ek = $conn->query("SELECT COUNT(*) c FROM karyawan")) {
      $kpi['employee_count'] = (int)($ek->fetch_assoc()['c'] ?? 0);
    }
  }

  // ===== Reservasi terbaru (AMAN, tidak fatal error kalau tabel belum ada) =====
  if (table_exists($conn, 'reservations')) {
    if ($q = $conn->query("SELECT id, name, phone, datetime, guests, message FROM reservations ORDER BY id DESC LIMIT 5")) {
      $reservasi_rows = $q->fetch_all(MYSQLI_ASSOC);
    }
  }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Restoran Management</title>
  <base href="./">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"/>
  <link rel="stylesheet" href="style.css">

  <style>
    .dashboard-content{
      display:grid;
      grid-template-columns: repeat(3, minmax(0, 1fr));
      gap:18px;
      align-items:stretch;
    }
    .dashboard-card{min-width:0}
    .dashboard-card.wide{grid-column: 1 / -1;}

    @media (max-width: 992px){
      .dashboard-content{grid-template-columns: repeat(2, minmax(0, 1fr));}
    }
    @media (max-width: 576px){
      .dashboard-content{grid-template-columns: 1fr;}
      .dashboard-header h1{font-size:22px;}
      .user-info span{display:none;}
      .btn-action{padding:8px 12px; font-size:12px;}
    }
  
    .sidebar-clock{color:#cdd6f4;font-size:12px;margin-top:6px;opacity:.9;}
    .sidebar-clock #rtClock{display:inline-block;}
</style>
</head>

<body>
  <div class="sidebar-toggle" onclick="toggleSidebar()">☰ Menu</div>
  <div class="mobile-overlay" onclick="toggleSidebar()"></div>

  <div class="sidebar" id="appSidebar" style="display:block">
    <div class="sidebar-header">
      <h2>🍽️ DERASA</h2>
      <div class="sidebar-clock"><span id="rtClock" aria-label="Waktu sekarang"></span></div>
    </div>
    <ul class="sidebar-menu" id="sidebarMenu">
      <li class="active"><a href="index.php">Dashboard</a></li>
      <li><a href="menubar.php">Manajemen Menu</a></li>
      <li><a href="laporan/laporan.php">Laporan</a></li>
      <li><a href="contact/contact_list.php">Pesan Pelanggan</a></li>
      <li><a href="reservasi/reservasi.php">Reservasi</a></li>
    </ul>
    <div class="sidebar-footer"></div>
  </div>

  <div class="main-content">
    <div class="container">
      <div class="dashboard" id="dashboardSection" style="display:block">
        <div class="dashboard-header">
          <h1>Dashboard Admin Restoran</h1>
          <div class="header-actions">
            <div class="user-info">
              <div class="user-avatar">A</div>
              <span>Admin User</span>
              <a href="logout.php" id="logoutBtn">Logout</a>
            </div>
          </div>
        </div>

        <div class="dashboard-content">
          <div class="dashboard-card">
            <h3>Pesanan Masuk</h3>
            <p>Monitoring pesanan masuk</p>
            <div class="card-stats">
              <div>
                <div class="stat-value" id="kpiMasuk"><?php echo (int)$kpi['pending']; ?></div>
                <div class="stat-label" id="subMasuk"><?php echo (int)$kpi['today_pending']; ?> Hari ini</div>
              </div>
              <a class="btn-action" href="pesananmasuk.php">Lihat</a>
            </div>
          </div>

          <div class="dashboard-card">
            <h3>Pesanan Diproses</h3>
            <p>Monitoring pesanan yang diproses</p>
            <div class="card-stats">
              <div>
                <div class="stat-value" id="kpiProses"><?php echo (int)$kpi['processing']; ?></div>
                <div class="stat-label" id="subProses"><?php echo (int)$kpi['today_processing']; ?> Hari ini</div>
              </div>
              <a class="btn-action" href="pesananproses.php">Lihat</a>
            </div>
          </div>

          <div class="dashboard-card">
            <h3>Pesanan Selesai</h3>
            <p>Monitoring pesanan yang telah diproses</p>
            <div class="card-stats">
              <div>
                <div class="stat-value" id="kpiSelesai"><?php echo (int)$kpi['completed']; ?></div>
                <div class="stat-label" id="subSelesai"><?php echo (int)$kpi['today_completed']; ?> Hari ini</div>
              </div>
              <a class="btn-action" href="pesananselesai.php">Lihat</a>
            </div>
          </div>

          <div class="dashboard-card">
            <h3>Pesanan Dibatalkan</h3>
            <p>Monitoring pesanan yang dibatalkan pelanggan atau admin</p>
            <div class="card-stats">
              <div>
                <div class="stat-value" id="kpiBatal"><?php echo (int)$kpi['cancelled']; ?></div>
                <div class="stat-label" id="subBatal"><?php echo (int)$kpi['today_cancelled']; ?> Hari ini</div>
              </div>
              <a class="btn-action" href="pesananbatal.php">Lihat</a>
            </div>
          </div>

          <div class="dashboard-card">
            <h3>Pendapatan Hari Ini</h3>
            <p>Total pendapatan dari penjualan hari ini</p>
            <div class="card-stats">
              <div>
                <div class="stat-value" id="todayRevenue">Rp <?php echo number_format((int)$kpi['today_revenue'], 0, ',', '.'); ?></div>
                <div class="stat-label" id="revenueChange"><?php echo ((int)$kpi['today_revenue'] > 0) ? 'Pendapatan hari ini (Completed)' : 'Belum ada transaksi hari ini'; ?></div>
              </div>
              <a class="btn-action" href="pendapatan.php">Lihat</a>
            </div>
          </div>

          <div class="dashboard-card">
            <h3>Rating Pelanggan</h3>
            <p>Rata-rata rating dari pelanggan</p>
            <div class="card-stats">
              <div>
                <div class="stat-value" id="customerRating"><?php echo number_format((float)$kpi['avg_rating'], 1, ',', '.'); ?></div>
                <div class="stat-label" id="ratingCount"><?php echo (int)$kpi['rating_count']; ?> rating masuk</div>
              </div>
              <a class="btn-action" href="rating/rating.php">Lihat</a>
            </div>
          </div>

          <div class="dashboard-card">
            <h3>Karyawan</h3>
            <p>Kelola data team yang tampil di website</p>
            <div class="card-stats">
              <div>
                <div class="stat-value" id="kpiKaryawan"><?php echo (int)$kpi['employee_count']; ?></div>
                <div class="stat-label">Total karyawan</div>
              </div>
              <a class="btn-action" href="karyawan/karyawan.php">Lihat</a>
            </div>
          </div>

          <!-- Reservasi -->
          <div class="dashboard-card wide" style="padding: 25px;">
            <div style="display:flex; justify-content: space-between; align-items:center; gap:12px; flex-wrap:wrap;">
              <div>
                <h3>Data Reservasi Terbaru</h3>
                <p>Menampilkan data reservasi masuk</p>
              </div>

              <div style="display:flex; gap:10px; flex-wrap:wrap;">
                <input type="text" id="searchReservasi" placeholder="Cari nama..." class="form-control" style="width:150px;">
                <button class="btn btn-secondary" onclick="refreshReservasi()">Refresh</button>
                <button class="btn btn-danger" onclick="hapusSemuaReservasi()">Hapus Tabel</button>
              </div>
            </div>

            <div class="table-responsive mt-3">
              <table class="menu-table" id="reservasiTable" style="width: 100%;">
                <thead>
                  <tr>
                    <th>Id Reservasi</th>
                    <th>Nama</th>
                    <th>No HP</th>
                    <th>Tanggal & Waktu</th>
                    <th>Orang</th>
                    <th>Pesan</th>
                  </tr>
                </thead>
                <tbody id="reservasiBody">
                  <?php if (empty($reservasi_rows)): ?>
                    <tr>
                      <td colspan="6" style="text-align:center; padding:16px;">
                        Belum ada data reservasi.
                      </td>
                    </tr>
                  <?php else: ?>
                    <?php foreach ($reservasi_rows as $r): 
                      $dt = !empty($r['datetime']) ? date("Y-m-d H:i", strtotime($r['datetime'])) : '-';
                    ?>
                      <tr>
                        <td><?php echo (int)$r['id']; ?></td>
                        <td><?php echo htmlspecialchars($r['name'] ?? ''); ?></td>
                        <td><?php echo htmlspecialchars($r['phone'] ?? ''); ?></td>
                        <td><?php echo htmlspecialchars($dt); ?></td>
                        <td><?php echo htmlspecialchars($r['guests'] ?? ''); ?></td>
                        <td><?php echo htmlspecialchars($r['message'] ?? ''); ?></td>
                      </tr>
                    <?php endforeach; ?>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>
          </div>

        </div><!-- dashboard-content -->
      </div><!-- dashboard -->
    </div><!-- container -->
  </div><!-- main-content -->

  <script>
    function toggleSidebar(){ document.body.classList.toggle("sidebar-open"); }
    function refreshReservasi(){ location.reload(); }
    function hapusSemuaReservasi(){
      if(confirm("Yakin ingin menghapus semua data reservasi?")){
        window.location.href = "reservasi/hapus_semua.php";
      }
    }

    // Filter tabel reservasi
    document.addEventListener("DOMContentLoaded", function() {
      const searchInput = document.getElementById("searchReservasi");
      if (searchInput) {
        searchInput.addEventListener("keyup", function() {
          let filter = this.value.toLowerCase();
          document.querySelectorAll("#reservasiBody tr").forEach(row => {
            let nama = (row.children[1]?.innerText || "").toLowerCase();
            row.style.display = nama.includes(filter) ? "" : "none";
          });
        });
      }
    });

    // ====== LIVE KPI dari API ======
    (function(){
      const API_URL = "simpan_pesanan.php?status=all";
      const fmtIDR = n => "Rp " + Number(n||0).toLocaleString('id-ID');

      const norm = (raw) => {
        const s = String(raw||'').toLowerCase().trim();
        if (['pending','baru','new','menunggu'].includes(s)) return 'pending';
        if (['processing','diproses','proses','onprocess'].includes(s)) return 'processing';
        if (['completed','selesai','done','finished','complete'].includes(s)) return 'completed';
        if (['cancelled','canceled','dibatalkan','batal','cancel'].includes(s)) return 'cancelled';
        return s;
      };

      const sameDay = (a,b)=> a && b &&
        a.getFullYear()===b.getFullYear() &&
        a.getMonth()===b.getMonth() &&
        a.getDate()===b.getDate();

      const toDate = (val)=>{
        if(!val) return null;
        const s = String(val).replace(' ', 'T');
        const d = new Date(s);
        return isNaN(d) ? null : d;
      };

      function setText(id, txt){
        const el = document.getElementById(id);
        if(el) el.textContent = txt;
      }

      async function refreshKPI(){
        try{
          const res = await fetch(API_URL, { headers:{Accept:"application/json"} });
          const json = await res.json();
          if(!res.ok || json.status!=="success") return;

          const rows = Array.isArray(json.data) ? json.data : [];
          const today = new Date();

          let all = {pending:0, processing:0, completed:0, cancelled:0};
          let todayCount = {pending:0, processing:0, completed:0, cancelled:0};
          let todayRevenue = 0;

          rows.forEach(o=>{
            const st = norm(o.status);
            if(all[st] != null) all[st]++;

            const t = toDate(o.waktu);
            if (t && sameDay(t, today) && todayCount[st] != null) todayCount[st]++;

            if (t && sameDay(t, today) && st === 'completed'){
              todayRevenue += Number(o.total||0);
            }
          });

          setText('kpiMasuk', String(all.pending));
          setText('subMasuk', `${todayCount.pending} Hari ini`);

          setText('kpiProses', String(all.processing));
          setText('subProses', `${todayCount.processing} Hari ini`);

          setText('kpiSelesai', String(all.completed));
          setText('subSelesai', `${todayCount.completed} Hari ini`);

          setText('kpiBatal', String(all.cancelled));
          setText('subBatal', `${todayCount.cancelled} Hari ini`);

          setText('todayRevenue', fmtIDR(todayRevenue));
        }catch(e){}
      }

      document.addEventListener("DOMContentLoaded", ()=>{
        refreshKPI();
        setInterval(refreshKPI, 5000);
      });
    })();
  </script>

  <script>
    (function(){
      function pad(n){ return String(n).padStart(2,'0'); }
      function fmt(d){
        const dd=pad(d.getDate()), mm=pad(d.getMonth()+1), yy=d.getFullYear();
        const hh=pad(d.getHours()), mi=pad(d.getMinutes()), ss=pad(d.getSeconds());
        return `${dd}/${mm}/${yy} ${hh}:${mi}:${ss}`;
      }
      const el = document.getElementById('rtClock');
      if(!el) return;
      function tick(){ el.textContent = fmt(new Date()); }
      tick();
      setInterval(tick, 1000);
    })();
  </script>
</body>
</html>
