<?php
// /ADMIN/rating/simpan_review.php
// Simpan rating & saran (terkait order) ke tabel order_ratings.
// NOTE: Tabel `reviews` sudah DIHAPUS. Semua ulasan diambil dari order_ratings.

header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../koneksi.php';
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
  $order_id = isset($_POST['order_id']) ? (int)$_POST['order_id'] : (isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0);
  $name     = trim($_POST['name'] ?? ($_GET['name'] ?? 'Guest'));
  $star     = (int)($_POST['star'] ?? ($_GET['star'] ?? 0));
  $comment  = trim($_POST['comment'] ?? ($_GET['comment'] ?? ''));

  if ($order_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Order tidak valid.']);
    exit;
  }

  if ($star < 1 || $star > 5) {
    echo json_encode(['success' => false, 'message' => 'Rating tidak valid.']);
    exit;
  }

  if ($name === '') $name = 'Guest';

  // 1) Simpan rating per order (jika order_id valid)
  if ($order_id > 0) {
    // upsert: kalau sudah ada rating untuk order ini, update
    $stmt = $conn->prepare(
      "INSERT INTO order_ratings (order_id, rating, saran) VALUES (?, ?, ?)\n       ON DUPLICATE KEY UPDATE rating = VALUES(rating), saran = VALUES(saran)"
    );
    $stmt->bind_param('iis', $order_id, $star, $comment);
    $stmt->execute();
    $stmt->close();
  }

  // Tidak ada insert ke tabel `reviews` (tabel sudah dihapus)
  echo json_encode(['success' => true, 'message' => 'Rating berhasil disimpan.']);

} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['success' => false, 'message' => 'Gagal menyimpan review: ' . $e->getMessage()]);
}
