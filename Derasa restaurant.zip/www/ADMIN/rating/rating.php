<?php
// =========================
//  BAGIAN PHP (AMBIL DATA)
// =========================

// error reporting (opsional, untuk debug)
error_reporting(E_ALL);
ini_set('display_errors', 1);

$host = 'localhost';
$db   = 'restaurant';
$user = 'root';
$pass = '';

$db_error = '';

try {
    // Koneksi pakai PDO
    $pdo = new PDO(
        "mysql:host={$host};dbname={$db};charset=utf8mb4",
        $user,
        $pass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    // Ambil semua rating pelanggan (tabel reviews sudah dihapus)
    // Sumber: order_ratings JOIN pesanan_masuk
    $sql = "SELECT r.id, p.pelanggan AS name, r.rating AS star, r.saran AS comment, r.created_at AS time
            FROM order_ratings r
            JOIN pesanan_masuk p ON p.id = r.order_id
            ORDER BY r.id DESC";
    $stmt = $pdo->query($sql);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Rapikan data
    $result = [];
    foreach ($rows as $r) {
        $result[] = [
            'id'      => (int)$r['id'],
            'name'    => $r['name'],
            'star'    => (int)$r['star'],
            'comment' => $r['comment'],
            'time'    => $r['time'],
        ];
    }

    // ====== MODE JSON UNTUK AJAX (dipakai rating.js / JS di bawah) ======
    // kalau dipanggil dengan ?mode=json -> kirim JSON saja
    if (isset($_GET['mode']) && $_GET['mode'] === 'json') {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($result);
        exit;
    }

} catch (PDOException $e) {
    // jika dipanggil sebagai JSON
    if (isset($_GET['mode']) && $_GET['mode'] === 'json') {
        header('Content-Type: application/json; charset=utf-8');
        http_response_code(500);
        echo json_encode([
            'error'   => true,
            'message' => 'Gagal mengambil data: ' . $e->getMessage()
        ]);
        exit;
    }

    // kalau hanya buka halaman HTML biasa, simpan pesan error
    $db_error = $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rating Pelanggan</title>

    <style>
        /* =====================
           GLOBAL
        ===================== */
        body {
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background: #deeafa;
            color: #222;
        }

        .container {
            max-width: 900px;
            margin: 25px auto;
            padding: 0 20px;
        }

        /* =====================
           HEADER
        ===================== */
        .header {
            padding: 20px 35px;
            background: #ffffff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-radius: 0 0 20px 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.06);
        }

        .header h1 {
            margin: 0;
            font-size: 26px;
            font-weight: 700;
            color: #1f3e72;
        }

        .btn-dashboard {
            background: #2d5aac;
            padding: 10px 20px;
            border-radius: 8px;
            color: white;
            text-decoration: none;
            font-weight: 600;
            transition: 0.2s;
            box-shadow: 0 3px 8px rgba(0,0,0,0.10);
        }

        .btn-dashboard:hover {
            background: #244a90;
            transform: translateY(-2px);
        }

        /* =====================
           SUMMARY SECTION
        ===================== */
        .summary-box {
            background: #ffffff;
            padding: 32px;
            border-radius: 20px;
            display: flex;
            justify-content: space-between;
            gap: 20px;
            margin-bottom: 35px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.06);
            border: 1px solid #e7e9ee;
        }

        .summary-box .left {
            text-align: center;
            width: 32%;
        }

        .summary-box h2 {
            font-size: 54px;
            margin: 0;
            font-weight: 700;
            color: #244a90;
        }

        .stars {
            color: #e0b000;
            font-size: 22px;
            margin: 6px 0;
        }

        .summary-box p {
            margin: 0;
            color: #555;
            font-size: 15px;
        }

        /* Rating bars */
        .right {
            width: 65%;
            padding-top: 5px;
        }

        .bar-item {
            display: flex;
            align-items: center;
            gap: 14px;
            margin-bottom: 12px;
            color: #444;
            font-size: 15px;
            font-weight: 500;
        }

        .bar {
            flex: 1;
            height: 10px;
            background: #eaecef;
            border-radius: 20px;
            overflow: hidden;
        }

        .bar-fill {
            height: 100%;
            width: 0%;
            background: #2d5aac;
            border-radius: 20px;
            transition: width 0.4s ease;
            box-shadow: inset 0 0 10px rgba(255,255,255,0.2);
        }

        /* =====================
           REVIEW SECTION
        ===================== */
        .section-title {
            color: #244a90;
            margin-left: 5px;
            font-size: 21px;
            font-weight: 700;
        }

        .review-list {
            margin-top: 18px;
        }

        .review-card {
            background: #ffffff;
            padding: 20px;
            margin-bottom: 18px;
            border-radius: 16px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.05);
            display: flex;
            gap: 18px;
            transition: 0.25s ease;
            border: 1px solid #e9ebf2;
        }

        .review-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 28px rgba(0,0,0,0.10);
        }

        .avatar {
            width: 55px;
            height: 55px;
            border-radius: 50%;
            background: #2d5aac;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #fff;
            font-weight: 600;
            font-size: 20px;
            flex-shrink: 0;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }

        .review-content {
            flex: 1;
        }

        .review-name {
            font-weight: 700;
            font-size: 16px;
            color: #1e2a41;
        }

        .review-stars {
            color: #e0b000;
            margin-top: 3px;
        }

        .review-comment {
            margin: 6px 0;
            color: #444;
            font-size: 14px;
            line-height: 1.5;
        }

        .review-time {
            font-size: 12px;
            color: #777;
            margin-top: 4px;
        }

        .empty {
            color: #666;
            text-align: center;
            margin-top: 25px;
            font-size: 15px;
        }

        /* =====================
           FILTER SECTION
        ===================== */
        .filter-box {
            background: #ffffff;
            padding: 15px 10px;
            border-radius: 12px;
            box-shadow: 5px 5px rgba(94, 90, 90, 0.002);
            border: 1px solid #fdfbfb;

            display: flex;
            gap: 25px;
            align-items: center;
            justify-content: center;   /* posisi di tengah */
            margin-bottom: 25px;
            flex-wrap: wrap;
        }

        .filter-group {
            display: flex;
            flex-direction: column;
            font-size: 14px;
            color: #223;
            text-align: center;
        }

        .filter-group label {
            margin-bottom: 5px;
            font-weight: 600;
        }

        .filter-group select,
        .filter-group input {
            padding: 8px 12px;
            border-radius: 8px;
            border: 1px solid #ccd3e0;
            font-size: 14px;
            min-width: 130px;
        }

        .btn-reset {
            background: #2d5aac;
            color: white;
            padding: 9px 18px;
            border-radius: 8px;
            border: none;
            cursor: pointer;
            font-weight: 600;
            transition: 0.2s;
        }

        .btn-reset:hover {
            background: #244a90;
            transform: translateY(-2px);
        }

        @media (max-width: 768px) {
            .summary-box {
                flex-direction: column;
            }
            .summary-box .left,
            .right {
                width: 100%;
            }
        }
    </style>
</head>
<body>

<!-- HEADER -->
<header class="header">
    <h1>Rating Pelanggan</h1>
    <a href="../index.php" class="btn-dashboard">Kembali ke Dashboard</a>
</header>

<!-- WRAPPER -->
<div class="container">

    <!-- SUMMARY SECTION -->
    <section class="summary-box">
        <div class="left">
            <h2 id="avgRating">0.0</h2>
            <div id="avgStars" class="stars">⭐⭐⭐⭐⭐</div>
            <p id="totalReviews">0 review</p>
        </div>

        <div class="right">
            <div class="bar-item">
                <span>5 ⭐</span>
                <div class="bar"><div id="bar5" class="bar-fill"></div></div>
                <span id="count5">0</span>
            </div>
            <div class="bar-item">
                <span>4 ⭐</span>
                <div class="bar"><div id="bar4" class="bar-fill"></div></div>
                <span id="count4">0</span>
            </div>
            <div class="bar-item">
                <span>3 ⭐</span>
                <div class="bar"><div id="bar3" class="bar-fill"></div></div>
                <span id="count3">0</span>
            </div>
            <div class="bar-item">
                <span>2 ⭐</span>
                <div class="bar"><div id="bar2" class="bar-fill"></div></div>
                <span id="count2">0</span>
            </div>
            <div class="bar-item">
                <span>1 ⭐</span>
                <div class="bar"><div id="bar1" class="bar-fill"></div></div>
                <span id="count1">0</span>
            </div>
        </div>
    </section>

    <!-- FILTER SECTION -->
    <div class="filter-box">
        <div class="filter-group">
            <label>Rating</label>
            <select id="filterStar">
                <option value="">Semua</option>
                <option value="5">5 ⭐</option>
                <option value="4">4 ⭐</option>
                <option value="3">3 ⭐</option>
                <option value="2">2 ⭐</option>
                <option value="1">1 ⭐</option>
            </select>
        </div>

        <div class="filter-group">
            <label>Dari Tanggal</label>
            <input type="date" id="filterStart">
        </div>

        <div class="filter-group">
            <label>Sampai</label>
            <input type="date" id="filterEnd">
        </div>

        <button id="resetFilter" class="btn-reset">Reset</button>
    </div>

    <!-- REVIEW LIST -->
    <h2 class="section-title">Review Pelanggan</h2>

    <div id="reviewList" class="review-list"></div>
    <p id="emptyMsg" class="empty">Belum ada review pelanggan.</p>

    <?php if (!empty($db_error)): ?>
        <p style="color:red; margin-top:20px;">
            Error database: <?= htmlspecialchars($db_error) ?>
        </p>
    <?php endif; ?>

</div>

<script>
/* Ambil data dari database via API */
let reviews = []; // array review global

// Fungsi untuk inisiasi halaman
async function initPage() {
  try {
    const response = await fetch('rating.php?mode=json');
    if (!response.ok) {
        throw new Error('Gagal mengambil data review');
    }

    // Isi variabel 'reviews' dengan data dari database
    reviews = await response.json();

    // Panggil fungsi render SETELAH data didapat
    renderSummary();
    renderReviews();

  } catch (error) {
    console.error('Error:', error);
    // Tampilkan pesan error
    const empty = document.getElementById("emptyMsg");
    if (empty) {
      empty.textContent = "Gagal memuat data review.";
      empty.style.display = "block";
    }
  }
}

/* =============================
   RENDER SUMMARY
============================= */
function renderSummary() {
    const total = reviews.length;
    document.getElementById("totalReviews").textContent = total + " review";

    if (total === 0) {
        document.getElementById("avgRating").textContent = "0.0";
        document.getElementById("avgStars").textContent = "⭐".repeat(0);
        return;
    }

    // Hitung rata-rata
    const avg = (
        reviews.reduce((s, r) => s + r.star, 0) / total
    ).toFixed(1);

    document.getElementById("avgRating").textContent = avg;
    document.getElementById("avgStars").textContent = "⭐".repeat(Math.round(avg));

    // Hitung jumlah bintang
    const starCount = [0,0,0,0,0]; // index 0=1⭐, index 4=5⭐

    reviews.forEach(r => {
        if (r.star >= 1 && r.star <= 5) {
            starCount[r.star - 1]++;
        }
    });

    // Pengisian bar & count (1–5)
    for (let i = 1; i <= 5; i++) {
        const idx = 6 - i; // urutan 5 → index 4, dst
        const count = starCount[idx - 1]; // starCount[4] untuk 5⭐
        const percent = total ? (count / total) * 100 : 0;

        const countEl = document.getElementById("count" + idx);
        const barEl   = document.getElementById("bar" + idx);
        if (countEl) countEl.textContent = count;
        if (barEl) barEl.style.width = percent + "%";
    }
}

/* =============================
   RENDER REVIEW LIST
============================= */
function renderReviews() {
    const list = document.getElementById("reviewList");
    const empty = document.getElementById("emptyMsg");

    list.innerHTML = "";

    if (reviews.length === 0) {
        empty.style.display = "block";
        return;
    }

    empty.style.display = "none";

    reviews.forEach(r => {
        const card = document.createElement("div");
        card.className = "review-card";

        const initial = r.name ? r.name.charAt(0).toUpperCase() : "?";

        card.innerHTML = `
            <div class="avatar">${initial}</div>
            <div class="review-content">
                <div class="review-name">${r.name}</div>
                <div class="review-stars">${"⭐".repeat(r.star)}</div>
                <div class="review-comment">"${r.comment}"</div>
                <div class="review-time">${r.time}</div>
            </div>
        `;

        list.appendChild(card);
    });
}

/* =============================
   FILTER LOGIC
============================= */
function applyFilter() {
    let filtered = [...reviews];

    const star = document.getElementById("filterStar").value;
    const startDate = document.getElementById("filterStart").value;
    const endDate = document.getElementById("filterEnd").value;

    // Filter bintang
    if (star !== "") {
        filtered = filtered.filter(r => r.star == star);
    }

    // Filter tanggal mulai
    if (startDate) {
        filtered = filtered.filter(r => new Date(r.time) >= new Date(startDate));
    }

    // Filter tanggal akhir
    if (endDate) {
        filtered = filtered.filter(r => new Date(r.time) <= new Date(endDate + " 23:59:59"));
    }

    // Render ulang
    renderFilteredReviews(filtered);
}

/* Render Review versi Filter */
function renderFilteredReviews(data) {
    const list = document.getElementById("reviewList");
    const empty = document.getElementById("emptyMsg");

    list.innerHTML = "";

    if (data.length === 0) {
        empty.style.display = "block";
        return;
    }

    empty.style.display = "none";

    data.forEach(r => {
        const card = document.createElement("div");
        card.className = "review-card";

        const initial = r.name ? r.name.charAt(0).toUpperCase() : "?";

        card.innerHTML = `
            <div class="avatar">${initial}</div>
            <div class="review-content">
                <div class="review-name">${r.name}</div>
                <div class="review-stars">${"⭐".repeat(r.star)}</div>
                <div class="review-comment">"${r.comment}"</div>
                <div class="review-time">${r.time}</div>
            </div>
        `;
        list.appendChild(card);
    });
}

// Aktifkan filter setiap input berubah
document.getElementById("filterStar").addEventListener("change", applyFilter);
document.getElementById("filterStart").addEventListener("change", applyFilter);
document.getElementById("filterEnd").addEventListener("change", applyFilter);

// Tombol reset
document.getElementById("resetFilter").addEventListener("click", () => {
    document.getElementById("filterStar").value = "";
    document.getElementById("filterStart").value = "";
    document.getElementById("filterEnd").value = "";

    renderReviews();
    renderSummary();
});

/* =============================
   INISIASI HALAMAN
============================= */
initPage();
</script>
</body>
</html>
