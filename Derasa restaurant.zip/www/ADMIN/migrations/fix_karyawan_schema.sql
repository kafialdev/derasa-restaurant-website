-- Jalankan jika tabel `karyawan` Anda versi lama dan muncul error:
-- "Unknown column 'is_chef' in 'where clause'" atau kolom lainnya.

CREATE TABLE IF NOT EXISTS karyawan (
  id INT NOT NULL AUTO_INCREMENT,
  nama VARCHAR(100) NOT NULL,
  posisi VARCHAR(50) DEFAULT NULL,
  deskripsi TEXT,
  is_chef TINYINT(1) NOT NULL DEFAULT 0,
  image VARCHAR(255) DEFAULT NULL,
  visible TINYINT(1) NOT NULL DEFAULT 1,
  dibuat_pada DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Jika tabel sudah ada, pastikan kolom-kolomnya ada.
-- NOTE: XAMPP banyak yang pakai MariaDB/MySQL versi lama, jadi tidak semua mendukung `IF NOT EXISTS` di ALTER.
-- Jalankan satu per satu (kalau ada error "Duplicate column name" berarti kolomnya sudah ada, lanjutkan ke baris berikutnya).

ALTER TABLE karyawan ADD COLUMN deskripsi TEXT NULL AFTER posisi;
ALTER TABLE karyawan ADD COLUMN is_chef TINYINT(1) NOT NULL DEFAULT 0 AFTER deskripsi;
ALTER TABLE karyawan ADD COLUMN image VARCHAR(255) NULL AFTER is_chef;
ALTER TABLE karyawan ADD COLUMN visible TINYINT(1) NOT NULL DEFAULT 1 AFTER image;
ALTER TABLE karyawan ADD COLUMN dibuat_pada DATETIME NULL DEFAULT CURRENT_TIMESTAMP AFTER visible;
