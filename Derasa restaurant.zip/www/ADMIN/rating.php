<?php
// Backward-compatible alias: some parts of the dashboard used to link to /ADMIN/rating.php
// The actual rating management page lives in /ADMIN/rating/rating.php
require_once __DIR__ . '/rating/rating.php';
