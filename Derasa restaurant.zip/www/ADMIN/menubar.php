<?php /* /ADMIN/menubar.php */ ?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Manajemen Menu - DeRasa</title>

  <!-- Font -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">

  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Poppins', sans-serif;
    }

    body {
      background: linear-gradient(120deg, #f3f6ff, #eef3ff);
      min-height: 100vh;
    }

    .container {
      width: 90%;
      max-width: 1100px;
      margin: 40px auto;
      background: #fff;
      border-radius: 22px;
      box-shadow: 0 10px 25px rgba(0,0,0,0.07);
      padding: 40px 50px;
      animation: fadeIn 0.5s ease;
    }

    header {
      text-align: center;
      margin-bottom: 30px;
    }

    header h1 {
      color: #2b4eff;
      font-size: 2.2rem;
      margin-bottom: 8px;
    }

    header p {
      color: #555;
      font-size: 14px;
      margin-bottom: 15px;
    }

    .header-actions {
      display: flex;
      justify-content: center;
      align-items: center;
      gap: 15px;
      margin-top: 10px;
      flex-wrap: wrap;
    }

    #searchMenu {
      padding: 10px 15px;
      width: 250px;
      border-radius: 12px;
      border: 1px solid #ccc;
      font-size: 14px;
      transition: all 0.3s ease;
    }

    #searchMenu:focus {
      border-color: #2b4eff;
      outline: none;
      box-shadow: 0 0 5px rgba(43, 78, 255, 0.3);
    }

    .btn-primary {
      background: #2b4eff;
      color: white;
      border: none;
      padding: 10px 18px;
      border-radius: 12px;
      cursor: pointer;
      font-weight: 600;
      transition: 0.3s;
    }
    .btn-primary:hover {
      background: #1e37c4;
    }

    .btn-secondary {
      background: #ddd;
      color: #222;
      border: none;
      padding: 10px 16px;
      border-radius: 12px;
      cursor: pointer;
      font-weight: 500;
    }
    .btn-secondary:hover {
      background: #ccc;
    }

    .menu-section h2 {
      color: #333;
      margin-bottom: 15px;
      font-size: 18px;
    }

    .menu-cards {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 25px;
      width: 100%;
    }

    .menu-card {
      width: 90%;
      max-width: 600px;
      background: #fdfdfd;
      border-radius: 18px;
      box-shadow: 0 6px 18px rgba(0,0,0,0.08);
      overflow: hidden;
      padding: 15px;
      display: flex;
      align-items: center;
      gap: 15px;
      transition: all 0.3s ease;
    }

    .menu-card:hover {
      transform: translateY(-6px);
      box-shadow: 0 10px 25px rgba(0,0,0,0.12);
    }

    .menu-card img {
      width: 80px;
      height: 80px;
      border-radius: 14px;
      object-fit: cover;
      border: 2px solid #eee;
      background: #fafafa;
      flex-shrink: 0;
    }

    .menu-info {
      flex: 1;
      min-width: 0;
    }

    .menu-info h3 {
      color: #2b4eff;
      font-size: 16px;
      margin-bottom: 5px;
    }

    .menu-info p {
      color: #666;
      font-size: 13px;
      margin-bottom: 4px;
    }

    .menu-info small {
      color: #333;
      font-weight: 600;
      font-size: 13px;
    }

    .menu-actions {
      display: flex;
      flex-direction: column;
      gap: 6px;
      flex-shrink: 0;
    }

    .btn-edit {
      background: #ffb300;
      color: white;
      border: none;
      padding: 6px 10px;
      border-radius: 8px;
      cursor: pointer;
      font-size: 12px;
      transition: 0.3s;
    }
    .btn-edit:hover {
      background: #f29a00;
    }

    .btn-delete {
      background: #e63946;
      color: white;
      border: none;
      padding: 6px 10px;
      border-radius: 8px;
      cursor: pointer;
      font-size: 12px;
      transition: 0.3s;
    }
    .btn-delete:hover {
      background: #c92b39;
    }

    /* Modal */
    .modal-overlay {
      position: fixed;
      inset: 0;
      background: rgba(0,0,0,0.4);
      display: none;
      justify-content: center;
      align-items: center;
      z-index: 999;
    }

    .modal-content {
      background: #fff;
      border-radius: 18px;
      padding: 25px 30px;
      width: 400px;
      max-width: 95%;
      max-height: 90vh;
      overflow-y: auto;
      box-shadow: 0 10px 25px rgba(0,0,0,0.15);
      animation: zoomIn 0.3s ease;
    }

    .modal-content h2 {
      text-align: center;
      color: #2b4eff;
      margin-bottom: 15px;
    }

    label {
      font-weight: 500;
      color: #333;
      display: block;
      margin-top: 8px;
    }

    input, textarea, select {
      width: 100%;
      padding: 8px 10px;
      border-radius: 10px;
      border: 1px solid #ccc;
      margin-top: 4px;
      font-size: 14px;
    }

    .photo-preview {
      width: 150px;
      height: 100px;
      object-fit: cover;
      background-color: #eee;
      border-radius: 8px;
      margin-top: 8px;
      display: none;
    }

    .modal-actions {
      display: flex;
      justify-content: flex-end;
      gap: 10px;
      margin-top: 15px;
    }

    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }

    @keyframes zoomIn {
      from { transform: scale(0.85); opacity: 0; }
      to { transform: scale(1); opacity: 1; }
    }

    .menu-category {
      background: #e7ecff;
      color: #2b4eff;
      font-size: 12px;
      font-weight: 600;
      padding: 4px 8px;
      border-radius: 8px;
      display: inline-block;
      margin-top: 3px;
    }

    .menu-status {
      display: inline-block;
      font-size: 12px;
      font-weight: 600;
      border-radius: 8px;
      padding: 4px 8px;
      margin-left: 6px;
    }

    .status-Tersedia {
      background: #d4f7d4;
      color: #1c7c1c;
    }

    .status-Habis {
      background: #ffd6d6;
      color: #b30000;
    }

    .btn-back-dashboard {
      display: block;
      background: #2b4eff;
      color: #fff;
      padding: 10px 20px;
      border-radius: 12px;
      font-weight: 600;
      font-size: 14px;
      text-decoration: none;
      margin: 0 auto 20px;
      width: max-content;
      transition: 0.3s ease;
    }

    .btn-back-dashboard:hover {
      background: #1e37c4;
      transform: translateY(-2px);
    }

    /* RESPONSIVE */
    @media (max-width: 768px) {
      .container {
        width: 95%;
        margin: 20px auto;
        padding: 24px 18px;
      }
      header h1 {
        font-size: 1.7rem;
      }
      .menu-card {
        width: 100%;
        padding: 12px;
      }
      .menu-card img {
        width: 70px;
        height: 70px;
      }
      .modal-content {
        padding: 20px 18px;
      }
    }
  </style>
</head>

<body>
  <div class="container">

    <!-- Tombol kembali -->
    <a href="index.php" class="btn-back-dashboard">⬅ Kembali ke Dashboard</a>

    <!-- Header utama -->
    <header>
      <h1>Manajemen Menu</h1>
      <p>Kelola daftar menu makanan, minuman, dan snack dengan mudah</p>
    </header>

    <!-- Aksi pencarian + tambah menu -->
    <div class="header-actions">
      <input type="text" id="searchMenu" placeholder="Cari menu...">
      <button id="addMenuBtn" class="btn-primary">+ Tambah Menu</button>
    </div>

    <!-- Daftar Menu -->
    <section class="menu-section">
      <div id="menuCards" class="menu-cards"></div>
    </section>

  </div>

  <!-- Modal Tambah/Edit -->
  <div class="modal-overlay" id="menuModal">
    <div class="modal-content">
      <h2 id="modalTitle">Tambah Menu Baru</h2>

      <form id="menuForm" enctype="multipart/form-data">
        <label>Nama Menu</label>
        <input type="text" id="menuName" required />

        <label>Harga</label>
        <input type="number" id="menuPrice" required />

        <label>Kategori</label>
        <select id="menuCategory" required>
          <option value="Makanan">Makanan</option>
          <option value="Minuman">Minuman</option>
          <option value="Snack">Snack</option>
        </select>

        <label>Status</label>
        <select id="menuStatus" required>
          <option value="Tersedia">Tersedia</option>
          <option value="Habis">Habis</option>
        </select>

        <label>Stok</label>
        <input type="number" id="menuStock" required />

        <label>Deskripsi</label>
        <textarea id="menuDescription" rows="2"></textarea>

        <label>Foto Menu</label>
        <input type="file" id="menuPhoto" accept="image/*"/>
        <img id="photoPreview" class="photo-preview" alt="Preview Foto" />

        <div class="modal-actions">
          <button type="button" class="btn-secondary" id="cancelBtn">Batal</button>
          <button type="submit" class="btn-primary">Simpan</button>
        </div>

      </form>
    </div>
  </div>

  <script>
    // =========================
    // DOM ELEMENTS
    // =========================
    const addBtn       = document.getElementById("addMenuBtn");
    const modal        = document.getElementById("menuModal");
    const cancelBtn    = document.getElementById("cancelBtn");
    const form         = document.getElementById("menuForm");
    const menuCards    = document.getElementById("menuCards");
    const photoPreview = document.getElementById("photoPreview");
    const fileInput    = document.getElementById("menuPhoto");
    const searchInput  = document.getElementById("searchMenu");

    let editId = null;

    // =========================
    // API BASE (RELATIF)
    // =========================
    // Struktur: /ADMIN/menubar.php dan /ADMIN/api/menu_list.php
    const API_BASE = "api/";

    function formatRupiah(n) {
      n = parseInt(n, 10) || 0;
      return "Rp " + n.toLocaleString("id-ID");
    }

    // =========================
    // HELPER GAMBAR
    // =========================
    function resolveImageSrc(m) {
      // ambil nilai dari berbagai kemungkinan field
      let g = (m.gambar || m.img || m.foto || m.photo || "").trim();

      // kalau kosong → placeholder
      if (!g) {
        return "https://via.placeholder.com/100?text=No+Image";
      }

      // kalau sudah URL lengkap / data:image → pakai langsung
      if (/^https?:\/\//i.test(g) || g.startsWith("data:image")) {
        return g;
      }

      // normalisasi (buang query string, buang slash depan)
      g = g.split("?")[0].replace(/^\/+/, "");

      // Kalau DB masih menyimpan path lama seperti "/ADMIN/uploads/xxx.jpg" atau "ADMIN/uploads/xxx.jpg"
      const lower = g.toLowerCase();
      if (lower.startsWith("admin/uploads/") || lower.startsWith("uploads/")) {
        // di halaman admin (folder /ADMIN), cukup pakai "uploads/namafile"
        return "uploads/" + g.split("/").pop();
      }

      // Kalau DB menyimpan filename saja
      return "uploads/" + g;
    }




    // =====================================================
    // LOAD MENU
    // =====================================================
    async function loadMenus(q = "") {
      menuCards.innerHTML = "<p style='text-align:center;color:#777;'>Memuat...</p>";
      try {
        const res = await fetch(`${API_BASE}menu_list.php?q=${encodeURIComponent(q)}`);
        if (!res.ok) {
          throw new Error("Gagal menghubungi server (" + res.status + ")");
        }

        const json = await res.json();
        if (!json.ok) {
          throw new Error(json.error || "Gagal memuat data menu.");
        }

        renderMenus(json.data || []);
      } catch (err) {
        console.error("Error loadMenus:", err);
        menuCards.innerHTML =
          `<p style='text-align:center;color:#c00;'>Terjadi kesalahan saat memuat menu.<br>${err.message}</p>`;
      }
    }

    // =====================================================
    // RENDER MENU
    // =====================================================
    function renderMenus(list) {
      if (!list.length) {
        menuCards.innerHTML = "<p style='text-align:center;color:#777;'>Belum ada menu ditemukan.</p>";
        return;
      }

      menuCards.innerHTML = "";

      list.forEach((m, index) => {
        const nomorUrut = index + 1;
        const imgSrc    = resolveImageSrc(m);

        const card = document.createElement("div");
        card.className = "menu-card";
        card.innerHTML = `
          <img src="${imgSrc}" alt="${m.nama_menu || ''}">
          <div class="menu-info">
            <h3>${nomorUrut}. ${m.nama_menu}</h3>
            <p>${m.deskripsi || ''}</p>
            <small>ID Menu: ${m.id || '-'} • ${formatRupiah(m.harga)} • Stok: ${m.stok}</small><br>
            <span class="menu-category">${m.kategori}</span>
            <span class="menu-status status-${m.status}">${m.status}</span>
          </div>
          <div class="menu-actions">
            <button class="btn-edit" data-id="${m.id}">Edit</button>
            <button class="btn-delete" data-id="${m.id}">Hapus</button>
          </div>
        `;
        menuCards.appendChild(card);
      });

      document.querySelectorAll('.btn-edit').forEach(btn => {
        btn.onclick = () => startEdit(btn.dataset.id);
      });
      document.querySelectorAll('.btn-delete').forEach(btn => {
        btn.onclick = () => delMenu(btn.dataset.id);
      });
    }

    // =====================================================
    // MODAL CONTROL
    // =====================================================
    function openModal(title) {
      document.getElementById("modalTitle").textContent = title;
      modal.style.display = "flex";
    }

    addBtn.onclick = () => {
      form.reset();
      photoPreview.src = "";
      photoPreview.style.display = "none";
      if (fileInput) fileInput.value = "";
      editId = null;
      openModal("Tambah Menu Baru");
    };

    cancelBtn.onclick = () => (modal.style.display = "none");

    // =====================================================
    // PREVIEW FOTO
    // =====================================================
    if (fileInput) {
      fileInput.addEventListener("change", (e) => {
        const file = e.target.files[0];
        if (file) {
          const reader = new FileReader();
          reader.onload = (ev) => {
            photoPreview.src = ev.target.result;
            photoPreview.style.display = "block";
          };
          reader.readAsDataURL(file);
        } else {
          photoPreview.src = "";
          photoPreview.style.display = "none";
        }
      });
    }

    // =====================================================
    // EDIT MENU
    // =====================================================
    async function startEdit(id) {
      try {
        const res  = await fetch(`${API_BASE}menu_list.php`);
        if (!res.ok) throw new Error("Gagal mengambil data menu (" + res.status + ")");
        const json = await res.json();
        if (!json.ok) throw new Error(json.error || "Gagal mengambil data menu.");
        const item = (json.data || []).find((x) => String(x.id) === String(id));

        if (!item) {
          alert("Data tidak ditemukan");
          return;
        }

        editId = id;
        document.getElementById("menuName").value        = item.nama_menu;
        document.getElementById("menuPrice").value       = item.harga;
        document.getElementById("menuDescription").value = item.deskripsi || "";
        document.getElementById("menuStock").value       = item.stok;
        document.getElementById("menuCategory").value    = item.kategori;
        document.getElementById("menuStatus").value      = item.status;

        if (fileInput) fileInput.value = "";
        const imgSrc = resolveImageSrc(item);
        if (imgSrc) {
          photoPreview.src = imgSrc;
          photoPreview.style.display = "block";
        } else {
          photoPreview.src = "";
          photoPreview.style.display = "none";
        }

        openModal("Edit Menu");
      } catch (err) {
        console.error("Error startEdit:", err);
        alert("Terjadi kesalahan saat mengambil data menu: " + err.message);
      }
    }

    // =====================================================
    // HAPUS MENU
    // =====================================================
    async function delMenu(id) {
      if (!confirm("Hapus menu ini?")) return;
      try {
        const res = await fetch(`${API_BASE}menu_delete.php`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id: parseInt(id, 10) }),
        });
        const json = await res.json();
        if (!json.ok) {
          alert(json.error || "Gagal menghapus menu");
          return;
        }
        await loadMenus(searchInput.value);
      } catch (err) {
        console.error("Error delMenu:", err);
        alert("Terjadi kesalahan saat menghapus menu: " + err.message);
      }
    }

    // =====================================================
    // LOAD & SEARCH
    // =====================================================
    searchInput.addEventListener("input", (e) => loadMenus(e.target.value));
    window.addEventListener("DOMContentLoaded", () => loadMenus());

    // =====================================================
    // SUBMIT FORM
    // =====================================================
    function toInt(v) {
      return parseInt((v || "").toString().replace(/[^\d]/g, ""), 10) || 0;
    }

    form.addEventListener("submit", async (e) => {
      e.preventDefault();

      const price = toInt(document.getElementById("menuPrice").value);

      const stockField = document.getElementById("menuStock").value;
      const stock = stockField.trim() === "" ? "0" : stockField.trim();

      const payloadBase = {
        name: document.getElementById("menuName").value.trim(),
        price: price,
        desc: document.getElementById("menuDescription").value,
        stock: stock,
        category: document.getElementById("menuCategory").value,
        status: document.getElementById("menuStatus").value,
        img: null, // bisa diisi base64 atau nama file oleh backend
      };

      const doFetch = async (payload, url) => {
        const res = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });

        const json = await res.json();

        if (!json.ok) {
          console.error("Error API:", json);
          throw new Error(json.error || "Gagal menyimpan menu");
        }

        return json;
      };

      const finish = async (payload) => {
        let url = `${API_BASE}menu_create.php`;
        if (editId) {
          payload.id = parseInt(editId, 10);
          url = `${API_BASE}menu_update.php`;
        }

        await doFetch(payload, url);
        modal.style.display = "none";
        await loadMenus(searchInput.value);
      };

      try {
        if (fileInput && fileInput.files[0]) {
          const reader = new FileReader();
          reader.onload = async (ev) => {
            payloadBase.img = ev.target.result; // data:image/...
            await finish(payloadBase);
          };
          reader.onerror = () => alert("Gagal membaca file gambar.");
          reader.readAsDataURL(fileInput.files[0]);
        } else {
          await finish(payloadBase);
        }
      } catch (err) {
        console.error("Error submit form:", err);
        alert("Terjadi kesalahan saat menyimpan menu: " + err.message);
      }
    });
  </script>
</body>
</html>
