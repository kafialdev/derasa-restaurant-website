<?php
// KONEKSI DATABASE
$conn = new mysqli("localhost", "root", "", "restaurant");
if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "Koneksi gagal"]);
    exit;
}

header('Content-Type: application/json');

$input = file_get_contents("php://input");
$data = json_decode($input, true);

if (!$data || !isset($data['id']) || !isset($data['status'])) {
    echo json_encode(["status" => "error", "message" => "Data tidak lengkap"]);
    exit;
}

$id = (int)$data['id'];
$status = $conn->real_escape_string($data['status']);

$sql = "UPDATE pesanan_masuk SET status='$status' WHERE id=$id";

if ($conn->query($sql)) {
    echo json_encode(["status" => "success", "message" => "Status berhasil diperbarui"]);
} else {
    echo json_encode(["status" => "error", "message" => "Gagal update: " . $conn->error]);
}
$conn->close();
?>
