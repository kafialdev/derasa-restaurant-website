// ======================= DATA STRUCTURE =======================
let orders = JSON.parse(localStorage.getItem('cafeOrders')) || [];
let stockItems = JSON.parse(localStorage.getItem('cafeStock')) || [];
let dailyStats = JSON.parse(localStorage.getItem('cafeStats')) || {
  revenue: 0,
  customers: 0,
  orders: 0
};

// ======================= INITIALIZATION =======================
document.addEventListener('DOMContentLoaded', () => {
  // Jika dashboard sudah memakai DB (index.php menghitung via PHP), jangan override dengan localStorage.
  if (window.USE_DB_DASHBOARD) {
    // tetap jalankan sidebar toggle kalau ada
    const sidebar = document.getElementById('appSidebar');
    const overlay = document.querySelector('.mobile-overlay');
    // no-op: fungsi toggleSidebar didefinisikan di halaman
    return;
  }

renderOrderChart("7");


  // --- SIDEBAR ---
  const navLinks = document.querySelectorAll('#sidebarMenu li a');
  let current = location.pathname.split('/').pop()?.toLowerCase() || '';

  navLinks.forEach(a => {
    const li = a.parentElement;
    const href = (a.getAttribute('href') || '').split('?')[0].split('#')[0].toLowerCase();
    if (href === current) li.classList.add('active');

    a.addEventListener('click', () => {
      document.querySelectorAll('#sidebarMenu li')
        .forEach(x => x.classList.remove('active'));
      li.classList.add('active');
    });

    a.addEventListener('mouseenter', () => a.style.transform = 'translateX(10px)');
    a.addEventListener('mouseleave', () => a.style.transform = 'translateX(0)');
  });

  initializeApp();
  loadDashboardData();


// ======================= ORDER CHART =======================
function renderOrderChart(range = "7") {
  const canvas = document.getElementById("orderChart");
  if (!canvas) return;

  const ctx = canvas.getContext("2d");
  if (window.weekChart) window.weekChart.destroy();

  const orders = JSON.parse(localStorage.getItem("orders")) || [];
  const completed = orders.filter(o => o.status === "completed");

  const today = new Date();
  let startDate = new Date();
  let labels = [];
  let dataset = [];

  // Helper: cocokkan tanggal tanpa jam
  const sameDate = (t, d) =>
    t.getFullYear() === d.getFullYear() &&
    t.getMonth() === d.getMonth() &&
    t.getDate() === d.getDate();

  // ===================== MINGGUAN =====================
  if (range === "7") {
    const day = today.getDay();
    const diffToMonday = (day === 0 ? -6 : 1 - day);
    const monday = new Date(today);
    monday.setDate(today.getDate() + diffToMonday);

    labels = ["Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min"];

    dataset = labels.map((_, i) => {
      const d = new Date(monday);
      d.setDate(monday.getDate() + i);
      return completed.filter(o => {
        const t = new Date(o.time);
        return sameDate(t, d);
      }).length;
    });
  }

  // ===================== BULANAN (30 hari) - label "1 Jan", "2 Jan", ... =====================
if (range === "30") {
  startDate = new Date();
  startDate.setDate(today.getDate() - 29);

  labels = Array.from({ length: 30 }, (_, i) => {
    const d = new Date(startDate);
    d.setDate(startDate.getDate() + i);

    // Format label 01 Nov
    const day = String(d.getDate()).padStart(2, "0");
    const month = d.toLocaleDateString("id-ID", { month: "short" });

    return `${day} ${month}`;
  });

  dataset = Array.from({ length: 30 }, (_, i) => {
    const d = new Date(startDate);
    d.setDate(startDate.getDate() + i);

    return completed.filter(o => {
      const t = new Date(o.time);
      return sameDate(t, d);
    }).length;
  });
}

  // ===================== RENDER CHART =====================
  window.weekChart = new Chart(ctx, {
    type: "bar",
    data: {
      labels: labels,
      datasets: [{
        label: "Pesanan Selesai",
        data: dataset,
        backgroundColor: function() {
          const gradient = ctx.createLinearGradient(0, 0, 0, 300);
          gradient.addColorStop(0, "rgba(54,162,235,0.9)");
          gradient.addColorStop(1, "rgba(54,162,235,0.25)");
          return gradient;
        },
        borderColor: "rgba(54,162,235,1)",
        borderWidth: 1.5,
        borderRadius: 10
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false }
      },
      scales: {
        x: {
          // mencegah label tumpuk pada 30 hari
          ticks: {
            autoSkip: true,
            maxTicksLimit: 10
          }
        },
        y: {
          beginAtZero: true,
          precision: 0,
          ticks: {
            stepSize: 1,
            callback: value => Number(value).toFixed(0)
          }
        }
      }
    }
  });
}



// ===================== TOMBOL MINGGU / BULAN =====================
document.querySelectorAll(".btn-tf").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".btn-tf").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");

    const range = btn.dataset.tf;
    renderOrderChart(range);
  });
});

// Render default: 7 hari
renderOrderChart("7");

  // ======================= FINANCE CHART =======================
  const financeCanvas = document.getElementById('financeChart');
  if (financeCanvas && window.Chart) {
    const ctxF = financeCanvas.getContext('2d');

    const datasetsByRange = {
      7: {
        labels: ['Sen','Sel','Rab','Kam','Jum','Sab','Min'],
        income: [4000000,4800000,4600000,5200000,5800000,6000000,6200000],
        expense:[2500000,2200000,2600000,2700000,2900000,3000000,3100000]
      },
      30: {
        labels: Array.from({length:30},(_,i)=>`Tgl ${i+1}`),
        income: Array.from({length:30},()=>4000000+Math.random()*3000000),
        expense:Array.from({length:30},()=>2000000+Math.random()*1500000)
      },
      90: {
        labels: Array.from({length:12},(_,i)=>`Minggu ${i+1}`),
        income: Array.from({length:12},()=>10000000+Math.random()*5000000),
        expense:Array.from({length:12},()=>7000000+Math.random()*4000000)
      }
    };

    const calcProfit = (income, expense) => income.map((v,i)=>v-expense[i]);
    let chartFinance = null;

    function updateFinanceChart(range='7') {
      const data = datasetsByRange[range];
      const profit = calcProfit(data.income, data.expense);

      const totalIncome  = data.income.reduce((a,b)=>a+b,0);
      const totalExpense = data.expense.reduce((a,b)=>a+b,0);
      const totalProfit  = totalIncome - totalExpense;

      document.getElementById('totalIncome').textContent  = 'Rp ' + totalIncome.toLocaleString();
      document.getElementById('totalExpense').textContent = 'Rp ' + totalExpense.toLocaleString();
      document.getElementById('totalProfit').textContent  = 'Rp ' + totalProfit.toLocaleString();

      if (chartFinance) chartFinance.destroy();

      chartFinance = new Chart(ctxF, {
        type: 'line',
        data: {
          labels: data.labels,
          datasets: [
            { label:'Pendapatan', data:data.income, borderColor:'#28a745', backgroundColor:'rgba(40,167,69,0.15)', fill:true, tension:0.4, borderWidth:3 },
            { label:'Pengeluaran', data:data.expense, borderColor:'#dc3545', backgroundColor:'rgba(220,53,69,0.15)', fill:true, tension:0.4, borderWidth:3 },
            { label:'Laba', data:profit, borderColor:'#ffc107', backgroundColor:'rgba(255,193,7,0.15)', fill:true, tension:0.4, borderWidth:3 }
          ]
        },
        options: {
          responsive: true,
          plugins: { legend: { display:false } },
          scales: {
            y: { beginAtZero:true, ticks:{ callback:v=>'Rp '+v.toLocaleString(), color:'#333' } },
            x: { ticks:{ color:'#333' } }
          }
        }
      });
    }

    updateFinanceChart('7');

    document.querySelectorAll('.btn-tf').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        document.querySelectorAll('.btn-tf').forEach(b=>b.classList.remove('active'));
        btn.classList.add('active');
        updateFinanceChart(btn.dataset.tf);
      });
    });

    document.getElementById('downloadFinanceChart').addEventListener('click', ()=>{
      const link = document.createElement('a');
      link.download = 'grafik_keuangan.png';
      link.href = financeCanvas.toDataURL('image/png');
      link.click();
    });
  }
});

// ======================= INITIAL FUNCTIONS =======================
function initializeApp() {
  if (stockItems.length === 0) {
    stockItems = [
      { id:1, name:'Kopi Arabica', quantity:100, unit:'kg', minStock:20 },
      { id:2, name:'Susu Segar', quantity:50, unit:'liter', minStock:10 },
      { id:3, name:'Gula', quantity:30, unit:'kg', minStock:5 },
      { id:4, name:'Tepung Terigu', quantity:25, unit:'kg', minStock:8 }
    ];
    saveStockData();
  }
}

function loadDashboardData() {
  updateDashboardStats();
  checkLowStock();
}

// ======================= POPULAR MENU (FROM ORDERS ONLY) =======================
function findPopularMenu() {
  if (orders.length === 0) return null;

  const count = {};

  orders.forEach(order => {
    if (!order.items) return;
    order.items.forEach(item => {
      const name = item.name || "Menu Tidak Diketahui";
      count[name] = (count[name] || 0) + (item.quantity || 0);
    });
  });

  const sorted = Object.entries(count).sort((a,b)=>b[1]-a[1]);
  if (!sorted.length) return null;

  return { name: sorted[0][0], orders: sorted[0][1] };
}

function updateDashboardStats() {
  // Jika dashboard sudah pakai data dari DB (PHP), jangan overwrite pakai localStorage/dummy.
  if (window.USE_DB_DASHBOARD) return;

  document.getElementById('todayRevenue').textContent =
    `Rp ${dailyStats.revenue.toLocaleString()}`;

  document.getElementById('todayCustomers').textContent =
    dailyStats.customers;

  const pop = findPopularMenu();
  if (pop) {
    document.getElementById('popularMenu').textContent = pop.name;
    document.getElementById('popularMenuOrders').textContent =
      `${pop.orders} pesanan`;
  }

  const stockLevel = calculateStockLevel();
  document.getElementById('stockLevel').textContent = `${stockLevel}`;
  document.getElementById('stockStatus').textContent =
    stockLevel > 20 ? 'Hari ini' : 'Ramai/Sepi';

  const pendingOrders = orders.filter(o => o.status === 'pending').length;
  document.getElementById('pendingOrders').textContent = pendingOrders;

  const rating = (Math.random() * 1 + 4).toFixed(1);
  document.getElementById('customerRating').textContent = rating;
}

function calculateStockLevel() {
  if (stockItems.length === 0) return 0;
  const total = stockItems.reduce((s,i)=>s+i.quantity,0);
  const min   = stockItems.reduce((s,i)=>s+i.minStock,0);
  if (min === 0) return 100;
  return Math.min(100, Math.round((total / (min * 2)) * 100));
}

function checkLowStock() {
  const low = stockItems.filter(i => i.quantity <= i.minStock);
  if (low.length > 0) showToast(`Warning: ${low.length} item stok rendah!`, 'error');
}

// ======================= UTILITIES =======================
function saveStockData() { localStorage.setItem('cafeStock', JSON.stringify(stockItems)); }
function saveOrderData() { localStorage.setItem('cafeOrders',JSON.stringify(orders)); }
function saveStatsData() { localStorage.setItem('cafeStats', JSON.stringify(dailyStats)); }

function showToast(message, type='success') {
  const toast = document.getElementById('toast');
  if (!toast) return;
  toast.textContent = message || '';
  toast.className = type === 'error' ? 'toast error show' : 'toast show';
  setTimeout(() => toast.classList.remove('show'), 3000);
}

// ======================= PLACEHOLDER NAV BUTTONS =======================
function showRevenueReport() { window.location.href = 'pendapatan.php'; }
function showCustomerReport() { window.location.href = 'pesananproses.php'; }
function showMenuReport()     { window.location.href = 'pesananselesai.php'; }
function showCancelledOrders(){ window.location.href = 'pesananbatal.php'; }
function showStockManager()   { window.location.href = 'pesananmasuk.php'; }
function showOrderManager()   { window.location.href = 'laporan/laporan.php'; }
function showFeedback()       { window.location.href = 'rating/rating.php'; }

// =====================================================================
// =============== KPI DASHBOARD DARI localStorage['orders'] ============
// =====================================================================
(function(){
  function isSameDay(a, b) {
    return a.getFullYear() === b.getFullYear() &&
           a.getMonth() === b.getMonth() &&
           a.getDate() === b.getDate();
  }

  function calcOrderTotal(order) {
    if (Array.isArray(order?.items) && order.items.length) {
      return order.items.reduce((s, it) =>
        s + (Number(it.price) || 0) * (Number(it.quantity) || 0), 0);
    }
    return Number(order?.total || 0);
  }

  function getOrders() {
    try {
      const raw = JSON.parse(localStorage.getItem('orders')) || [];
      return raw.map(o => ({
        id: o.id,
        time: o.time ? new Date(o.time) : null,
        status: (o.status || '').toLowerCase(),
        customer: o.customer || '-',
        items: Array.isArray(o.items) ? o.items : [],
        total: Number(o.total || 0),
        noAntrian: o.noAntrian || null,
        paymentMethod: o.paymentMethod || '-',
        notes: o.notes || ''
      }));
    } catch {
      return [];
    }
  }

  function computeMetrics() {
    const orders = getOrders();
    const today = new Date();

    const pendingOrNew = orders.filter(o => o.status !== 'processing' && o.status !== 'completed' && o.status !== 'cancelled');
    const processing   = orders.filter(o => o.status === 'processing');
    const completed    = orders.filter(o => o.status === 'completed');
    const cancelled    = orders.filter(o => o.status === 'cancelled');

    const isToday = (o) => o.time && isSameDay(o.time, today);
    const masukToday   = pendingOrNew.filter(isToday).length;
    const prosesToday  = processing.filter(isToday).length;
    const selesaiToday = completed.filter(isToday).length;
    const batalToday   = cancelled.filter(isToday).length;

    const pendingToday = orders.filter(o => o.status === 'pending' && isToday(o)).length;

    const revenueToday = completed.filter(isToday)
      .reduce((sum, o) => sum + calcOrderTotal(o), 0);

    const yesterday = new Date(today); yesterday.setDate(today.getDate() - 1);
    const revenueYesterday = completed.filter(o => o.time && isSameDay(o.time, yesterday))
      .reduce((sum, o) => sum + calcOrderTotal(o), 0);
    const deltaPercent = revenueYesterday === 0
      ? 0
      : Math.round(((revenueToday - revenueYesterday) / revenueYesterday) * 100);

    return {
      counts: {
        masuk: pendingOrNew.length,
        proses: processing.length,
        selesai: completed.length,
        batal: cancelled.length,
        masukToday,
        prosesToday,
        selesaiToday,
        batalToday,
        pendingToday
      },
      revenueToday,
      deltaPercent
    };
  }

  function updateDashboardCards() {
    const m = computeMetrics();

    document.getElementById('kpiMasuk').textContent = m.counts.masuk;
    document.getElementById('subMasuk').textContent = `${m.counts.masukToday} Hari ini`;

    document.getElementById('kpiProses').textContent = m.counts.proses;
    document.getElementById('subProses').textContent = `${m.counts.prosesToday} Hari ini`;

    document.getElementById('kpiSelesai').textContent = m.counts.selesai;
    document.getElementById('subSelesai').textContent = `${m.counts.selesai} pesanan`;

    // Pesanan dibatalkan
    const batalEl = document.getElementById('kpiBatal');
    const subBatalEl = document.getElementById('subBatal');
    if (batalEl && subBatalEl) {
      batalEl.textContent = m.counts.batal;
      subBatalEl.textContent = `${m.counts.batalToday} Hari ini`;
    }

    const sign = m.deltaPercent >= 0 ? '+' : '';
    document.getElementById('kpiPendapatan').textContent = `Rp ${m.revenueToday.toLocaleString('id-ID')}`;
    document.getElementById('subPendapatan').textContent = `${sign}${m.deltaPercent}% dari kemarin`;

    document.getElementById('kpiHariIni').textContent = m.counts.pendingToday;
  }

  document.addEventListener('DOMContentLoaded', updateDashboardCards);
  window.addEventListener('storage', (e) => {
    if (e.key === 'orders') updateDashboardCards();
  });
})();

// Logout admin
document.getElementById('logoutBtn')?.addEventListener('click', () => {
  sessionStorage.removeItem('adminLoggedIn'); // hapus session admin
  localStorage.removeItem('adminToken');      // hapus token jika ada

  showToast("Berhasil logout");
  setTimeout(() => {
    window.location.href = 'login.php';
  }, 1000);
});

function showToast(message) {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 3000);
}

// Auto refresh grafik jika minggu berganti
async function autoWeeklyCheck() {
    const res = await fetch("api/weekly_reset.php");
    const js = await res.json();

    if (js.reset === true) {
        console.log("Minggu baru dimulai → grafik di-refresh");
        renderOrderChart(7);
        renderFinanceChart(7);
    }
}

// Auto buat laporan bulanan
async function autoMonthlyReport() {
    const res = await fetch("api/monthly_report.php");
    const js = await res.json();

    if (js.create_report === true) {
        console.log("Laporan bulanan dibuat otomatis.");
    }
}

// jalankan setiap 30 detik
setInterval(() => {
    autoWeeklyCheck();
    autoMonthlyReport();
}, 30000);
