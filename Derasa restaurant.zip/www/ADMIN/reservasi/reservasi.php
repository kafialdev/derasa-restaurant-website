<?php
require_once __DIR__ . '/../koneksi.php';

// Hapus data jika tombol delete ditekan
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $mysqli->query("DELETE FROM reservations WHERE id = $id");
    echo "<script>alert('Reservasi berhasil dihapus!'); window.location.href='reservasi.php';</script>";
    exit;
}

// Searching
$search = $_GET['search'] ?? '';
$searchQuery = "";

if ($search !== "") {
    $searchSafe = $mysqli->real_escape_string($search);
    $searchQuery = "WHERE name LIKE '%$searchSafe%' OR phone LIKE '%$searchSafe%' OR datetime LIKE '%$searchSafe%'";
}

$result = $mysqli->query("SELECT * FROM reservations $searchQuery ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin – Data Reservasi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

    <div class="container py-5">
        <!-- Back to Dashboard -->
        <div class="mb-3">
            <a href="../index.php" class="btn btn-primary">&larr; Kembali ke Dashboard</a>
        </div>
        <h2 class="mb-4 text-center fw-bold">📋 Data Reservasi Pelanggan</h2>

        <!-- Search box -->
        <form class="row mb-4" method="GET">
            <div class="col-md-10">
                <input type="text" name="search" class="form-control" placeholder="Cari nama / nomor HP / tanggal..." value="<?= htmlspecialchars($search) ?>">
            </div>
            <div class="col-md-2">
                <button class="btn btn-primary w-100">Search</button>
            </div>
        </form>

        <div class="card shadow">
            <div class="card-body">

                <table class="table table-bordered table-hover text-center align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>#</th>
                            <th>Nama</th>
                            <th>No HP</th>
                            <th>Tanggal & Waktu</th>
                            <th>Orang</th>
                            <th>Pesan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php if ($result->num_rows > 0): ?>
                            <?php while ($row = $result->fetch_assoc()): ?>
                                <tr>
                                    <td><?= $row['id'] ?></td>
                                    <td><?= htmlspecialchars($row['name']) ?></td>
                                    <td><?= htmlspecialchars($row['phone']) ?></td>
                                    <td><?= htmlspecialchars($row['datetime']) ?></td>
                                    <td><?= htmlspecialchars($row['guests']) ?></td>
                                    <td><?= htmlspecialchars($row['message']) ?></td>

                                    <td>
                                        <a href="?delete=<?= $row['id'] ?>"
                                           onclick="return confirm('Yakin ingin menghapus reservasi ini?')"
                                           class="btn btn-danger btn-sm">
                                            Delete
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>

                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="text-muted">Belum ada data reservasi...</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

            </div>
        </div>

    </div>

</body>
</html>

<?php $mysqli->close(); ?>
