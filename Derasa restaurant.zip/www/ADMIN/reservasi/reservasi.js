document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById("reservationForm");
  if (!form) return; // halaman ini tidak punya form reservasi

  form.addEventListener("submit", function (e) {
    const nameEl = document.getElementById("name");
    const phoneEl = document.getElementById("phone");
    const dtEl = document.getElementById("datetime");

    const name = (nameEl?.value || "").trim();
    const phone = (phoneEl?.value || "").trim();
    const datetime = (dtEl?.value || "").trim();

    if (name === "" || phone === "" || datetime === "") {
      e.preventDefault();
      alert("Nama, nomor telepon, dan tanggal wajib diisi!");
      return false;
    }
    return true;
  });
});

function showReservationPopup() {
  const name = (document.getElementById("name")?.value || "").trim();
  const phone = (document.getElementById("phone")?.value || "").trim();
  const datetime = (document.getElementById("datetime")?.value || "").trim();
  const people = document.getElementById("people")?.value || "";
  const message = document.getElementById("message")?.value || "";

  if (name === "" || phone === "" || datetime === "") {
    alert("Nama, nomor telepon, dan tanggal wajib diisi!");
    return;
  }

  // isi popup jika elemennya ada
  const setText = (id, val) => { const el = document.getElementById(id); if (el) el.innerText = val; };
  setText("r_name", name);
  setText("r_phone", phone);
  setText("r_datetime", datetime);
  setText("r_people", people);
  setText("r_message", message);

  const popup = document.getElementById("receiptPopup");
  if (popup) popup.style.display = "flex";
}

function closeReceiptPopup() {
  const popup = document.getElementById("receiptPopup");
  if (popup) popup.style.display = "none";
}

function submitReservation() {
  const form = document.getElementById("reservationForm");
  if (form) form.submit();
}
