<?php
require_once __DIR__ . '/../koneksi.php';

// Pastikan request POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $name     = $_POST["name"] ?? '';
    $phone    = $_POST["phone"] ?? '';
    $datetime = $_POST["datetime"] ?? '';
    $people   = $_POST["people"] ?? '';
    $message  = $_POST["message"] ?? '';

    // Validasi
    if ($name === "" || $phone === "" || $datetime === "") {
        echo "<script>alert('Semua field wajib diisi!'); window.history.back();</script>";
        exit;
    }

    // Perbaiki format datetime dari "2025-11-19T23:37" ke "2025-11-19 23:37:00"
    $datetime = str_replace("T", " ", $datetime) . ":00";

    // Simpan ke database
    $stmt = $mysqli->prepare("
        INSERT INTO reservations (name, phone, datetime, guests, message, created_at)
        VALUES (?, ?, ?, ?, ?, NOW())
    ");

    $stmt->bind_param("sssss", $name, $phone, $datetime, $people, $message);
    if ($stmt->execute()) {
        echo "<script>
        alert('Reservasi berhasil disimpan!');
        window.location.href='../../index.php';
      </script>";
    } else {
        echo '<pre>Error SQL: ' . $stmt->error . '</pre>';
    }


    $stmt->close();
    $mysqli->close();
}
?>
