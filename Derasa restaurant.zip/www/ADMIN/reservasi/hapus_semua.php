<?php
include "../koneksi.php";
if (!isset($conn) && isset($mysqli)) { $conn = $mysqli; }

mysqli_query($conn, "TRUNCATE TABLE reservations");

header("Location: ../index.php");
exit;
?>
