<?php
/**
 * Salin file ini menjadi: config.php
 * Lalu isi sesuai setting database hosting kamu.
 * (Di localhost boleh dibiarkan default)
 */
date_default_timezone_set('Asia/Jakarta');

$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'restaurant';

// Admin koneksi.php akan ikut pakai variabel ini bila tersedia
$servername = $DB_HOST;
$username   = $DB_USER;
$password   = $DB_PASS;
$dbname     = $DB_NAME;

// Mode debug (tampilkan error) hanya untuk localhost
$APP_DEBUG = ($_SERVER['SERVER_NAME'] ?? '') === 'localhost';
