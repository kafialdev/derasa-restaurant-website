<?php
// proses_reservasi.php
// Endpoint penyimpanan reservasi (dipakai user) -> tersimpan & terbaca di Admin.
// Support:
// 1) AJAX (fetch)  : return JSON
// 2) POST biasa    : redirect kembali ke index.php

// IMPORTANT: supaya output JSON tidak rusak oleh warning/notice
error_reporting(E_ALL);
ini_set('display_errors', '0');

require_once __DIR__ . '/koneksi.php';
if (!isset($conn) && isset($koneksi)) { $conn = $koneksi; }

$accept = strtolower($_SERVER['HTTP_ACCEPT'] ?? '');
$xrw    = strtolower($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '');
$isAjax = (strpos($accept, 'application/json') !== false) || ($xrw === 'xmlhttprequest');

if ($isAjax) {
  header('Content-Type: application/json; charset=utf-8');
}

function json_out($data, $code = 200) {
  http_response_code($code);
  echo json_encode($data);
  exit;
}

function redirect_back($ok, $msg = '') {
  $q = $ok ? 'ok=1' : 'ok=0';
  if ($msg !== '') { $q .= '&msg=' . urlencode($msg); }
  // Query string harus sebelum anchor
  header('Location: index.php?' . $q . '#reservasi');
  exit;
}

if (!isset($conn) || !($conn instanceof mysqli)) {
  if ($isAjax) json_out(['status'=>'error','message'=>'Koneksi database tidak tersedia'], 500);
  redirect_back(false, 'Koneksi database tidak tersedia');
}

// Pastikan tabel tersedia (biar aman walau database belum import SQL)
// NOTE: ini tidak akan mengubah data yang sudah ada, hanya membuat tabel jika belum ada.
try {
  $conn->query("CREATE TABLE IF NOT EXISTS `reservations` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(100) NOT NULL,
    `phone` VARCHAR(20) NOT NULL,
    `datetime` DATETIME NOT NULL,
    `guests` VARCHAR(50) DEFAULT NULL,
    `message` TEXT,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_datetime` (`datetime`)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (Throwable $e) {
  // kalau gagal bikin tabel (misal permission), lanjutkan ke proses insert dan biarkan error ter-report
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
  if ($isAjax) json_out(['status'=>'error','message'=>'Method tidak didukung'], 405);
  redirect_back(false, 'Method tidak didukung');
}

$payload = [];
$raw = file_get_contents('php://input');
if (is_string($raw) && trim($raw) !== '') {
  $j = json_decode($raw, true);
  if (is_array($j)) { $payload = $j; }
}
if (!is_array($payload) || !$payload) { $payload = $_POST; }

$name     = trim((string)($payload['name'] ?? ''));
$phone    = trim((string)($payload['phone'] ?? ''));
$datetime = trim((string)($payload['datetime'] ?? ''));
$guests   = trim((string)($payload['guests'] ?? ($payload['people'] ?? ($payload['Guests'] ?? ''))));
$message  = trim((string)($payload['message'] ?? ''));

if ($name === '' || $phone === '' || $datetime === '') {
  if ($isAjax) json_out(['status'=>'error','message'=>'Nama, telepon, dan tanggal wajib diisi'], 400);
  redirect_back(false, 'Nama/Telepon/Tanggal wajib diisi');
}

$datetime = str_replace('T',' ',$datetime);
if (strlen($datetime) === 16) { $datetime .= ':00'; }

// Validasi datetime sederhana (hindari 0000-00-00)
$ts = strtotime($datetime);
if ($ts === false) {
  if ($isAjax) json_out(['status'=>'error','message'=>'Format tanggal/waktu tidak valid'], 400);
  redirect_back(false, 'Format tanggal/waktu tidak valid');
}

try {
  $stmt = $conn->prepare('INSERT INTO reservations (name, phone, datetime, guests, message) VALUES (?,?,?,?,?)');
  $stmt->bind_param('sssss', $name, $phone, $datetime, $guests, $message);
  $stmt->execute();
  $id = $stmt->insert_id;
  $stmt->close();
  if ($isAjax) {
    json_out(['status'=>'success','message'=>'Reservasi berhasil dikirim','reservation_id'=>$id]);
  }
  redirect_back(true, 'Reservasi berhasil dikirim');
} catch (Throwable $e) {
  if ($isAjax) json_out(['status'=>'error','message'=>$e->getMessage()], 500);
  redirect_back(false, $e->getMessage());
}
