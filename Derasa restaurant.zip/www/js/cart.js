/* ===================================================================
   CART.JS — FINAL VERSION (FADE-IN, FADE-OUT BLUR, BACK BUTTON FIX)
   =================================================================== */

// ==========================
// INIT CART
// ==========================
let cart = JSON.parse(localStorage.getItem("cart")) || [];

// Normalisasi path gambar di keranjang
function resolveCartImage(raw) {
  if (!raw) return "https://via.placeholder.com/100?text=No+Image";

  let img = String(raw).trim();

  // URL penuh / data URI
  if (/^https?:\/\//i.test(img) || img.startsWith("data:image")) return img;

  // buang prefix relatif seperti ../ atau ./
  while (img.startsWith("../")) img = img.substring(3);
  while (img.startsWith("./")) img = img.substring(2);

  // buang slash depan
  img = img.replace(/^\/+/, "");
  const lower = img.toLowerCase();

  // kalau path mengandung admin/uploads di mana pun
  const marker = "admin/uploads/";
  const idx = lower.indexOf(marker);
  if (idx !== -1) {
    const rest = img.substring(idx + marker.length);
    return "ADMIN/uploads/" + rest;
  }

  // kalau path mulai dari uploads/
  if (lower.startsWith("uploads/")) return "ADMIN/" + img;

  // kalau hanya nama file
  return "ADMIN/uploads/" + img;
}



function saveCart() {
  localStorage.setItem("cart", JSON.stringify(cart));
}

// ==========================
// RENDER CART
// ==========================
function renderCart() {
  const cartContainer = document.getElementById("cart-items");
  const totalEl = document.getElementById("cart-total");
  if (!cartContainer || !totalEl) return;

  cartContainer.innerHTML = "";
  let total = 0;

  if (cart.length === 0) {
    cartContainer.innerHTML = '<p class="empty-cart">Keranjang Anda kosong 😢</p>';
    totalEl.textContent = "Rp 0";
    return;
  }

  cart.forEach((item, index) => {
    const subtotal = item.price * item.qty;
    total += subtotal;

    const imgSrc = resolveCartImage(item.img);

    const el = document.createElement("div");
    el.classList.add("cart-item");
    el.innerHTML = `
      <img src="${imgSrc}" alt="${item.name}">
      <div class="cart-details">
        <div class="top">
          <h3>${item.name}</h3>
          <div class="price-remove">
            <span class="price">Rp ${item.price.toLocaleString("id-ID")}</span>
            <button class="remove-item" data-index="${index}" title="Hapus item">❌</button>
          </div>
        </div>
        <div class="bottom">
          <div class="quantity-control">
            <button class="decrease" data-index="${index}" title="Kurangi">−</button>
            <input type="text" value="${item.qty}" readonly>
            <button class="increase" data-index="${index}" title="Tambah">+</button>
          </div>
        </div>
      </div>
    `;
    cartContainer.appendChild(el);
  });

  totalEl.textContent = `Rp ${total.toLocaleString("id-ID")}`;
  saveCart();
}

// ==========================
// EVENT: TAMBAH / KURANG / HAPUS ITEM
// ==========================
document.addEventListener("click", (e) => {
  const index = e.target.dataset.index;
  if (typeof index === "undefined") return;

  if (e.target.classList.contains("increase")) {
    cart[index].qty++;
  }

  if (e.target.classList.contains("decrease")) {
    if (cart[index].qty > 1) {
      cart[index].qty--;
    } else {
      if (confirm(`Hapus ${cart[index].name} dari keranjang?`)) {
        cart.splice(index, 1);
      }
    }
  }

  if (e.target.classList.contains("remove-item")) {
    if (confirm(`Yakin ingin menghapus ${cart[index].name}?`)) {
      cart.splice(index, 1);
    }
  }

  saveCart();
  renderCart();
});

// ==========================
// SMOOTH REDIRECT (FADE OUT + BLUR)
// ==========================
function smoothRedirect(url, delay = 300) {
  document.body.classList.remove("loaded");
  document.body.classList.add("blur-out");

  setTimeout(() => {
    window.location.href = url;
  }, delay);
}

// ==========================
// DOMContentLoaded
// ==========================
document.addEventListener("DOMContentLoaded", () => {
  
  // FADE-IN + REMOVE BURAM
  requestAnimationFrame(() => {
    setTimeout(() => document.body.classList.add("loaded"), 20);
  });

  if (typeof updateFloatingCart === "function") {
    try { updateFloatingCart(); } catch (e) {}
  }
  if (typeof updateCartIcon === "function") {
    try { updateCartIcon(); } catch (e) {}
  }

  renderCart();

  if (typeof syncMenuControls === "function") {
    try { syncMenuControls(); } catch (e) {}
  }

  // ==========================
  // GROUP TOMBOL BACK
  // ==========================
  (function ensureInlineBackAndAddButton() {
    const cartWrapper = document.querySelector(".cart-container");
    if (!cartWrapper) return;
    if (cartWrapper.querySelector("#back-group")) return;

    if (getComputedStyle(cartWrapper).position === "static") {
      cartWrapper.style.position = "relative";
    }

    const group = document.createElement("div");
    group.id = "back-group";
    group.className = "back-group";

    const backBtn = document.createElement("button");
    backBtn.id = "back-to-previous";
    backBtn.className = "back-arrow";
    backBtn.type = "button";
    backBtn.title = "Kembali";
    backBtn.innerHTML = '<span class="arrow">&larr;</span>';

    // FINAL BACK FIX — selalu smooth, tidak patah
    backBtn.addEventListener("click", () => {
      smoothRedirect("ordermakan.php");
    });

    group.appendChild(backBtn);

    const slot = cartWrapper.querySelector("#cart-back-slot");
    if (slot) {
      slot.appendChild(group);
    } else {
      // fallback: taruh di paling atas
      cartWrapper.insertBefore(group, cartWrapper.firstChild);
    };
  })();

  // ==========================
  // HIGHLIGHT NAV "MENU"
  // ==========================
  (function highlightMenuNav() {
    const navAnchors = document.querySelectorAll(".nav-links a, header a, .navbar a");
    navAnchors.forEach((a) => {
      try {
        if ((a.textContent || "").toLowerCase().trim().includes("menu")) {
          a.classList.add("menu");
        }
      } catch (e) {}
    });
  })();

  // ==========================
  // TOMBOL "TAMBAH MENU LAIN"
  // ==========================
  const backToMenuEl = document.getElementById("back-to-menu");
  if (backToMenuEl) {
    backToMenuEl.addEventListener("click", () => smoothRedirect("ordermakan.php"));
  }

  // ==========================
  // TOMBOL CHECKOUT
  // ==========================
  const paymentBtn = document.getElementById("checkout-btn");
  if (paymentBtn) {
    paymentBtn.addEventListener("click", () => {
      if (cart.length === 0) {
        alert("Keranjang masih kosong 😢");
        return;
      }
      smoothRedirect("payment/payment.php");
    });
  }

});
