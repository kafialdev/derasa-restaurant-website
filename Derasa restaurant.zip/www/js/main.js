(function ($) {
    "use strict";

    // ==========================//
    //       Spinner             //
    // ==========================//
    var spinner = function () {
        setTimeout(function () {
            if ($('#spinner').length > 0) {
                $('#spinner').removeClass('show');
            }
        }, 1);
    };
    spinner();

    

    // ===================================================================
    // 🔥 REPLACEMENT FOR WOW.js — SUPER SMOOTH, NO LAG, LIGHTWEIGHT
    // ===================================================================
    document.addEventListener("DOMContentLoaded", () => {
        const animatedElements = document.querySelectorAll(
            ".wow, .fadeInLeft, .fadeInRight, .fadeInUp, [data-wow-delay]"
        );

        animatedElements.forEach(el => {
            el.classList.add("fade-anim");
        });

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add("visible");
                }
            });
        }, { threshold: 0.2 });

        animatedElements.forEach(el => observer.observe(el));
    });


    // ==========================//
    //      Sticky Navbar        //
    // ==========================//
    $(window).scroll(function () {
        if ($(this).scrollTop() > 45) {
            $('.navbar').addClass('sticky-top shadow-sm');
        } else {
            $('.navbar').removeClass('sticky-top shadow-sm');
        }
    });


    // ==========================//
    //   Dropdown on Hover       //
    // ==========================//
    const $dropdown = $(".dropdown");
    const $dropdownToggle = $(".dropdown-toggle");
    const $dropdownMenu = $(".dropdown-menu");
    const showClass = "show";

    $(window).on("load resize", function () {
        if (this.matchMedia("(min-width: 992px)").matches) {
            $dropdown.hover(
                function () {
                    const $this = $(this);
                    $this.addClass(showClass);
                    $this.find($dropdownToggle).attr("aria-expanded", "true");
                    $this.find($dropdownMenu).addClass(showClass);
                },
                function () {
                    const $this = $(this);
                    $this.removeClass(showClass);
                    $this.find($dropdownToggle).attr("aria-expanded", "false");
                    $this.find($dropdownMenu).removeClass(showClass);
                }
            );
        } else {
            $dropdown.off("mouseenter mouseleave");
        }
    });


    // ==========================//
    //    Back to Top Button     //
    // ==========================//
    $(window).scroll(function () {
        if ($(this).scrollTop() > 300) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });

    $('.back-to-top').click(function () {
        $('html, body').animate({ scrollTop: 0 }, 1500, 'easeInOutExpo');
        return false;
    });


    // ==========================//
    //      Facts Counter        //
    // ==========================//
    $('[data-toggle="counter-up"]').counterUp({
        delay: 10,
        time: 2000
    });


    // ==========================//
    //       Modal Video         //
    // ==========================//
    $(document).ready(function () {
        var $videoSrc;
        $('.btn-play').click(function () {
            $videoSrc = $(this).data("src");
        });

        $('#videoModal').on('shown.bs.modal', function () {
            $("#video").attr('src', $videoSrc + "?autoplay=1&amp;modestbranding=1&amp;showinfo=0");
        });

        $('#videoModal').on('hide.bs.modal', function () {
            $("#video").attr('src', $videoSrc);
        });
    });


    // ==========================//
    //   Testimonials Carousel   //
    // ==========================//
    $(".testimonial-carousel").owlCarousel({
        autoplay: true,
        smartSpeed: 1000,
        center: true,
        margin: 24,
        dots: true,
        loop: true,
        nav: false,
        responsive: {
            0: { items: 1 },
            768: { items: 2 },
            992: { items: 3 }
        }
    });


    // ==========================//
    //    Smooth scroll buttons  //
    // ==========================//
    function smoothScroll(buttonId, targetId) {
        const btn = document.getElementById(buttonId);
        const target = document.getElementById(targetId);
        if (btn && target) {
            btn.addEventListener('click', function () {
                target.scrollIntoView({ behavior: 'smooth' });
            });
        }
    }
    smoothScroll('scrollToDivButton', 'targetDiv');
    smoothScroll('scrollToMenuButton', 'targetMenu');
    smoothScroll('scrollToBuyButton', 'targetbuy');
    smoothScroll('scrollToChefButton', 'Chef');
    smoothScroll('scrollToServiceButton', 'targetService');


    // ==========================//
    //          Dark Mode        //
    // ==========================//
    document.addEventListener("DOMContentLoaded", function () {
        const toggleBtn = document.getElementById("darkModeToggle");
        if (toggleBtn) {
            toggleBtn.addEventListener("click", function () {
                document.body.classList.toggle("dark-mode");
                console.log("Dark mode toggled");
            });
        }


        // ==========================//
        // Auto Capitalize Name      //
        // ==========================//
        (function safeCapitalizeName() {
            const nameInput = document.getElementById("name");
            if (!nameInput) return;

            let composing = false;

            function capitalizeValue(el) {
                let start = el.selectionStart;
                let end = el.selectionEnd;
                const newVal = el.value.replace(/\b\w/g, ch => ch.toUpperCase());
                if (newVal !== el.value) {
                    el.value = newVal;
                    try { el.setSelectionRange(start, end); } catch (err) { }
                }
            }

            nameInput.addEventListener("compositionstart", () => composing = true);
            nameInput.addEventListener("compositionend", e => {
                composing = false;
                capitalizeValue(e.target);
            });

            nameInput.addEventListener("input", function () {
                if (composing) return;
                capitalizeValue(this);
            });

            nameInput.addEventListener("blur", function () {
                this.value = this.value
                    .replace(/\s+/g, " ")
                    .trim()
                    .replace(/\b\w/g, ch => ch.toUpperCase());
            });
        })();


        // ==========================//
        //   Simple Form Validation  //
        // ==========================//
        const form = document.getElementById("reservationForm");
        if (form) {
            form.addEventListener("submit", function (e) {
                e.preventDefault();
                const name = document.getElementById("name").value.trim();
                const email = document.getElementById("email").value.trim();
                const message = document.getElementById("message").value.trim();

                if (!name || !email || !message) {
                    alert("Harap isi semua field sebelum submit!");
                } else {
                    alert("Terima kasih, " + name + "! Reservasi Anda sudah terkirim.");
                    form.reset();
                }
            });
        }
    });


    // ==========================//
    //   ORDER MAKAN – FILTER     //
    // ==========================//
    const filterButtons = document.querySelectorAll('.filter-btn');
    const menuItems = document.querySelectorAll('.menu-item');

    filterButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const category = btn.dataset.category;

            filterButtons.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            menuItems.forEach(item => {
                if (category === 'all' || item.classList.contains(category)) {
                    item.style.display = 'flex';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    });

})(jQuery);

var swiper = new Swiper(".mySwiper", {
    slidesPerView: 3,          // tampil 3 card
    spaceBetween: 30,
    loop: true,
    autoplay: {
        delay: 2500,
        disableOnInteraction: false,
    },
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },

    breakpoints: {
        0:   { slidesPerView: 1 },
        768: { slidesPerView: 2 },
        1024:{ slidesPerView: 3 }
    }
});

function downloadPDF() {

    if (!window.jspdf || typeof window.jspdf.jsPDF === "undefined") {
        alert("PDF gagal dibuat. jsPDF tidak ter-load.");
        return;
    }

    const { jsPDF } = window.jspdf;
    const doc = new jsPDF("p", "mm", "a4");

    // ambil data dari popup
    const name     = document.getElementById("r_name").innerText;
    const phone    = document.getElementById("r_phone").innerText;
    const datetime = document.getElementById("r_datetime").innerText;
    const people   = document.getElementById("r_people").innerText;
    const message  = document.getElementById("r_message").innerText;

    // ======================
    // BLUE BORDER FRAME
    // ======================
    doc.setDrawColor(40, 80, 160); 
    doc.setLineWidth(1.2);
    doc.roundedRect(10, 10, 190, 277, 6, 6);

    // ======================
    // HEADER (BLUE THEME)
    // ======================
    doc.setFont("helvetica", "bold");
    doc.setFontSize(26);
    doc.setTextColor(30, 60, 120);
    doc.text("DeRasa Restaurant", 105, 28, { align: "center" });

    doc.setFont("helvetica", "normal");
    doc.setFontSize(14);
    doc.setTextColor(100, 100, 100);
    doc.text("Reservation Receipt", 105, 38, { align: "center" });

    // BLUE LINE
    doc.setDrawColor(40, 80, 160);
    doc.setLineWidth(1);
    doc.line(40, 45, 170, 45);

    // ======================
    // BLUE INFO BOX
    // ======================
    doc.setFillColor(235, 242, 255);  // soft blue
    doc.roundedRect(20, 55, 170, 150, 4, 4, "F");

    // ======================
    // CONTENT
    // ======================
    let y = 75;

    doc.setFont("helvetica", "bold");
    doc.setFontSize(13);
    doc.setTextColor(20, 40, 80);

    // NAME
    doc.text("Name", 30, y);
    doc.setFont("helvetica", "normal");
    doc.text(": " + name, 80, y);
    y += 15;

    // PHONE
    doc.setFont("helvetica", "bold");
    doc.text("Phone", 30, y);
    doc.setFont("helvetica", "normal");
    doc.text(": " + phone, 80, y);
    y += 15;

    // DATE & TIME
    doc.setFont("helvetica", "bold");
    doc.text("Date & Time", 30, y);
    doc.setFont("helvetica", "normal");
    doc.text(": " + datetime, 80, y);
    y += 15;

    // GUESTS
    doc.setFont("helvetica", "bold");
    doc.text("Guests", 30, y);
    doc.setFont("helvetica", "normal");
    doc.text(": " + people, 80, y);
    y += 15;

    // REQUEST
    doc.setFont("helvetica", "bold");
    doc.text("Request", 30, y);
    doc.setFont("helvetica", "normal");
    doc.text(": " + (message || "-"), 80, y);
    y += 25;

    // ======================
    // WARNING RED TEXT
    // ======================
    doc.setTextColor(200, 0, 0);
    doc.setFont("helvetica", "bold");
    doc.text("IMPORTANT NOTE:", 30, y);

    doc.setFont("helvetica", "normal");
    doc.text("Jika meja penuh, CS kami akan menghubungi Anda.", 30, y + 10);

    // ======================
    // FOOTER
    // ======================
    doc.setTextColor(30, 60, 120);
    doc.setFont("helvetica", "italic");
    doc.setFontSize(12);
    doc.text("Thank you for choosing DeRasa Restaurant!", 105, 275, { align: "center" });

    // simpan file
    const filename = "Reservasi_" + name.replace(/\s+/g, "_") + ".pdf";
    doc.save(filename);
}


// =========== SEMUA FUNGSI POPUP ADA DI SINI (DI LUAR IIFE) ===========

function formatDateTime(value) {
  const date = new Date(value);

  const months = [
    "Januari", "Februari", "Maret", "April", "Mei", "Juni",
    "Juli", "Agustus", "September", "Oktober", "November", "Desember"
  ];

  const day = String(date.getDate()).padStart(2, "0");
  const month = months[date.getMonth()];
  const year = date.getFullYear();
  const hours = String(date.getHours()).padStart(2, "0");
  const minutes = String(date.getMinutes()).padStart(2, "0");

  return `${day} ${month} ${year}, ${hours}:${minutes}`;
}

function showReservationPopup() {
  const name     = document.getElementById("name").value;
  const phone    = document.getElementById("phone").value;
  const datetime = document.getElementById("datetime").value;
  const people   = document.getElementById("people").value;
  const message  = document.getElementById("message").value;

  document.getElementById("r_name").innerText = name;
  document.getElementById("r_phone").innerText = phone;
  document.getElementById("r_datetime").innerText = formatDateTime(datetime);
  document.getElementById("r_people").innerText = people;
  document.getElementById("r_message").innerText = message;

  // IMPORTANT: gunakan flex agar popup benar-benar center (CSS pakai justify/align)
  document.getElementById("receiptPopup").style.display = "flex";
}

// Tutup popup reservasi
function closeReservationPopup() {
  const popup = document.getElementById("receiptPopup");
  if (popup) popup.style.display = "none";
}

// Notifikasi kecil (toast) untuk reservasi
function showReservationToast(title, subtitle = "", type = "success") {
  try {
    let toast = document.getElementById("reservationToast");
    if (!toast) {
      toast = document.createElement("div");
      toast.id = "reservationToast";
      toast.className = "reservation-toast";
      toast.innerHTML = `
        <div class="rt-title"></div>
        <div class="rt-sub"></div>
      `;
      document.body.appendChild(toast);
    }

    toast.classList.remove("success", "error");
    toast.classList.add(type === "error" ? "error" : "success");

    const t1 = toast.querySelector(".rt-title");
    const t2 = toast.querySelector(".rt-sub");
    if (t1) t1.textContent = title || (type === "error" ? "Gagal" : "Berhasil");
    if (t2) t2.textContent = subtitle || "";

    toast.classList.add("show");
    clearTimeout(window.__rt_timer);
    window.__rt_timer = setTimeout(() => toast.classList.remove("show"), 3500);
  } catch (e) {
    // fallback sederhana
    alert((type === "error" ? "❌ " : "✅ ") + (title || "") + (subtitle ? "\n" + subtitle : ""));
  }
}

// expose biar bisa dipanggil dari index.php setelah redirect (?ok=1)
window.showReservationToast = showReservationToast;

// Kirim reservasi ke DB (reservations)
// return: response JSON dari server
async function submitReservation(options = {}) {
  const { silent = false } = options;
  const name     = (document.getElementById("name")?.value || "").trim();
  const phone    = (document.getElementById("phone")?.value || "").trim();
  const datetime = (document.getElementById("datetime")?.value || "").trim();
  const people   = (document.getElementById("people")?.value || "").trim();
  const message  = (document.getElementById("message")?.value || "").trim();

  if (!name || !phone || !datetime) {
    if (!silent) alert("Nama, Telepon, dan Tanggal/Waktu wajib diisi!");
    return { status: "error", message: "Validation failed" };
  }

  try {
    const res = await fetch("proses_reservasi.php", {
      method: "POST",
      headers: {"Content-Type": "application/json", "Accept": "application/json"},
      body: JSON.stringify({ name, phone, datetime, guests: people, message })
    });
    const json = await res.json();
    if (!res.ok || json.status !== "success") {
      throw new Error(json.message || ("HTTP " + res.status));
    }
    if (!silent) alert("✅ Reservasi berhasil dikirim! ID: " + (json.reservation_id || "-"));
    return json;
  } catch (err) {
    console.error(err);
    // Fallback: submit biasa (tanpa AJAX) supaya tetap tersimpan ke DB
    try {
      const form = document.getElementById("reservationForm");
      if (form) {
        form.submit();
        return { status: "success", message: "submitted" };
      }
    } catch (_) {}
    if (!silent) alert("❌ Gagal mengirim reservasi: " + err.message);
    return { status: "error", message: err.message };
  }
}

// UX: klik Reserve Now langsung proses -> lalu popup bukti tampil
async function reserveNow() {
  const json = await submitReservation({ silent: true });
  if (json && json.status === "success") {
    showReservationToast("Reservasi berhasil!", json.reservation_id ? ("ID Reservasi: " + json.reservation_id) : "Kami akan menghubungi Anda.", "success");
    // isi konten popup dari input terbaru
    showReservationPopup();
    // reset input supaya tidak double submit
    ["name","phone","datetime","people","message"].forEach(id=>{ const el=document.getElementById(id); if (el) el.value=""; });
  }
}

// === RESERVATION: pastikan tombol selalu berfungsi ===
// Jika JS berhasil load, kita intercept submit supaya:
// 1) simpan via AJAX (tanpa reload)
// 2) tampilkan popup receipt
// Kalau JS gagal load, fallback submit biasa tetap jalan karena tombol type="submit".
document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("reservationForm");
  if (!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const btn = document.getElementById("reserveBtn");
    const oldText = btn ? btn.innerText : "";
    if (btn) {
      btn.disabled = true;
      btn.innerText = "Processing...";
    }

    const json = await submitReservation({ silent: true });

    if (json && json.status === "success") {
      showReservationToast("Reservasi berhasil!", json.reservation_id ? ("ID Reservasi: " + json.reservation_id) : "Kami akan menghubungi Anda.", "success");
      showReservationPopup();
      // reset form aman (select & textarea ikut reset)
      form.reset();
    } else {
      // submitReservation sudah fallback submit biasa kalau fetch gagal.
      // Kalau masih error, tampilkan alert sederhana.
      if (json && json.message) showReservationToast("Reservasi gagal", json.message, "error");
    }

    if (btn) {
      btn.disabled = false;
      btn.innerText = oldText || "Reserve Now";
    }
  });
});

