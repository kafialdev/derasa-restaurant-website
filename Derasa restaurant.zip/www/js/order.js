// Identifikasi kategori halaman (makan, minum, snack)
const category = window.location.pathname
  .split("/")
  .pop()
  .replace(".php", "")
  .replace("order", "");

// Inisialisasi keranjang
let cart = JSON.parse(localStorage.getItem("cart")) || [];

// ---------------------- SAVE CART ----------------------
function saveCart() {
  localStorage.setItem("cart", JSON.stringify(cart));
}

// ---------------------- TRANSISI HALUS ----------------------
function smoothRedirect(url) {
  document.body.classList.remove("loaded");
  document.body.style.opacity = "0";
  setTimeout(() => (window.location.href = url), 300);
}

// ---------------------- NOTIFICATION ----------------------
function showNotification(text, type = "add") {
  const box = document.getElementById("notifBox");
  if (!box) return;

  box.textContent = text;
  box.className = `notif-floating ${type} show`;

  setTimeout(() => {
    box.classList.remove("show");
  }, 1200);
}


// ---------------------- TAMBAH ITEM ----------------------
function addToCart(item) {
  const existing = cart.find(i => i.id === item.id && i.category === category);

  if (existing) {
    existing.qty += 1;
  } else {
    cart.push({ ...item, qty: 1, category });
  }

  saveCart();
  updateFloatingCart();
  updateCartIcon();
  syncMenuControls();
  showNotification(`${item.name} ditambahkan 🛒`, "add");

  const f = document.getElementById("floatingCart");
  if (f) f.classList.add("show");
}

// ---------------------- HAPUS ITEM ----------------------
function removeFromCart(itemId, cat) {
  const index = cart.findIndex(i => i.id == itemId && i.category === cat);

  if (index !== -1) {
    cart[index].qty -= 1;

    if (cart[index].qty <= 0) {
      const removedName = cart[index].name;
      cart.splice(index, 1);
      showNotification(`${removedName} dihapus ❌`, "remove");
    }
  }

  saveCart();
  updateFloatingCart();
  updateCartIcon();
  renderCart();
  syncMenuControls();
}

// ---------------------- CLEAR ----------------------
function clearCart() {
  if (!confirm("Yakin ingin menghapus semua item di keranjang?")) return;

  cart = [];
  saveCart();
  renderCart();
  updateFloatingCart();
  updateCartIcon();
  syncMenuControls();
  showNotification("Semua item dihapus 🗑️", "remove");
}

// ---------------------- UPDATE FLOATING CART ----------------------
function updateFloatingCart() {
  const f = document.getElementById("floatingCart");
  const count = document.getElementById("cart-count");
  const total = document.getElementById("cart-total");

  if (!f || !count || !total) return;

  const totalItems = cart.reduce((s, i) => s + i.qty, 0);
  const totalPrice = cart.reduce((s, i) => s + i.price * i.qty, 0);

  count.textContent = `${totalItems} item`;
  total.textContent = `Rp ${totalPrice.toLocaleString("id-ID")}`;

  f.classList.toggle("show", totalItems > 0);
}

// ---------------------- ICON ----------------------
function updateCartIcon() {
  const icon = document.getElementById("floatingCartIcon");
  const badge = document.getElementById("cart-badge");
  if (!icon || !badge) return;

  const totalItems = cart.reduce((s, i) => s + i.qty, 0);
  badge.textContent = totalItems;
  icon.classList.toggle("show", totalItems > 0);
}

// ---------------------- RENDER CART ----------------------
function renderCart() {
  const container = document.getElementById("cart-container");
  const totalDiv = document.getElementById("cart-total");
  if (!container || !totalDiv) return;

  container.innerHTML = "";

  if (cart.length === 0) {
    container.innerHTML = "<p>Keranjang Anda kosong 😢</p>";
    totalDiv.textContent = "Total: Rp 0";
    return;
  }

  let total = 0;
  cart.forEach((item, index) => {
    total += item.price * item.qty;

    const div = document.createElement("div");
    div.classList.add("cart-item");
    div.innerHTML = `
      <img src="${item.img}" alt="${item.name}">
      <div class="cart-info">
        <h3>${item.name}</h3>
        <p><small>${item.category.toUpperCase()}</small></p>
        <p>Rp ${item.price.toLocaleString("id-ID")}</p>
        <div class="cart-qty">
          <button class="qty-btn" data-index="${index}" data-action="decrease">−</button>
          <span>${item.qty}</span>
          <button class="qty-btn" data-index="${index}" data-action="increase">+</button>
        </div>
      </div>
      <button class="remove-item" data-index="${index}">❌</button>
    `;
    container.appendChild(div);
  });

  totalDiv.textContent = `Total: Rp ${total.toLocaleString("id-ID")}`;
}

// ---------------------- SYNC MENU BUTTONS ----------------------
function syncMenuControls() {
  document.querySelectorAll(".menu-item").forEach(menuEl => {
    const id = menuEl.dataset.id;
    if (!id) return;

    const existing = cart.find(i => i.id == id && i.category === category);
    let actions = menuEl.querySelector(".action-btns");

    if (!actions) {
      actions = document.createElement("div");
      actions.className = "action-btns";
      menuEl.appendChild(actions);
    }

    actions.innerHTML = "";

    if (!existing) {
      const add = document.createElement("button");
      add.className = "add-btn";
      add.textContent = "+";
      add.addEventListener("click", () => {
        const item = {
          id: menuEl.dataset.id,
          name: menuEl.dataset.name,
          price: parseInt(menuEl.dataset.price),
          img: menuEl.dataset.img
        };
        addToCart(item);
      });
      actions.appendChild(add);

    } else {
      const wrap = document.createElement("div");
      wrap.className = "qty-control";

      const dec = document.createElement("button");
      dec.className = "qty-btn";
      dec.textContent = "−";
      dec.addEventListener("click", () => removeFromCart(id, category));

      const span = document.createElement("span");
      span.className = "qty-number";
      span.textContent = existing.qty;

      const inc = document.createElement("button");
      inc.className = "qty-btn";
      inc.textContent = "+";
      inc.addEventListener("click", () => {
        const item = {
          id: menuEl.dataset.id,
          name: menuEl.dataset.name,
          price: parseInt(menuEl.dataset.price),
          img: menuEl.dataset.img
        };
        addToCart(item);
      });

      wrap.append(dec, span, inc);
      actions.appendChild(wrap);
    }
  });
}

// ========================================================
// DOMContentLoaded
// ========================================================
document.addEventListener("DOMContentLoaded", () => {
  document.body.classList.add("loaded");

  updateFloatingCart();
  updateCartIcon();
  renderCart();
  syncMenuControls();

  const viewCartBtn = document.getElementById("view-cart");
  if (viewCartBtn) {
    viewCartBtn.addEventListener("click", () => {
      if (cart.length === 0) {
        showNotification("Keranjang kosong 🍽️", "remove");
        return;
      }
      localStorage.setItem("selectedMenu", JSON.stringify(cart));
      smoothRedirect("keranjang.php");
    });
  }

  const clearCartBtn = document.getElementById("clear-cart");
  if (clearCartBtn) clearCartBtn.addEventListener("click", clearCart);
});

// ========================================================
// Event tombol + - & hapus
// ========================================================
document.addEventListener("click", e => {
  if (e.target.classList.contains("remove-item")) {
    const idx = e.target.dataset.index;
    const removedName = cart[idx]?.name;

    cart.splice(idx, 1);
    showNotification(`${removedName} dihapus ❌`, "remove");

    saveCart();
    renderCart();
    updateFloatingCart();
    updateCartIcon();
    syncMenuControls();
  }

  if (e.target.classList.contains("qty-btn")) {
    const idx = e.target.dataset.index;
    const act = e.target.dataset.action;

    if (act === "increase") {
      cart[idx].qty += 1;
      showNotification(`${cart[idx].name} ditambahkan 🛒`, "add");
    }
    if (act === "decrease") {
      cart[idx].qty -= 1;
      if (cart[idx] && cart[idx].qty <= 0) {
        const removedName = cart[idx].name;
        cart.splice(idx, 1);
        showNotification(`${removedName} dihapus ❌`, "remove");
      }
    }

    saveCart();
    renderCart();
    updateFloatingCart();
    updateCartIcon();
    syncMenuControls();
  }
});

// ========================================================
// FIX floating cart muncul otomatis
// ========================================================
window.addEventListener("load", () => {
  const f = document.getElementById("floatingCart");
  const total = cart.reduce((s, i) => s + (i.qty || 0), 0);
  if (f && total > 0) f.classList.add("show");
});
