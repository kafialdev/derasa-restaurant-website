<?php
require_once __DIR__ . '/../ADMIN/koneksi.php';

// Pastikan timezone sesuai Indonesia (biar jam & tanggal benar)
date_default_timezone_set('Asia/Jakarta');

$order_id = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;
$order = null;
$items = [];

if ($order_id > 0) {
  $stmt = $conn->prepare("SELECT id, waktu, pelanggan, telepon, metode_pembayaran, status, catatan, total FROM pesanan_masuk WHERE id = ?");
  $stmt->bind_param('i', $order_id);
  $stmt->execute();
  $order = $stmt->get_result()->fetch_assoc();
  $stmt->close();

  if ($order) {
    $stmt2 = $conn->prepare("SELECT nama_menu, qty, harga FROM detail_pesanan WHERE order_id = ? ORDER BY id ASC");
    $stmt2->bind_param('i', $order_id);
    $stmt2->execute();
    $items = $stmt2->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt2->close();
  }
}

/* =========================
   FIX TANGGAL STRUK DI SINI
   ========================= */
$tanggal_label = '-';
if (!empty($order) && !empty($order['waktu'])) {
  // Handle format waktu dari MySQL (DATETIME / TIMESTAMP)
  $ts = strtotime($order['waktu']);
  if ($ts !== false) {
    // Contoh: Jumat, 12 Desember 2025 • 14:09 WIB
    $tanggal_label = date('d-m-Y H:i', $ts);

    // Kalau mau versi lebih “rapi” pakai nama hari/bulan Indonesia (opsional):
    // $hari = ['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'];
    // $bulan = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
    // $tanggal_label = $hari[(int)date('w',$ts)].', '.date('d',$ts).' '.$bulan[(int)date('n',$ts)-1].' '.date('Y H:i',$ts).' WIB';
  }
}

// hitung subtotal dari detail jika ada, fallback ke total
$subtotal = 0;
foreach ($items as $it) {
  $subtotal += ((int)$it['harga']) * ((int)$it['qty']);
}
if ($subtotal <= 0 && $order) {
  $subtotal = (int)$order['total'];
}
$pajak = (int)round($subtotal * 0.10);
$grand = $subtotal + $pajak;
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Bukti Pembayaran - Restoran DeRasa</title>

  <style>
  @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&family=Playfair+Display:wght@600&display=swap');
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(135deg, #ffffff, #ffffff);
    padding: 20px; margin: 0;
    display: block; min-height: auto;
    overflow-x: hidden;
  }
  .receipt-card {
    display: flex; flex-direction: row;
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(15px);
    border-radius: 25px; overflow: hidden;
    width: 100%; max-width: 950px; margin: auto;
    box-shadow: 0 30px 40px rgba(15, 40, 80, 0.15);
    animation: fadeIn 0.8s ease;
    border: 2px solid #1F4E79;
  }
  .left-side {
    width: 40%;
    background: linear-gradient(135deg, #0A1A2F, #1F4E79);
    color: white; padding: 30px;
    display: flex; flex-direction: column; justify-content: space-between;
    border-right: 3px solid rgba(255,255,255,0.25);
  }
  .restaurant-logo { text-align: center; }
  .restaurant-logo img {
    width: 85px; height: 85px; border-radius: 50%;
    object-fit: cover; margin-bottom: 10px;
    border: 3px solid rgba(255,255,255,0.4);
  }
  .restaurant-logo h2 {
    font-family: 'Playfair Display', serif;
    margin: 10px 0 5px; font-size: 26px; color: #FFFFFF;
  }
  .restaurant-logo h2 span { color: #DCEBFF; }
  .restaurant-logo p { font-size: 14px; opacity: 0.9; }

  .customer-info {
    background: rgba(255,255,255,0.15);
    border-radius: 15px; padding: 15px;
  }
  .customer-info h3 {
    font-size: 18px; margin-bottom: 10px;
    font-weight: 600; color: #E8F3FF;
  }
  .info-row {
    display: flex; justify-content: space-between; gap: 10px;
    font-size: 14px; margin: 5px 0;
    border-bottom: 1px dashed rgba(255,255,255,0.25);
    padding-bottom: 5px; word-break: break-word;
  }
  .info-row span:last-child { text-align: right; }

  .status-section { text-align: center; }
  .status-section h3 {
    font-size: 16px; font-weight: 600; color: #E8F3FF;
  }

  .right-side {
    width: 60%; padding: 35px 40px;
    display: flex; flex-direction: column; justify-content: space-between;
    color: #123456;
  }
  .right-side h3 {
    color: #1F4E79; font-size: 22px;
    margin-bottom: 15px;
    font-family: 'Playfair Display', serif;
  }
  .items {
    background: #F4F9FF;
    border-radius: 15px;
    padding: 18px; margin-bottom: 20px;
    border: 1px solid #BFD7FF;
  }
  .item {
    display: flex; justify-content: space-between; gap: 12px;
    font-size: 15px; color: #1A2B3C;
    margin: 6px 0; word-break: break-word;
  }
  .item span:last-child {
    font-weight: 600; color: #1F4E79; text-align: right;
  }
  .receipt-total {
    background: linear-gradient(135deg, #E8F3FF, #D5E7FF);
    border-radius: 15px;
    padding: 15px 20px;
    box-shadow: inset 0 2px 5px rgba(190, 218, 255, 0.6);
  }
  .receipt-total p {
    font-size: 14px; color: #1A2B3C;
    display: flex; justify-content: space-between;
  }
  .receipt-total h2 {
    text-align: right; color: #1F4E79;
    font-size: 24px; margin-top: 10px;
  }
  .footer {
    text-align: center;
    border-top: 1px dashed #BFD7FF;
    padding-top: 15px; margin-top: 20px;
  }
  .footer p { color: #1F3250; font-size: 14px; margin-bottom: 10px; }
  .footer-btns {
    display: flex; justify-content: center;
    gap: 10px; flex-wrap: wrap;
  }
  .footer button {
    background: linear-gradient(90deg, #1F77DD, #165FB5);
    border: none; border-radius: 10px;
    color: white; padding: 10px 20px;
    font-size: 15px; font-weight: 600;
    cursor: pointer; transition: 0.3s;
    box-shadow: 0 4px 12px rgba(31, 119, 221, 0.3);
  }
  .footer button:hover { transform: scale(1.05); background: linear-gradient(90deg, #165FB5, #1F77DD); }
  @keyframes fadeIn { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }

  @media (max-width: 850px) {
    .receipt-card { flex-direction: column; width: 100%; max-width: 100%; }
    .left-side, .right-side { width: 100%; padding: 20px 18px; }
    .left-side { border-right: none; border-bottom: 3px solid rgba(255,255,255,0.25); }
    body { padding: 12px; }
  }
  @media (max-width: 430px) {
    body { padding: 10px 8px; }
    .receipt-card { border-radius: 18px; width: 100%; max-width: 100%; margin: 0 auto; }
    .left-side, .right-side { padding: 16px 12px; }
    .restaurant-logo img { width: 70px; height: 70px; }
    .restaurant-logo h2 { font-size: 20px; }
    .restaurant-logo p { font-size: 12px; }
    .customer-info h3 { font-size: 15px; }
    .info-row { font-size: 12px; }
    .right-side h3 { font-size: 18px; margin-bottom: 12px; }
    .items { padding: 12px; margin-bottom: 14px; }
    .item { font-size: 13px; }
    .receipt-total { padding: 12px 14px; }
    .receipt-total p { font-size: 13px; }
    .receipt-total h2 { font-size: 20px; }
    .footer p { font-size: 12px; }
    .footer-btns { flex-direction: column; align-items: stretch; }
    .footer button { width: 100%; font-size: 14px; padding: 9px 14px; }
  }

  /* Rating modal CSS (punyamu tetap) */
  .rating-backdrop{position:fixed;inset:0;background:rgba(0,0,50,0.35);backdrop-filter:blur(2px);z-index:90;display:none;}
  .rating-modal{position:fixed;inset:0;display:none;place-items:center;z-index:100;}
  .rating-modal__content{width:min(520px,92vw);background:rgba(255,255,255,0.98);border:1px solid #BFD7FF;border-radius:20px;padding:22px 22px;box-shadow:0 18px 50px rgba(10,40,90,0.2);animation:fadeIn 0.25s ease;color:#123456;position:relative;}
  .rating-modal__content h3{margin:0 0 6px;font-family:'Playfair Display',serif;font-size:22px;color:#1F4E79;}
  .rating-subtitle{margin:0 0 14px;color:#345;font-size:14px;}
  .stars{display:flex;gap:8px;margin-bottom:10px;}
  .star{font-size:28px;line-height:1;background:linear-gradient(90deg,#1F4E79,#3C6EB4);-webkit-background-clip:text;background-clip:text;color:transparent;border:1px solid #BFD7FF;border-radius:12px;padding:8px 10px;cursor:pointer;transition:transform .12s ease,box-shadow .12s ease;}
  .star:hover{transform:translateY(-1px) scale(1.03);}
  .star.active{background:linear-gradient(90deg,#3C6EB4,#1F4E79);color:#fff;box-shadow:0 6px 14px rgba(31,77,130,0.35);}
  .feedback-label{display:block;margin:10px 0 6px;font-size:13px;color:#345;}
  .feedback-input{width:100%;border:1px solid #BFD7FF;border-radius:12px;padding:10px 12px;background:#F4F9FF;color:#123456;resize:vertical;}
  .rating-error{margin:6px 0 0;color:#d44;font-size:13px;}
  .rating-actions{display:flex;justify-content:flex-end;gap:10px;margin-top:14px;}
  .btn-primary{border-radius:10px;padding:10px 16px;font-weight:600;cursor:pointer;background:linear-gradient(90deg,#1F77DD,#165FB5);color:#fff;box-shadow:0 4px 12px rgba(31,119,221,0.35);}
  .btn-primary:hover{transform:scale(1.03);}
  .btn-ghost{background:#fff;color:#345;border:1px solid #BFD7FF;padding:10px 16px;border-radius:10px;font-weight:600;}
  .rating-backdrop.is-open{display:block;}
  .rating-modal.is-open{display:grid;}
  .close-rating{position:absolute;top:10px;right:14px;background:none;border:none;font-size:24px;font-weight:bold;color:#1F4E79;cursor:pointer;transition:transform .2s ease,color .2s ease;}
  .close-rating:hover{color:#165FB5;transform:scale(1.15);}

  @media print {
    body, html {
      margin: 0 !important;
      padding: 0 !important;
      background: #fff !important;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }

    /* Sembunyikan elemen interaktif */
    button, .footer-btns, #ratingModal, #ratingBackdrop, .rating-modal, .rating-backdrop {
      display: none !important;
    }

    /* Kartu struk full-width agar tidak kepotong di HP */
    .receipt-card {
      width: 100% !important;
      max-width: 100% !important;
      margin: 0 !important;
      border: 1px solid #000 !important;
      border-radius: 10px !important;
      box-shadow: none !important;
      display: block !important;
      page-break-inside: avoid !important;
    }

    /* Paksa jadi 1 kolom saat print */
    .left-side, .right-side {
      width: 100% !important;
      padding: 12px !important;
    }

    .left-side {
      background: #fff !important;
      color: #000 !important;
      border-right: none !important;
      border-bottom: 1px dashed #000 !important;
    }

    .right-side {
      color: #000 !important;
    }

    /* Tetap tampilkan logo & teks */
    .restaurant-logo img { display: block !important; }
    a { color: #000 !important; text-decoration: none !important; }

    /* Hindari ukuran kertas fixed 80mm yang sering bikin aneh di mobile */
    @page { size: auto; margin: 8mm; }
  }


  .notif{position:fixed;top:20px;right:20px;padding:12px 18px;background:linear-gradient(135deg,#1F4E79,#0A1A2F);color:#fff;border-radius:10px;font-size:15px;opacity:0;pointer-events:none;transform:translateY(-20px);transition:opacity .4s ease,transform .4s ease;z-index:9999;}
  .notif.show{opacity:1;transform:translateY(0);pointer-events:auto;}
  </style>
</head>

<body>
  <div class="receipt-card">
    <div class="left-side">
      <div class="restaurant-logo">
        <img src="../img/logofiks.png" alt="Logo Restoran">
        <h2>Restoran <span>DeRasa</span></h2>
        <p>Jl. Panglima Sudirman No. 68, Surabaya</p>
      </div>

      <div class="customer-info">
        <h3>👤 Identitas Pelanggan</h3>
        <div class="info-row"><span>ID Pesanan</span><span id="idPesanan"><?php echo htmlspecialchars($order['id'] ?? '-'); ?></span></div>
        <div class="info-row"><span>Nama</span><span id="namaPelanggan"><?php echo htmlspecialchars($order['pelanggan'] ?? '-'); ?></span></div>
        <div class="info-row"><span>No. Telepon</span><span id="noTelepon"><?php echo htmlspecialchars($order['telepon'] ?? '-'); ?></span></div>
        <div class="info-row"><span>Metode</span><span id="metodeBayar"><?php echo htmlspecialchars($order['metode_pembayaran'] ?? '-'); ?></span></div>
        <!-- FIX: Tanggal sekarang pasti ada (ambil dari $order['waktu']) -->
        <div class="info-row"><span>Tanggal</span><span id="tanggalTransaksi"><?php echo htmlspecialchars($tanggal_label); ?></span></div>
      </div>

      <div class="status-section">
        <h3>Pembayaran Berhasil ✅</h3>
      </div>
    </div>

    <div class="right-side">
      <h3>🧾 Rincian Pesanan</h3>
      <div class="items" id="rincianPesanan">
        <?php if (empty($order)): ?>
          <div class="item"><span>Pesanan tidak ditemukan / order_id belum dikirim.</span><span></span></div>
        <?php elseif (empty($items)): ?>
          <div class="item"><span>Detail pesanan kosong.</span><span></span></div>
        <?php else: ?>
          <?php foreach ($items as $it): ?>
            <div class="item">
              <span><?php echo htmlspecialchars($it['nama_menu']); ?> (x<?php echo (int)$it['qty']; ?>)</span>
              <span>Rp<?php echo number_format((int)$it['harga'] * (int)$it['qty'], 0, ',', '.'); ?></span>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>

      <div class="receipt-total">
        <p>Subtotal: <span id="subtotal">Rp <?php echo number_format((int)$subtotal, 0, ',', '.'); ?></span></p>
        <p>Pajak (10%): <span id="pajak">Rp <?php echo number_format((int)$pajak, 0, ',', '.'); ?></span></p>
        <h2>Total: <span id="totalHarga">Rp <?php echo number_format((int)$grand, 0, ',', '.'); ?></span></h2>
      </div>

      <div class="footer">
        <p id="peringatanKasir" style="display:none; color:red; font-weight:bold; margin-bottom:10px;">
          Lakukan pembayaran di kasir, atau pemesananmu tidak akan diproses!
        </p>
        <p>Terima kasih telah berkunjung ke <strong>Restoran DeRasa</strong> 💛</p>
        <div class="footer-btns">
          <button type="button" onclick="window.print()">🖨️ Cetak Struk</button>
          <button id="btnBeranda" type="button">🏠 Kembali ke Beranda</button>
        </div>
      </div>
    </div>
  </div>

  <div id="ratingBackdrop" class="rating-backdrop"></div>
  <div id="ratingModal" class="rating-modal" role="dialog" aria-modal="true" aria-labelledby="ratingTitle">
    <div class="rating-modal__content">
      <button id="closeRating" class="close-rating" type="button" aria-label="Tutup pop-up">&times;</button>
      <h3 id="ratingTitle">Bagaimana pengalaman Anda?</h3>
      <p class="rating-subtitle">Beri rating untuk kunjungan Anda hari ini.</p>

      <div class="stars" aria-label="Pilih rating 1 sampai 5">
        <button class="star" data-value="1" aria-label="1 bintang">★</button>
        <button class="star" data-value="2" aria-label="2 bintang">★</button>
        <button class="star" data-value="3" aria-label="3 bintang">★</button>
        <button class="star" data-value="4" aria-label="4 bintang">★</button>
        <button class="star" data-value="5" aria-label="5 bintang">★</button>
      </div>
      <p id="ratingError" class="rating-error" hidden>Silakan pilih rating dulu.</p>

      <label class="feedback-label" for="ratingFeedback">Masukan (opsional)</label>
      <textarea id="ratingFeedback" class="feedback-input" rows="3" placeholder="Tulis saran atau kesan Anda..."></textarea>
      <div class="rating-actions">
        <button id="skipRating" class="btn-ghost" type="button">Lewati</button>
        <button id="submitRating" class="btn-primary" type="button">Kirim & Kembali</button>
        <div id="notif" class="notif"></div>
      </div>
    </div>
  </div>

  <script>
  const ORDER_ID = <?php echo (int)$order_id; ?>;
  const METODE_BAYAR = <?php echo json_encode($order['metode_pembayaran'] ?? ''); ?>;

  const peringatanKasir = document.getElementById("peringatanKasir");
  if (peringatanKasir) {
    const m = String(METODE_BAYAR || '').toLowerCase();
    if (m === 'kasir' || m === 'bayar di kasir' || m === 'cash') peringatanKasir.style.display = 'block';
    else peringatanKasir.style.display = 'none';
  }

  const btnBeranda = document.getElementById('btnBeranda');
  const backdrop   = document.getElementById('ratingBackdrop');
  const modal      = document.getElementById('ratingModal');
  const closeBtn   = document.getElementById('closeRating');
  const skipBtn    = document.getElementById('skipRating');

  const openModal = () => {
    backdrop.classList.add('is-open');
    modal.classList.add('is-open');
    document.body.style.overflow = 'hidden';
  };

  const closeModal = () => {
    backdrop.classList.remove('is-open');
    modal.classList.remove('is-open');
    document.body.style.overflow = '';
  };

  closeBtn?.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); closeModal(); });
  btnBeranda?.addEventListener('click', (e) => { e.preventDefault(); openModal(); });
  backdrop?.addEventListener('click', (e) => { if (e.target === backdrop) closeModal(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && modal.classList.contains('is-open')) closeModal(); });

  const submitBtn  = document.getElementById('submitRating');
  const stars      = Array.from(document.querySelectorAll('.star'));
  const errorEl    = document.getElementById('ratingError');
  const feedbackEl = document.getElementById('ratingFeedback');

  const redirectHome = () => { window.location.href = '../index.php'; };

  let selectedRating = 0;
  stars.forEach(s => s.addEventListener('click', () => {
    selectedRating = Number(s.dataset.value);
    stars.forEach(x => x.classList.toggle('active', Number(x.dataset.value) <= selectedRating));
    if (errorEl) errorEl.hidden = true;
  }));

  function showNotif(text) {
    const notif = document.getElementById("notif");
    notif.textContent = text;
    notif.classList.add("show");
    setTimeout(() => notif.classList.remove("show"), 2000);
  }

  skipBtn?.addEventListener('click', (e) => { e.preventDefault(); redirectHome(); });

  const NAMA_PELANGGAN = <?php echo json_encode($order['pelanggan'] ?? 'Guest'); ?>;

  submitBtn?.addEventListener("click", async (e) => {
    e.preventDefault();
    if (!selectedRating) { if (errorEl) errorEl.hidden = false; return; }

    const namaPelanggan = NAMA_PELANGGAN || "Guest";
    const komentar = feedbackEl?.value?.trim() || "";

    const formData = new FormData();
    formData.append("order_id", String(ORDER_ID || 0));
    formData.append("name", namaPelanggan);
    formData.append("star", selectedRating);
    formData.append("comment", komentar);

    try {
      const res = await fetch("../ADMIN/rating/simpan_review.php", { method: "POST", body: formData });
      const data = await res.json();

      if (!data.success) { showNotif("❌ Review gagal disimpan!"); return; }
      showNotif("🎉 Review berhasil dikirim!");
      setTimeout(() => redirectHome(), 2000);
    } catch (err) {
      showNotif("⚠️ Terjadi kesalahan jaringan!");
    }
  });
  </script>
</body>
</html>
